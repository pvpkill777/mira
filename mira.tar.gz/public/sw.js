/* Service Worker кондитерской «Мира».
 * - страницы: сначала сеть, при отсутствии сети — кеш или офлайн-страница;
 * - статика Next (/_next/static), шрифты, иконки: cache-first;
 * - фото (Unsplash, загрузки): stale-while-revalidate;
 * - API никогда не кешируется.
 */
// Меняйте версию при изменении логики SW: старые кеши удаляются при активации.
const VERSION = "mira-v2";
const PAGES = `${VERSION}-pages`;
const STATIC = `${VERSION}-static`;
const IMAGES = `${VERSION}-images`;
const OFFLINE_URL = "/offline.html";

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(PAGES)
      .then((c) => c.addAll([OFFLINE_URL, "/", "/icons/icon-192.png"]))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

async function trimCache(name, max) {
  const cache = await caches.open(name);
  // Офлайн-страницу и главную, положенные при установке, не вытесняем.
  const keys = (await cache.keys()).filter((r) => {
    const p = new URL(r.url).pathname;
    return p !== OFFLINE_URL && p !== "/";
  });
  for (let i = 0; i < keys.length - max; i++) await cache.delete(keys[i]);
}

/** Кешируем только обычные успешные ответы своего сайта, которые сервер разрешил хранить. */
function cacheable(res) {
  if (!res || !res.ok || res.type !== "basic" || res.redirected) return false;
  const cc = res.headers.get("Cache-Control") || "";
  return !/no-store|private/i.test(cc);
}

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  const sameOrigin = url.origin === self.location.origin;

  // Кабинет и API (кроме картинок) — только сеть, ничего не кешируем.
  if (sameOrigin && url.pathname.startsWith("/admin")) return;
  if (sameOrigin && url.pathname.startsWith("/api/") && !url.pathname.startsWith("/api/media/")) return;

  if (request.mode === "navigate") {
    // Сеть в приоритете — после деплоя пользователь сразу получает свежий HTML;
    // кеш используется только без сети. Ключ — путь без query, чтобы кеш не разрастался.
    const key = new Request(url.origin + url.pathname);
    event.respondWith(
      fetch(request)
        .then((res) => {
          if (cacheable(res)) {
            const copy = res.clone();
            caches.open(PAGES).then((c) => c.put(key, copy).then(() => trimCache(PAGES, 20)));
          }
          return res;
        })
        .catch(async () => (await caches.match(key)) || (await caches.match("/")) || caches.match(OFFLINE_URL)),
    );
    return;
  }

  const isStatic =
    (url.origin === self.location.origin && (url.pathname.startsWith("/_next/static/") || url.pathname.startsWith("/icons/"))) ||
    url.hostname === "fonts.gstatic.com";
  if (isStatic) {
    event.respondWith(
      caches.match(request).then(
        (hit) =>
          hit ||
          fetch(request).then((res) => {
            if (res.ok) {
              const copy = res.clone();
              // Чанки прошлых деплоев не нужны вечно — держим ограниченное число файлов.
              caches.open(STATIC).then((c) => c.put(request, copy).then(() => trimCache(STATIC, 150)));
            }
            return res;
          }),
      ),
    );
    return;
  }

  const isImage = request.destination === "image" || url.hostname === "images.unsplash.com" || url.pathname.startsWith("/api/media/");
  if (isImage) {
    event.respondWith(
      caches.open(IMAGES).then(async (cache) => {
        const hit = await cache.match(request);
        const network = fetch(request)
          .then((res) => {
            if (res.ok || res.type === "opaque") {
              cache.put(request, res.clone());
              trimCache(IMAGES, 80);
            }
            return res;
          })
          .catch(() => hit);
        return hit || network;
      }),
    );
  }
});
