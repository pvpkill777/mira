#!/usr/bin/env bash
# Установка и обновление сайта «Мира» на сервере Ubuntu/Debian.
#
#   bash setup-server.sh /root/mira.tar.gz            — адрес вида 31-58-118-148.sslip.io (без своего домена)
#   bash setup-server.sh /root/mira.tar.gz cakes.ru   — свой домен (A-запись уже должна указывать на сервер)
#
# Скрипт можно запускать повторно: он обновит код, но сохранит .env, базу и загруженные фото.
set -euo pipefail

ARCHIVE="${1:-/root/mira.tar.gz}"
APP_DIR=/opt/mira
APP_USER=mira
PORT=3000
# Часовой пояс кондитерской: от него зависят «сегодня», доступные интервалы и срочность заказа.
SITE_TZ="${SITE_TZ:-Europe/Moscow}"

say() { printf '\n\033[1;33m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31mОшибка: %s\033[0m\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "запустите от root"
[ -f "$ARCHIVE" ] || die "не найден архив $ARCHIVE — загрузите mira.tar.gz на сервер"
. /etc/os-release
case "${ID:-} ${ID_LIKE:-}" in *debian*|*ubuntu*) ;; *) die "скрипт рассчитан на Ubuntu/Debian, а здесь ${PRETTY_NAME:-неизвестная система}" ;; esac

# ——— Адрес сайта ———
if [ -n "${2:-}" ]; then
  DOMAIN="$2"
elif [ -f "$APP_DIR/.env" ] && grep -q '^NEXT_PUBLIC_SITE_URL=' "$APP_DIR/.env"; then
  DOMAIN="$(grep '^NEXT_PUBLIC_SITE_URL=' "$APP_DIR/.env" | sed -E 's#.*https?://([^"/]+).*#\1#')"
else
  IP="$(curl -fsS4 --max-time 10 https://api.ipify.org 2>/dev/null || hostname -I | awk '{print $1}')"
  DOMAIN="${IP//./-}.sslip.io"
fi
say "Адрес сайта: https://$DOMAIN"

# ——— Системные пакеты ———
say "Обновляю список пакетов и ставлю нужные утилиты"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl ca-certificates gnupg sqlite3 openssl tar
timedatectl set-timezone "$SITE_TZ" 2>/dev/null || ln -sf "/usr/share/zoneinfo/$SITE_TZ" /etc/localtime

# Сборке Next.js нужно ~1,5 ГБ памяти: на маленьком сервере добавляем swap.
MEM_MB="$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)"
if [ "$MEM_MB" -lt 2000 ] && [ -z "$(swapon --show --noheadings)" ]; then
  say "Памяти ${MEM_MB} МБ — добавляю swap 2 ГБ"
  fallocate -l 2G /swapfile 2>/dev/null || dd if=/dev/zero of=/swapfile bs=1M count=2048
  chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
  grep -q '^/swapfile ' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

if ! command -v node >/dev/null 2>&1 || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 20 ]; then
  say "Ставлю Node.js 22"
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
say "Node.js $(node -v), npm $(npm -v)"

if ! command -v caddy >/dev/null 2>&1; then
  say "Ставлю Caddy (веб-сервер, сам получает и продлевает HTTPS-сертификат)"
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor --yes -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -y
  apt-get install -y caddy
fi

# ——— Код приложения ———
say "Распаковываю проект в $APP_DIR"
id "$APP_USER" >/dev/null 2>&1 || useradd --system --create-home --home-dir "/home/$APP_USER" --shell /usr/sbin/nologin "$APP_USER"
mkdir -p "$APP_DIR"
FIRST_RUN=0
[ -f "$APP_DIR/.env" ] || FIRST_RUN=1

if [ -f "$APP_DIR/prisma/prod.db" ]; then
  mkdir -p /var/backups/mira
  BACKUP="/var/backups/mira/prod-$(date +%F-%H%M%S).db"
  sqlite3 "$APP_DIR/prisma/prod.db" ".backup '$BACKUP'"
  say "Резервная копия базы перед обновлением: $BACKUP"
fi

# Архив не содержит .env, базу и uploads — они сохраняются при обновлении.
tar -xzf "$ARCHIVE" -C "$APP_DIR"
rm -rf "$APP_DIR/.next"
mkdir -p "$APP_DIR/uploads"

PIN=""
if [ "$FIRST_RUN" -eq 1 ]; then
  PIN="$(shuf -i 100000-999999 -n 1)"
  cat > "$APP_DIR/.env" <<EOF
DATABASE_URL="file:./prod.db"
ADMIN_PIN="$PIN"
ADMIN_SECRET="$(openssl rand -hex 32)"
NEXT_PUBLIC_SITE_URL="https://$DOMAIN"
SITE_URL="https://$DOMAIN"
EOF
else
  sed -i -E "s#^NEXT_PUBLIC_SITE_URL=.*#NEXT_PUBLIC_SITE_URL=\"https://$DOMAIN\"#; s#^SITE_URL=.*#SITE_URL=\"https://$DOMAIN\"#" "$APP_DIR/.env"
fi
chown -R "$APP_USER:$APP_USER" "$APP_DIR"
chmod 600 "$APP_DIR/.env"

as_app() { runuser -u "$APP_USER" -- bash -c "cd '$APP_DIR' && $1"; }

say "Ставлю зависимости (пара минут)"
as_app "npm ci --no-audit --no-fund"

say "Готовлю базу данных"
as_app "npx prisma db push --skip-generate"
# Приводим ключи занятости времени к текущему правилу (безопасно при каждом обновлении).
as_app "node scripts/backfill-slot-keys.mjs"
if [ "$FIRST_RUN" -eq 1 ]; then
  say "Наполняю базу демо-данными (начинки, галерея, расписание, тестовые заказы)"
  as_app "npx prisma db seed"
fi
# Тексты сайта и категории галереи по умолчанию (один раз; правки кондитера не трогает).
as_app "node scripts/ensure-defaults.mjs"

say "Собираю сайт (3–5 минут)"
as_app "NEXT_TELEMETRY_DISABLED=1 npm run build"

# ——— Служба ———
say "Запускаю сайт как службу"
NPM_BIN="$(command -v npm)"
cat > /etc/systemd/system/mira.service <<EOF
[Unit]
Description=Mira cakes (Next.js)
After=network.target

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=$APP_DIR
Environment=NODE_ENV=production
Environment=NEXT_TELEMETRY_DISABLED=1
Environment=TZ=$SITE_TZ
ExecStart=$NPM_BIN run start -- -H 127.0.0.1 -p $PORT
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable mira >/dev/null 2>&1
systemctl restart mira

# ——— HTTPS ———
SERVER_IP="$(hostname -I | awk '{print $1}')"
cat > /etc/caddy/Caddyfile <<EOF
$DOMAIN {
	encode zstd gzip
	request_body {
		max_size 20MB
	}
	reverse_proxy 127.0.0.1:$PORT {
		header_up X-Real-IP {remote_host}
	}
}

# Заход по голому IP перенаправляем на адрес с HTTPS.
http://$SERVER_IP {
	redir https://$DOMAIN{uri} permanent
}
EOF
caddy fmt --overwrite /etc/caddy/Caddyfile >/dev/null 2>&1 || true
systemctl enable caddy >/dev/null 2>&1
systemctl restart caddy

# ——— Ежедневные копии и уборка ———
cat > /etc/cron.d/mira <<EOF
# Резервная копия базы и фото каждую ночь, хранится 14 дней.
30 3 * * * root mkdir -p /var/backups/mira && sqlite3 $APP_DIR/prisma/prod.db ".backup '/var/backups/mira/prod-\$(date +\%F).db'" && tar -czf /var/backups/mira/uploads-\$(date +\%F).tar.gz -C $APP_DIR uploads && find /var/backups/mira -type f -mtime +14 -delete
# Удаляем фото, которые клиенты загрузили, но так и не отправили заявку (старше суток).
0 4 * * * $APP_USER cd $APP_DIR && node scripts/cleanup-uploads.mjs --apply --hours=24 >/dev/null 2>&1
EOF
chmod 644 /etc/cron.d/mira

# ——— Проверка ———
say "Жду, пока сайт запустится"
for i in $(seq 1 30); do
  if curl -fsS -o /dev/null "http://127.0.0.1:$PORT/"; then break; fi
  sleep 2
done
curl -fsS -o /dev/null "http://127.0.0.1:$PORT/" || die "сайт не ответил — посмотрите журнал: journalctl -u mira -n 80"

say "Жду HTTPS-сертификат"
HTTPS_OK=0
for i in $(seq 1 30); do
  if curl -fsS -o /dev/null --resolve "$DOMAIN:443:127.0.0.1" "https://$DOMAIN/"; then HTTPS_OK=1; break; fi
  sleep 3
done

printf '\n\033[1;32m%s\033[0m\n' "Готово!"
echo "Сайт для клиентов:   https://$DOMAIN"
echo "Кабинет кондитера:   https://$DOMAIN/admin"
if [ -n "$PIN" ]; then
  echo "PIN кабинета:        $PIN   (сохраните его; он хранится в $APP_DIR/.env)"
else
  echo "PIN кабинета не менялся — он в $APP_DIR/.env (ADMIN_PIN)"
fi
[ "$HTTPS_OK" -eq 1 ] || echo "HTTPS ещё не готов — подождите минуту. Если не появится: journalctl -u caddy -n 50"
echo
echo "Полезное:  systemctl status mira  ·  journalctl -u mira -f  ·  резервные копии: /var/backups/mira"
