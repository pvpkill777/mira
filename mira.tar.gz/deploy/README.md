# Запуск на сервере — коротко

Сервер: **31.58.118.148** (Ubuntu или Debian, вход под root).
Адрес сайта без домена: **https://31-58-118-148.sslip.io** — бесплатный адрес, который сам указывает на IP сервера; HTTPS-сертификат выпускается автоматически.

## 1. Загрузить два файла на сервер

С компьютера, с которого работает SSH до сервера, из папки проекта:

```bash
scp deploy/mira.tar.gz deploy/setup-server.sh root@31.58.118.148:/root/
```

Или любым SFTP-клиентом (WinSCP, FileZilla): положить `mira.tar.gz` и `setup-server.sh` в папку `/root/`.

## 2. Запустить установку

```bash
ssh root@31.58.118.148
```

```bash
bash /root/setup-server.sh /root/mira.tar.gz
```

Скрипт сам:
- поставит Node.js 22, Caddy (веб-сервер с автоматическим HTTPS) и sqlite3; на сервере с памятью меньше 2 ГБ добавит swap;
- распакует проект в `/opt/mira`, создаст `.env` со случайным `ADMIN_SECRET` и **новым 6-значным PIN**;
- создаст базу и наполнит её демо-данными, соберёт сайт;
- запустит сайт как службу `mira` (поднимается сама после перезагрузки сервера);
- настроит HTTPS для `31-58-118-148.sslip.io` и редирект с голого IP;
- включит ночные резервные копии базы и фото в `/var/backups/mira` (14 дней) и уборку брошенных фото.

Займёт 5–10 минут. В конце будут адрес сайта, адрес кабинета и **PIN — сохраните его**.

## Если SSH с компьютера не работает (например, мешает VPN)

Сервер может сам скачать проект — нужна только веб-консоль в панели хостинга.

1. На github.com: **New repository** → имя `mira` → **Public** → **Create** → ссылка **uploading an existing file** → перетащите `deploy/mira.tar.gz` → **Commit changes**.
2. В веб-консоли хостинга (вход под root) — одна команда, `ЛОГИН` замените на свой логин GitHub:

```bash
cd /root && curl -fLo mira.tar.gz https://github.com/ЛОГИН/mira/raw/main/mira.tar.gz && tar -xzf mira.tar.gz deploy/setup-server.sh && bash deploy/setup-server.sh /root/mira.tar.gz
```

3. Когда установка закончится, удалите репозиторий (Settings → Delete this repository) — архив больше не нужен. Секретов в нём нет: `.env`, база и фото в архив не входят.

## 3. Проверить

Откройте https://31-58-118-148.sslip.io с телефона, соберите торт, отправьте тестовую заявку и найдите её в кабинете `/admin`.

## Обновление сайта

Собрать новый архив на компьютере (команда в разделе ниже), снова загрузить оба файла и запустить ту же команду. База, загруженные фото и `.env` сохраняются, перед обновлением делается копия базы.

```bash
tar -czf deploy/mira.tar.gz src prisma/schema.prisma prisma/seed.ts public scripts uploads/.gitkeep package.json package-lock.json next.config.ts tsconfig.json postcss.config.mjs README.md DEPLOY.md .env.example
```

## Когда появится домен

1. В панели регистратора создайте A-запись домена → `31.58.118.148`.
2. На сервере: `bash /root/setup-server.sh /root/mira.tar.gz ваш-домен.ru`

Скрипт пересоберёт сайт под новый адрес и выпустит для него сертификат.

## Если что-то пошло не так

| Что | Команда на сервере |
|---|---|
| Состояние сайта | `systemctl status mira` |
| Журнал сайта | `journalctl -u mira -n 100` |
| Журнал HTTPS / Caddy | `journalctl -u caddy -n 50` |
| Перезапустить сайт | `systemctl restart mira` |
| Узнать PIN кабинета | `grep ADMIN_PIN /opt/mira/.env` (если PIN не меняли в кабинете) |
| Забыли PIN, заданный в кабинете | `cd /opt/mira && runuser -u mira -- node scripts/reset-pin.mjs` — снова действует PIN из `.env` |
| Сменить PIN | поправить `ADMIN_PIN` в `/opt/mira/.env`, затем `systemctl restart mira` |

## Безопасность — сделать после запуска

- **Смените пароль root** (`passwd`) — старый был отправлен в переписке.
- Лучше перейти на вход по SSH-ключу и отключить вход по паролю (`PasswordAuthentication no` в `/etc/ssh/sshd_config`). Делайте это, только убедившись, что вход по ключу работает, иначе можно потерять доступ к серверу.
