import type { NextConfig } from "next";

const isDev = process.env.NODE_ENV !== "production";

// Content-Security-Policy с nonce выставляет src/middleware.ts — на каждый запрос страницы свой.
const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()" },
  { key: "Cross-Origin-Opener-Policy", value: "same-origin" },
  ...(isDev ? [] : [{ key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains" }]),
];

const nextConfig: NextConfig = {
  poweredByHeader: false,
  // Отдельная папка сборки позволяет запускать несколько dev-серверов параллельно.
  distDir: process.env.NEXT_DIST_DIR || ".next",
  experimental: {
    // По умолчанию middleware обрезает тело запроса на 10 МБ — фото с телефона (10–15 МБ) терялись
    // с ошибкой «Файл не получен». Лимиты по каждому адресу проверяются в src/middleware.ts.
    middlewareClientMaxBodySize: "16mb",
  },
  // Браузеры и превью ссылок по привычке запрашивают /favicon.ico — отдаём им PNG-иконку.
  async rewrites() {
    return [{ source: "/favicon.ico", destination: "/icons/favicon-32.png" }];
  },
  async headers() {
    return [
      { source: "/:path*", headers: securityHeaders },
      {
        // Кабинет и его API не должны оседать ни в каких кешах.
        source: "/admin/:path*",
        headers: [{ key: "Cache-Control", value: "no-store" }, { key: "X-Robots-Tag", value: "noindex, nofollow" }],
      },
      { source: "/admin", headers: [{ key: "Cache-Control", value: "no-store" }, { key: "X-Robots-Tag", value: "noindex, nofollow" }] },
      { source: "/api/admin/:path*", headers: [{ key: "Cache-Control", value: "no-store" }] },
      {
        source: "/sw.js",
        headers: [
          { key: "Cache-Control", value: "no-cache, no-store, must-revalidate" },
          { key: "Service-Worker-Allowed", value: "/" },
        ],
      },
    ];
  },
};

export default nextConfig;
