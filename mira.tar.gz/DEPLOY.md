# Запуск в продакшене

> **Быстрый путь:** скрипт [`deploy/setup-server.sh`](deploy/setup-server.sh) делает всё ниже автоматически (Node.js, Caddy с HTTPS, служба systemd, `.env` с новым PIN, резервные копии). Инструкция на одну страницу — [`deploy/README.md`](deploy/README.md). Ручная схема с nginx — ниже.

Приложение хранит данные **локально на диске**: база SQLite (`prisma/dev.db` или путь из `DATABASE_URL`) и фото в папке `uploads/`. Поэтому ему нужен сервер с постоянным диском — обычный VPS. Ниже — проверенная схема: Node.js + pm2 (или systemd) + nginx с HTTPS.

## 1. Сервер

- VPS с Ubuntu 22.04/24.04, 1 vCPU и 1 ГБ RAM достаточно (для `npm run build` при 1 ГБ добавьте swap 1–2 ГБ).
- Node.js **20 LTS или новее** (`node -v`), git, nginx, certbot.
- Домен с A-записью на IP сервера.

```bash
sudo apt update && sudo apt install -y nginx git
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs
sudo adduser --disabled-password --gecos "" mira   # отдельный пользователь без sudo
```

## 2. Код и настройки

```bash
sudo -iu mira
git clone <адрес репозитория> app && cd app
cp .env.example .env
nano .env
```

В `.env` обязательно:

- `ADMIN_PIN` — новый PIN (не `2580`), лучше 6+ цифр;
- `ADMIN_SECRET` — случайная строка: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`. С заглушкой из примера вход в кабинет в production отключён;
- `NEXT_PUBLIC_SITE_URL=https://ваш-домен.ru` — без слеша в конце. Значение встраивается при сборке: после смены нужен `npm run build`;
- `DATABASE_URL` — можно оставить `file:./dev.db` (файл `prisma/dev.db`) или вынести базу из папки проекта: `file:/var/lib/mira/mira.db`.

```bash
chmod 600 .env
npm ci                 # ставит зависимости строго по package-lock.json, заодно prisma generate
npx prisma db push     # создаёт таблицы по схеме (на новой, пустой базе)
npm run db:seed        # ТОЛЬКО для первого запуска: демо-каталог и настройки, потом правьте в кабинете
npm run build
```

> Демо-данные содержат тестовые заказы — после первого входа в кабинет удалите их или отмените, поправьте настройки (имя, контакты, адрес), каталог и галерею.

## 3. Запуск процесса

Приложение должно работать **одним процессом**: защита от перебора PIN хранит счётчики в памяти, а SQLite не рассчитан на запись из нескольких процессов. Не используйте cluster-режим pm2.

### Вариант А: pm2

```bash
sudo npm i -g pm2
cd ~/app
pm2 start npm --name mira -- start -- -p 3000 -H 127.0.0.1
pm2 save
pm2 startup systemd    # выполните команду, которую он напечатает (с sudo)
```

Логи: `pm2 logs mira`, перезапуск: `pm2 restart mira`.

### Вариант Б: systemd

`/etc/systemd/system/mira.service`:

```ini
[Unit]
Description=Mira cakes (Next.js)
After=network.target

[Service]
User=mira
WorkingDirectory=/home/mira/app
Environment=NODE_ENV=production
ExecStart=/usr/bin/npm start -- -p 3000 -H 127.0.0.1
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload && sudo systemctl enable --now mira
journalctl -u mira -f
```

## 4. nginx и HTTPS

`/etc/nginx/sites-available/mira`:

```nginx
server {
    listen 80;
    server_name ваш-домен.ru www.ваш-домен.ru;

    # Фото дизайна от клиента — до ~12 МБ, фото кондитера в кабинете — до 15 МБ.
    # Без этой строки nginx отдаст 413 на любой файл больше 1 МБ.
    client_max_body_size 20m;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Host $host;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_read_timeout 60s;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/mira /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d ваш-домен.ru -d www.ваш-домен.ru   # сертификат Let's Encrypt и редирект на HTTPS
```

Certbot сам продлевает сертификат (`systemctl list-timers | grep certbot`). HTTPS обязателен: без него не работают Service Worker и установка на телефон.

Проверка после запуска:

- `https://ваш-домен.ru/robots.txt`, `/sitemap.xml`, `/manifest.webmanifest`, `/og.png` открываются;
- превью ссылки — через @WebpageBot в Telegram (он же сбрасывает кеш превью) и отладчик Facebook для Instagram;
- вход в `/admin` новым PIN.

## 5. Резервное копирование

Бэкапить нужно **две вещи**: базу SQLite и папку `uploads/` (фото-референсы клиентов и фото галереи). `.env` храните отдельно в менеджере паролей.

Простой ежедневный скрипт `/home/mira/backup.sh`:

```bash
#!/bin/sh
set -e
APP=/home/mira/app
DST=/home/mira/backups
STAMP=$(date +%F)
mkdir -p "$DST"
# .backup делает согласованную копию даже во время записи (нужен пакет sqlite3)
sqlite3 "$APP/prisma/dev.db" ".backup '$DST/db-$STAMP.db'"
tar -czf "$DST/uploads-$STAMP.tar.gz" -C "$APP" uploads
# храним 14 дней
find "$DST" -type f -mtime +14 -delete
```

```bash
sudo apt install -y sqlite3
chmod +x ~/backup.sh
crontab -e     # добавить строку:
# 30 3 * * * /home/mira/backup.sh
```

Копии на том же диске не спасут при потере сервера — раз в день отправляйте папку `backups/` наружу (rclone в облачное хранилище, `rsync` на другой сервер, снимки диска у хостера).

Восстановление: остановить приложение, положить файл базы на место `prisma/dev.db` (или путь из `DATABASE_URL`), распаковать `uploads`, запустить.

## 6. Смена PIN и ключа

1. Отредактировать `ADMIN_PIN` и/или `ADMIN_SECRET` в `.env`.
2. Перезапустить процесс: `pm2 restart mira` или `sudo systemctl restart mira`. Пересборка не нужна.

Смена любого из двух значений завершает все открытые сессии кабинета.

## 7. Обновление

```bash
cd ~/app
~/backup.sh                 # сначала копия
git pull
npm ci
npx prisma db push          # если менялась schema.prisma; без --force-reset!
npm run build
pm2 restart mira            # или sudo systemctl restart mira
```

- Никогда не запускайте на рабочем сервере `npm run db:reset` и `npm run setup` — они стирают или перезаписывают данные.
- Если `prisma db push` предупреждает о потере данных — остановитесь и разберитесь (сделайте бэкап, проверьте миграцию).
- При обновлении со старой версии без запрета двойной записи один раз выполните `node scripts/backfill-slot-keys.mjs`.
- Service Worker сам подхватит новую версию; если менялась логика кеша, в `public/sw.js` повышают `VERSION`.

## 8. Почему не Vercel и другой serverless

- **SQLite** — это файл на диске. В serverless у функций нет постоянного диска: файловая система доступна только для чтения или сбрасывается при каждом холодном старте, а несколько экземпляров функции не видят общий файл. Заказы будут теряться или не сохранятся вовсе.
- **Загрузки фото** пишутся в `uploads/` на диск — по той же причине они исчезнут.
- **Защита от перебора PIN** хранит счётчики в памяти процесса, а в serverless процессов много и они короткоживущие.

Если serverless всё же нужен, придётся переделать хранение (это изменения кода и схемы, их нужно планировать отдельно):

1. База — перейти на облачную: PostgreSQL (Neon, Supabase, Vercel Postgres) сменой `provider` в `schema.prisma`, либо Turso/libSQL (совместим с SQLite) через driver adapter Prisma.
2. Фото — хранить в объектном хранилище (S3-совместимое, Cloudflare R2, Vercel Blob) вместо `uploads/` и отдавать оттуда же.
3. Лимит попыток входа — вынести в общее хранилище (Redis/Upstash) или в базу.

Пока этого не сделано, используйте VPS (или любой хостинг с постоянным диском и долгоживущим Node-процессом: Docker на VPS, Railway/Render/Fly.io с подключённым томом).
