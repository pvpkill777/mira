import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const img = (id: string, w = 900) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=80`;

const pad = (n: number) => n.toString().padStart(2, "0");
const key = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const plusDays = (n: number) => {
  const d = new Date();
  d.setHours(12, 0, 0, 0);
  d.setDate(d.getDate() + n);
  return d;
};
/** n-й рабочий день от сегодняшнего (понедельник — выходной). */
const workingDay = (n: number) => {
  let offset = 0;
  let found = 0;
  while (true) {
    offset++;
    if (plusDays(offset).getDay() !== 1) found++;
    if (found === n) return key(plusDays(offset));
  }
};

async function main() {
  console.log("Очищаю базу…");
  await prisma.$transaction([
    prisma.order.deleteMany(),
    prisma.galleryItem.deleteMany(),
    prisma.dayOverride.deleteMany(),
    prisma.decor.deleteMany(),
    prisma.filling.deleteMany(),
    prisma.size.deleteMany(),
    prisma.settings.deleteMany(),
  ]);

  await prisma.settings.create({
    data: {
      id: 1,
      brandName: "Мира",
      ownerName: "Мира Орлова",
      tagline: "Авторские торты из 100% натуральных ингредиентов",
      city: "Москва",
      avatarUrl: "",
      heroImageUrl: img("1574340530044-81450c3c5948", 1200),
      telegram: "mira_cakes",
      whatsapp: "79990001122",
      instagram: "mira.cakes",
      pickupAddress: "Москва, Хамовники, ул. Ефремова, 10",
      paymentDetails: "Перевод по номеру +7 999 000-11-22 (Т-Банк, Мира О.)",
      defaultDailyLimit: 3,
      closedWeekdays: "1",
      urgentSurchargePct: 20,
      prepaymentPct: 50,
      deliveryFee: 450,
      timeSlots: "10:00–12:00,12:00–14:00,14:00–16:00,16:00–18:00,18:00–20:00",
      customMinGrams: 1000,
      customMaxGrams: 8000,
      bookingHorizonDays: 60,
    },
  });

  console.log("Размеры…");
  const [bento, medium, festive, large] = await Promise.all([
    prisma.size.create({ data: { name: "Бенто-торт", weightGrams: 450, guestsLabel: "1–2 гостя", fixedPrice: 2400, adjustable: false, sortOrder: 0 } }),
    prisma.size.create({ data: { name: "Средний", weightGrams: 1500, guestsLabel: "6–8 гостей", sortOrder: 1 } }),
    prisma.size.create({ data: { name: "Праздничный", weightGrams: 2500, guestsLabel: "12–15 гостей", sortOrder: 2 } }),
    prisma.size.create({ data: { name: "Большой", weightGrams: 3500, guestsLabel: "18–20 гостей", sortOrder: 3 } }),
  ]);

  console.log("Начинки…");
  const fillingsData = [
    {
      name: "Фисташка — Малина",
      description: "Влажный фисташковый бисквит, малиновое конфи и крем на маскарпоне с чистой фисташковой пастой. Ореховая глубина и яркая ягодная кислинка.",
      pricePerKg: 3200,
      imageUrl: img("1761637604927-e3656dc81383"),
      tags: "Хит",
    },
    {
      name: "Сникерс с солёной карамелью",
      description: "Шоколадный бисквит, тягучая солёная карамель, хрустящий слой жареного арахиса и нуги, лёгкий шоколадный крем.",
      pricePerKg: 2900,
      imageUrl: img("1547414368-ac947d00b91d"),
      tags: "Хит",
    },
    {
      name: "Манго — Маракуйя",
      description: "Воздушный ванильный бисквит, мусс из спелого манго и кремю из маракуйи. Свежий, тропический и совсем не приторный.",
      pricePerKg: 3100,
      imageUrl: img("1688458297155-228a3b1e5b49"),
      tags: "Без орехов,Нежный",
    },
    {
      name: "Красный бархат",
      description: "Бархатный какао-бисквит насыщенного цвета со сливочным крем-чизом и ноткой мадагаскарской ванили. Классика, которую любят все.",
      pricePerKg: 2700,
      imageUrl: img("1586788680434-30d324b2d46f"),
      tags: "Без орехов,Классика",
    },
    {
      name: "Медовик с брусникой",
      description: "Тонкие коржи на гречишном мёде, сметанный крем и брусничный конфитюр. Тёплый, домашний вкус с северной кислинкой.",
      pricePerKg: 2600,
      imageUrl: img("1624000961428-eeece184988b"),
      tags: "Без орехов",
    },
    {
      name: "Шоколад — Вишня",
      description: "Шоколадный бисквит на бельгийском какао, пьяная вишня и ганаш на тёмном шоколаде 70%. Для тех, кто любит поглубже.",
      pricePerKg: 2900,
      imageUrl: img("1606890737304-57a1ca8a5b62"),
      tags: "Насыщенный",
    },
  ];
  const fillings = [];
  for (const [i, f] of fillingsData.entries()) {
    fillings.push(await prisma.filling.create({ data: { ...f, sortOrder: i } }));
  }
  const [pistachio, snickers, mango, velvet, honey, choco] = fillings;

  console.log("Декор…");
  const [lettering, berries, chocoDecor, photo] = await Promise.all([
    prisma.decor.create({ data: { name: "Минималистичная надпись кремом", description: "Короткая фраза или имя — тонким почерком", price: 0, sortOrder: 0 } }),
    prisma.decor.create({ data: { name: "Свежие ягоды", description: "Сезонные: клубника, малина, голубика, физалис", price: 600, sortOrder: 1 } }),
    prisma.decor.create({ data: { name: "Шоколадный декор", description: "Сферы, макаронс, шоколадные капли и пластины", price: 800, sortOrder: 2 } }),
    prisma.decor.create({ data: { name: "Сахарная фотопечать", description: "Картинка или фото на съедобной бумаге", price: 500, sortOrder: 3 } }),
  ]);

  console.log("Галерея…");
  const gallery = [
    { title: "Бенто с макаронс", description: "Маленький торт на двоих: пастельный крем и миндальные макаронс.", imageUrl: img("1562440499-64c9a111f713"), category: "bento", weightGrams: 450, sizeId: bento.id, fillingId: pistachio.id, decorIds: [chocoDecor.id] },
    { title: "Бенто с голубикой", description: "Лавандовый крем, свежая голубика и надпись тонким кремом.", imageUrl: img("1653469742883-c47111ae3bc4"), category: "bento", weightGrams: 450, sizeId: bento.id, fillingId: velvet.id, decorIds: [berries.id, lettering.id] },
    { title: "Белый с бенгальским огнём", description: "Гладкий крем, ничего лишнего — только форма и вкус.", imageUrl: img("1640506054499-2b040ca19023"), category: "minimal", weightGrams: 1500, sizeId: medium.id, fillingId: mango.id, decorIds: [lettering.id] },
    { title: "Пудровый с цветами", description: "Нежная текстура крема и пара живых акцентов.", imageUrl: img("1557308536-ee471ef2c390"), category: "minimal", weightGrams: 2000, sizeId: medium.id, fillingId: snickers.id, decorIds: [lettering.id] },
    { title: "Ежевика и сирень", description: "Белый крем, ежевика и съедобные цветы.", imageUrl: img("1559620192-032c4bc4674e"), category: "berries", weightGrams: 2000, sizeId: medium.id, fillingId: choco.id, decorIds: [berries.id] },
    { title: "Малиновое облако", description: "Сливочный крем и много свежей малины.", imageUrl: img("1557925923-33b27f891f88"), category: "berries", weightGrams: 2500, sizeId: festive.id, fillingId: pistachio.id, decorIds: [berries.id] },
    { title: "Ягодный ярус", description: "Высокий торт с клубникой и голубикой.", imageUrl: img("1535141192574-5d4897c12636"), category: "berries", weightGrams: 3500, sizeId: large.id, fillingId: velvet.id, decorIds: [berries.id, chocoDecor.id] },
    { title: "Свадебный с клубникой", description: "Нежный белый торт с цветами и ягодами.", imageUrl: img("1623428454614-abaf00244e52"), category: "wedding", weightGrams: 5000, sizeId: large.id, fillingId: mango.id, decorIds: [berries.id] },
    { title: "Классика в цветах", description: "Многоярусный торт для большого дня.", imageUrl: img("1525257831700-183b9b8bf5c4"), category: "wedding", weightGrams: 6000, sizeId: large.id, fillingId: honey.id, decorIds: [chocoDecor.id] },
  ];
  for (const [i, g] of gallery.entries()) {
    await prisma.galleryItem.create({ data: { ...g, decorIds: g.decorIds.join(","), sortOrder: i } });
  }

  console.log("Расписание на месяц…");
  const overrides = [
    { date: key(plusDays(5)), closed: true, note: "Мест нет" },
    { date: key(plusDays(6)), closed: true, note: "Мест нет" },
    { date: key(plusDays(13)), closed: true, note: "Мастер-класс" },
    { date: key(plusDays(9)), closed: false, limit: 1, note: "Свадебный заказ" },
    { date: key(plusDays(17)), closed: false, limit: 4, note: "" },
    { date: key(plusDays(24)), closed: true, note: "Выходной" },
  ];
  for (const o of overrides) {
    await prisma.dayOverride.upsert({ where: { date: o.date }, create: o, update: o });
  }

  console.log("Тестовые заказы…");
  const mk = (n: number, data: Record<string, unknown>) => ({ number: n, ...data });
  const orders = [
    mk(1001, {
      status: "CONFIRMED",
      date: workingDay(1),
      timeSlot: "14:00–16:00",
      delivery: false,
      customerName: "Анна",
      phone: "+7 (916) 555-12-34",
      contact: "@anna_k",
      inscription: "С днём рождения, мама",
      wishes: "Без сильного запаха алкоголя, пожалуйста",
      sizeId: medium.id,
      sizeName: "Средний",
      weightGrams: 1500,
      fillingId: pistachio.id,
      fillingName: pistachio.name,
      decorJson: JSON.stringify([{ name: lettering.name, price: 0 }, { name: berries.name, price: 600 }]),
      urgent: false,
      basePrice: 4800,
      decorTotal: 600,
      urgentFee: 0,
      deliveryFee: 0,
      total: 5400,
      prepayment: 2700,
    }),
    mk(1002, {
      status: "NEW",
      date: workingDay(2),
      timeSlot: "18:00–20:00",
      delivery: true,
      address: "ул. Остоженка, 25, кв. 14",
      customerName: "Дмитрий",
      phone: "+7 (903) 222-45-67",
      contact: "@dmitry.photo",
      inscription: "",
      wishes: "Сюрприз для жены — позвоните перед доставкой",
      sizeId: bento.id,
      sizeName: "Бенто-торт",
      weightGrams: 450,
      fillingId: velvet.id,
      fillingName: velvet.name,
      decorJson: JSON.stringify([{ name: photo.name, price: 500 }]),
      urgent: false,
      basePrice: 2400,
      decorTotal: 500,
      urgentFee: 0,
      deliveryFee: 450,
      total: 3350,
      prepayment: 1680,
    }),
    mk(1003, {
      status: "NEW",
      date: workingDay(3),
      timeSlot: "12:00–14:00",
      delivery: false,
      customerName: "Екатерина",
      phone: "+7 (925) 777-88-99",
      contact: "@katya_events",
      inscription: "Саше 5 лет!",
      wishes: "Ребёнок не ест орехи",
      sizeId: festive.id,
      sizeName: "Праздничный",
      weightGrams: 2500,
      fillingId: mango.id,
      fillingName: mango.name,
      decorJson: JSON.stringify([{ name: chocoDecor.name, price: 800 }, { name: lettering.name, price: 0 }]),
      urgent: false,
      basePrice: 7750,
      decorTotal: 800,
      urgentFee: 0,
      deliveryFee: 0,
      total: 8550,
      prepayment: 4280,
    }),
    // Выполненные заказы — чтобы в аналитике сразу была выручка.
    mk(998, {
      status: "DONE",
      date: key(plusDays(-2)),
      timeSlot: "16:00–18:00",
      customerName: "Ольга",
      phone: "+7 (915) 101-20-30",
      contact: "@olga.m",
      sizeId: large.id,
      sizeName: "Большой",
      weightGrams: 3500,
      fillingId: snickers.id,
      fillingName: snickers.name,
      decorJson: JSON.stringify([{ name: chocoDecor.name, price: 800 }]),
      basePrice: 10150,
      decorTotal: 800,
      urgentFee: 0,
      deliveryFee: 0,
      total: 10950,
      prepayment: 5480,
    }),
    mk(999, {
      status: "DONE",
      date: key(plusDays(-1)),
      timeSlot: "10:00–12:00",
      customerName: "Игорь",
      phone: "+7 (926) 404-50-60",
      contact: "",
      sizeId: medium.id,
      sizeName: "Средний",
      weightGrams: 1500,
      fillingId: honey.id,
      fillingName: honey.name,
      decorJson: JSON.stringify([]),
      basePrice: 3900,
      decorTotal: 0,
      urgentFee: 0,
      deliveryFee: 0,
      total: 3900,
      prepayment: 1950,
    }),
  ];
  for (const o of orders) {
    const r = o as unknown as { status: string; date: string; timeSlot: string };
    // Время держат только активные заказы (как в кабинете и на сайте).
    const slotKey = r.status === "NEW" || r.status === "CONFIRMED" ? `${r.date}|${r.timeSlot}` : null;
    await prisma.order.create({ data: { ...o, slotKey } as never });
  }

  console.log("Готово: 4 размера, 6 начинок, 4 опции декора, 9 работ в галерее, 6 особых дней, 5 заказов.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
