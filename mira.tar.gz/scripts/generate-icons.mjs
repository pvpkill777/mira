// Генерирует PNG-иконки PWA из векторной монограммы (без шрифтов — только пути).
import sharp from "sharp";
import { mkdir } from "node:fs/promises";
import path from "node:path";

const out = path.join(process.cwd(), "public", "icons");
await mkdir(out, { recursive: true });

const mark = (scale = 1) => {
  const t = (v) => 256 + (v - 256) * scale;
  const sw = 26 * scale;
  return `
    <circle cx="256" cy="256" r="${170 * scale}" fill="none" stroke="#231F1E" stroke-opacity="0.18" stroke-width="${3 * scale}"/>
    <path d="M ${t(166)} ${t(338)} L ${t(166)} ${t(196)} L ${t(256)} ${t(300)} L ${t(346)} ${t(196)} L ${t(346)} ${t(338)}"
      fill="none" stroke="#231F1E" stroke-width="${sw}" stroke-linecap="square" stroke-linejoin="miter"/>
    <line x1="${t(140)}" y1="${t(370)}" x2="${t(372)}" y2="${t(370)}" stroke="#231F1E" stroke-width="${4 * scale}"/>
    <circle cx="256" cy="${t(150)}" r="${17 * scale}" fill="#B86B4B"/>`;
};

const svg = (scale, rounded) => `
<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
  <rect width="512" height="512" rx="${rounded ? 112 : 0}" fill="#FAF7F2"/>
  ${mark(scale)}
</svg>`;

const render = (s, size, file) => sharp(Buffer.from(s)).resize(size, size).png().toFile(path.join(out, file));

await render(svg(1, false), 512, "icon-512.png");
await render(svg(1, false), 192, "icon-192.png");
await render(svg(0.72, false), 512, "maskable-512.png");
await render(svg(0.9, false), 180, "apple-touch-icon.png");
await render(svg(1.15, true), 32, "favicon-32.png");
console.log("Иконки сохранены в public/icons");
