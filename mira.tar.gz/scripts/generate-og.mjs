// Генерирует статичную OG-картинку 1200×630 (public/og.png) для превью ссылки в Telegram и Instagram.
// Статичный PNG вместо opengraph-image.tsx: ImageResponse без сети не загрузит шрифт с кириллицей,
// а превью мессенджеры кешируют надолго — проще один раз сгенерировать и положить в public.
// Запуск: node scripts/generate-og.mjs
import sharp from "sharp";
import path from "node:path";

const W = 1200;
const H = 630;
const serif = "'Cormorant Garamond', 'Cormorant', Georgia, 'Times New Roman', serif";
const sans = "Manrope, 'Segoe UI', Arial, sans-serif";

// Монограмма — те же пути, что в scripts/generate-icons.mjs, масштаб под правую часть картинки.
const cx = 930;
const cy = 315;
const k = 0.95;
const t = (x, y) => [cx + (x - 256) * k, cy + (y - 256) * k];
const p = (pts) => pts.map(([x, y]) => t(x, y).join(" ")).join(" L ");

const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <rect width="${W}" height="${H}" fill="#FAF7F2"/>
  <rect x="24" y="24" width="${W - 48}" height="${H - 48}" fill="none" stroke="#231F1E" stroke-opacity="0.14" stroke-width="1.5" rx="28"/>
  <line x1="740" y1="72" x2="740" y2="${H - 72}" stroke="#231F1E" stroke-opacity="0.12" stroke-width="1.5"/>

  <circle cx="${cx}" cy="${cy}" r="${170 * k}" fill="#F2ECE4" stroke="#231F1E" stroke-opacity="0.18" stroke-width="2"/>
  <path d="M ${p([[166, 338], [166, 196], [256, 300], [346, 196], [346, 338]])}" fill="none" stroke="#231F1E" stroke-width="${22 * k}" stroke-linecap="square" stroke-linejoin="miter"/>
  <line x1="${t(140, 370)[0]}" y1="${t(140, 370)[1]}" x2="${t(372, 370)[0]}" y2="${t(372, 370)[1]}" stroke="#231F1E" stroke-width="3"/>
  <circle cx="${cx}" cy="${t(256, 150)[1]}" r="${16 * k}" fill="#B86B4B"/>

  <text x="96" y="132" font-family="${sans}" font-size="20" font-weight="600" letter-spacing="5" fill="#70655F">АВТОРСКАЯ КОНДИТЕРСКАЯ</text>
  <text x="90" y="300" font-family="${serif}" font-size="168" font-weight="500" fill="#231F1E">Мира</text>
  <text x="96" y="380" font-family="${serif}" font-size="54" font-style="italic" fill="#9B5639">торты на заказ</text>
  <line x1="96" y1="436" x2="660" y2="436" stroke="#231F1E" stroke-opacity="0.16" stroke-width="1.5"/>
  <text x="96" y="490" font-family="${sans}" font-size="27" fill="#231F1E">Соберите торт и узнайте точную цену сразу.</text>
  <text x="96" y="532" font-family="${sans}" font-size="27" fill="#70655F">Свободные даты — онлайн.</text>
</svg>`;

const out = path.join(process.cwd(), "public", "og.png");
await sharp(Buffer.from(svg)).png({ compressionLevel: 9 }).toFile(out);
console.log("OG-картинка сохранена в public/og.png");
