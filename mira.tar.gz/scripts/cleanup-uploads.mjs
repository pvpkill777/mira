// Удаляет «осиротевшие» файлы из uploads/: те, на которые не ссылается ни заказ,
// ни галерея, ни начинка, ни настройки, и которые старше N часов.
//
//   node scripts/cleanup-uploads.mjs            — пробный прогон, только список
//   node scripts/cleanup-uploads.mjs --apply    — удалить
//   node scripts/cleanup-uploads.mjs --apply --hours=48
//
// Запускайте по расписанию (cron / Планировщик задач) раз в сутки из корня проекта.
import { readdir, stat, unlink } from "node:fs/promises";
import path from "node:path";
import { PrismaClient } from "@prisma/client";

const args = process.argv.slice(2);
const apply = args.includes("--apply");
const hoursArg = args.find((a) => a.startsWith("--hours="));
const hours = hoursArg ? Number(hoursArg.split("=")[1]) : 24;
if (!Number.isFinite(hours) || hours < 1) {
  console.error("--hours должен быть числом ≥ 1");
  process.exit(1);
}

const UPLOAD_DIR = path.join(process.cwd(), "uploads");
const NAME_RE = /^[a-f0-9-]{36}\.(jpg|png|webp|avif)$/;
const prisma = new PrismaClient();

function collect(set, text) {
  if (!text) return;
  for (const m of String(text).matchAll(/\/api\/media\/([a-f0-9-]{36}\.(?:jpg|png|webp|avif))/g)) set.add(m[1]);
}

try {
  const used = new Set();
  const [orders, gallery, fillings, settings, demos] = await Promise.all([
    prisma.order.findMany({ select: { designPhotos: true } }),
    prisma.galleryItem.findMany({ select: { imageUrl: true } }),
    prisma.filling.findMany({ select: { imageUrl: true } }),
    prisma.settings.findMany({ select: { avatarUrl: true, heroImageUrl: true } }),
    prisma.demo.findMany({ select: { photos: true } }),
  ]);
  for (const d of demos) collect(used, d.photos);
  for (const o of orders) collect(used, o.designPhotos);
  for (const g of gallery) collect(used, g.imageUrl);
  for (const f of fillings) collect(used, f.imageUrl);
  for (const s of settings) {
    collect(used, s.avatarUrl);
    collect(used, s.heroImageUrl);
  }

  let names = [];
  try {
    names = await readdir(UPLOAD_DIR);
  } catch {
    console.log("Папки uploads нет — чистить нечего.");
    process.exit(0);
  }

  const cutoff = Date.now() - hours * 3600_000;
  let removed = 0;
  let freed = 0;
  for (const name of names) {
    if (!NAME_RE.test(name) || used.has(name)) continue;
    const file = path.join(UPLOAD_DIR, name);
    const st = await stat(file).catch(() => null);
    // Свежие файлы не трогаем: клиент мог загрузить фото и ещё не отправить заявку.
    if (!st || !st.isFile() || st.mtimeMs > cutoff) continue;
    removed++;
    freed += st.size;
    if (apply) await unlink(file).catch((e) => console.error(`Не удалось удалить ${name}: ${e.message}`));
    else console.log(`осиротевший: ${name} (${Math.round(st.size / 1024)} КБ)`);
  }
  const mb = (freed / 1024 / 1024).toFixed(1);
  console.log(
    apply
      ? `Удалено файлов: ${removed}, освобождено ${mb} МБ. Используется файлов: ${used.size}.`
      : `Пробный прогон: к удалению ${removed} файлов (${mb} МБ). Запустите с --apply, чтобы удалить.`,
  );
} finally {
  await prisma.$disconnect();
}
