// Один раз записывает в базу тексты сайта и категории галереи, которые раньше были зашиты в коде.
// Безопасно запускать при каждом обновлении: после первого раза ставится флаг Settings.contentSeeded,
// и дальше скрипт ничего не трогает — даже если кондитер удалила все вопросы FAQ намеренно.
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const settings = await prisma.settings.findUnique({ where: { id: 1 } });
if (!settings) {
  console.log("Тексты по умолчанию: настроек ещё нет — пропускаю (сначала нужен seed)");
  await prisma.$disconnect();
  process.exit(0);
}

// Категории галереи нужны всегда: без них работы не во что разложить. Добавляем недостающие из тех,
// что уже используются в работах, плюс стандартные.
const KNOWN = { bento: "Бенто", minimal: "Минимализм", berries: "С ягодами", wedding: "Свадебные" };
const used = (await prisma.galleryItem.findMany({ select: { category: true } })).map((g) => g.category);
const slugs = [...new Set([...Object.keys(KNOWN), ...used])];
let added = 0;
for (const [i, slug] of slugs.entries()) {
  const exists = await prisma.galleryCategory.findUnique({ where: { slug } });
  if (exists) continue;
  if (settings.contentSeeded && !used.includes(slug)) continue; // стандартные — только при первом запуске
  await prisma.galleryCategory.create({ data: { slug, label: KNOWN[slug] ?? slug, sortOrder: i } });
  added++;
}

if (settings.contentSeeded) {
  console.log(`Тексты по умолчанию: уже записаны ранее. Категорий галереи добавлено: ${added}`);
  await prisma.$disconnect();
  process.exit(0);
}

const fillIfEmpty = (cur, value) => (cur && cur.trim() ? cur : value);
await prisma.settings.update({
  where: { id: 1 },
  data: {
    heroTitle: fillIfEmpty(settings.heroTitle, "Авторские торты *из 100% натуральных* ингредиентов"),
    heroSubtitle: fillIfEmpty(
      settings.heroSubtitle,
      "Выберите размер, начинку и декор — цена посчитается сразу. Свободные даты видно в календаре, а заявка займёт пару минут, без переписки в директе.",
    ),
    aboutTitle: fillIfEmpty(settings.aboutTitle, "Каждый торт собираю сама"),
    aboutQuote: fillIfEmpty(settings.aboutQuote, "Торт режут при всех гостях, поэтому он должен быть вкусным не только на фото."),
    aboutText: fillIfEmpty(
      settings.aboutText,
      "Я {имя}. Пеку на заказ и сама отвечаю на каждую заявку: подскажу начинку под ваш праздник и честно скажу, если задумка не сработает.",
    ),
    faqTitle: fillIfEmpty(settings.faqTitle, "Без переписки и сюрпризов"),
    seoTitle: fillIfEmpty(settings.seoTitle, `${settings.brandName} — авторские торты на заказ`),
    seoDescription: fillIfEmpty(
      settings.seoDescription,
      "Соберите торт за минуту: размер, начинка, декор и точная цена сразу. Свободные даты онлайн, заявка без переписки в директе.",
    ),
  },
});

const items = [
  ["step", "Заявка", "Соберите торт, выберите дату и отправьте заявку. Платить на сайте ничего не нужно."],
  ["step", "Подтверждение", "{имя} напишет в течение часа, уточнит детали и пришлёт реквизиты."],
  ["step", "Предоплата {предоплата}", "Она закрепляет дату за вами. Остаток — при получении торта."],
  ["step", "Получение", "Самовывоз или доставка в выбранный интервал."],
  [
    "faq",
    "За сколько дней нужно заказывать?",
    "Чем раньше, тем больше выбор: календарь открыт на {горизонт} вперёд, и все свободные даты видны сразу. Если торт нужен меньше чем через сутки — выберите ближайший свободный интервал, срочность добавит {срочность} к цене.",
  ],
  [
    "faq",
    "Как устроена предоплата?",
    "После подтверждения деталей пришлём реквизиты, предоплата — {предоплата} от суммы. Пока её нет, дата не закреплена и может уйти другому заказу. Остаток оплачивается при получении.",
  ],
  ["faq", "Можно перенести дату или изменить заказ?", "Да, если в календаре есть свободный день — просто напишите заранее. Начинку и декор можно поменять, пока не начали печь бисквиты."],
  ["faq", "Что с аллергиями и составом?", "Напишите об аллергии в поле «Пожелания» — подберём начинку. Начинки без орехов отмечены в меню, точный состав пришлём по запросу."],
  ["faq", "Как работает доставка?", "Привезём по городу ({город}) в выбранный интервал, стоимость — {доставка}. Самовывоз бесплатный: {адрес}."],
  ["faq", "Как хранить торт?", "В холодильнике при +2…+6 °C, в коробке. Достаньте за 30–40 минут до подачи — так крем и начинка раскроют вкус. Лучше съесть в течение двух суток."],
  ["principle", "Только натуральное", "Сливочное масло 82%, сливки 33%, бельгийский шоколад. Без растительных жиров и готовых смесей."],
  ["principle", "Свежая выпечка к дате", "Бисквиты пеку под конкретный заказ, а не достаю из морозилки."],
  ["principle", "Немного заказов в день", "Поэтому даты в календаре заканчиваются — зато у каждого торта есть время."],
];
const counters = {};
for (const [kind, title, text] of items) {
  if ((await prisma.contentItem.count({ where: { kind } })) > 0 && !(kind in counters)) {
    counters[kind] = -1; // такие тексты уже есть — не дублируем
    continue;
  }
  if (counters[kind] === -1) continue;
  counters[kind] = (counters[kind] ?? -1) + 1;
  await prisma.contentItem.create({ data: { kind, title, text, sortOrder: counters[kind] } });
}

await prisma.settings.update({ where: { id: 1 }, data: { contentSeeded: true } });
console.log(`Тексты по умолчанию записаны. Категорий галереи добавлено: ${added}`);
await prisma.$disconnect();
