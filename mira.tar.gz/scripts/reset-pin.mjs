// Сброс PIN, заданного в кабинете, если его забыли. После сброса снова действует ADMIN_PIN из .env,
// а все открытые сессии кабинета завершаются.
// На сервере:  cd /opt/mira && runuser -u mira -- node scripts/reset-pin.mjs
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
await prisma.settings.update({
  where: { id: 1 },
  data: { adminPinHash: "", adminPinLength: 0, sessionsRevokedAt: Math.floor(Date.now() / 1000) },
});
console.log("PIN из кабинета сброшен. Войдите с PIN из файла .env (строка ADMIN_PIN).");
await prisma.$disconnect();
