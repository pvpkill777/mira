// Приводит ключи занятости времени (slotKey) в порядок. Безопасно запускать сколько угодно раз —
// скрипт установки делает это при каждом обновлении.
//  1) Время держат только активные заказы (NEW, CONFIRMED). У выполненных и отменённых ключ снимается:
//     иначе интервал выглядел бы на сайте свободным, а заявка на него получала бы отказ.
//  2) Активным заказам без ключа ключ проставляется. Если на одно время уже несколько активных
//     заказов, ключ получает самый ранний, остальные остаются без ключа — кабинет покажет конфликт.
import { PrismaClient } from "@prisma/client";

const ACTIVE = ["NEW", "CONFIRMED"];
const prisma = new PrismaClient();

const released = await prisma.order.updateMany({
  where: { slotKey: { not: null }, status: { notIn: ACTIVE } },
  data: { slotKey: null },
});

const orders = await prisma.order.findMany({ where: { slotKey: null, status: { in: ACTIVE } }, orderBy: { createdAt: "asc" } });
const conflicts = [];
let assigned = 0;
for (const o of orders) {
  const key = `${o.date}|${o.timeSlot}`;
  const taken = await prisma.order.findUnique({ where: { slotKey: key } });
  if (taken) conflicts.push(`№${o.number} пересекается с №${taken.number} (${o.date}, ${o.timeSlot})`);
  else {
    await prisma.order.update({ where: { id: o.id }, data: { slotKey: key } });
    assigned++;
  }
}
console.log(`Ключи времени: освобождено ${released.count}, проставлено ${assigned}, конфликтов ${conflicts.length}`);
for (const c of conflicts) console.log("  " + c);
await prisma.$disconnect();
