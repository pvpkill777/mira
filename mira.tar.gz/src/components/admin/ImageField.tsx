"use client";

import { ImagePlus, Loader2 } from "lucide-react";
import { useRef, useState } from "react";
import { Labeled, inputCls, useNotify } from "./ui";

/** Фото: загрузка файла с телефона или ссылка (например, Unsplash). */
export function ImageField({ value, onChange, label = "Фото" }: { value: string; onChange: (url: string) => void; label?: string }) {
  const notify = useNotify();
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const upload = async (file: File) => {
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) notify(data.error ?? "Фото не загрузилось. Попробуйте ещё раз.", "error");
      else onChange(data.url);
    } catch {
      notify("Нет соединения — фото не загрузилось.", "error");
    } finally {
      setUploading(false);
    }
  };

  return (
    <Labeled label={label}>
      <div className="flex items-center gap-2">
        {value ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={value} alt="" className="h-[46px] w-[46px] shrink-0 rounded-[10px] object-cover" />
        ) : null}
        <input className={`${inputCls} min-w-0 flex-1`} value={value} onChange={(e) => onChange(e.target.value)} placeholder="Ссылка на фото или загрузите →" />
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="btn-ghost h-11 w-11 shrink-0 !p-0"
          aria-label="Загрузить фото с устройства"
          title="Загрузить фото"
        >
          {uploading ? <Loader2 size={16} className="animate-spin" /> : <ImagePlus size={16} strokeWidth={1.5} />}
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/avif"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) upload(f);
            e.target.value = "";
          }}
        />
      </div>
    </Labeled>
  );
}
