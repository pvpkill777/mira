"use client";

import { ChevronDown, ChevronLeft, ChevronRight, ChevronUp } from "lucide-react";
import { useApi } from "./ui";

/** Перестановка позиции списка: отправляет на сервер весь новый порядок одним запросом. */
export function useReorder(entity: string) {
  const { call, pending } = useApi();
  const move = (ids: string[], index: number, dir: -1 | 1) => {
    const to = index + dir;
    if (to < 0 || to >= ids.length) return;
    const next = [...ids];
    [next[index], next[to]] = [next[to], next[index]];
    return call("PUT", `/api/admin/entities/${entity}`, { ids: next });
  };
  return { move, pending };
}

/** Кнопки «выше/ниже» (или «раньше/позже» для сетки), 44 × 44. */
export function MoveButtons({
  index,
  count,
  name,
  onMove,
  disabled,
  horizontal,
}: {
  index: number;
  count: number;
  name: string;
  onMove: (dir: -1 | 1) => void;
  disabled?: boolean;
  horizontal?: boolean;
}) {
  const Prev = horizontal ? ChevronLeft : ChevronUp;
  const Next = horizontal ? ChevronRight : ChevronDown;
  const prevLabel = horizontal ? `Переставить «${name}» раньше` : `Поднять «${name}» выше`;
  const nextLabel = horizontal ? `Переставить «${name}» дальше` : `Опустить «${name}» ниже`;
  const cls = "flex h-11 w-11 items-center justify-center rounded-full text-muted hover:bg-whip hover:text-choc disabled:pointer-events-none disabled:opacity-25";
  return (
    <span className="inline-flex shrink-0 items-center">
      <button type="button" className={cls} disabled={disabled || index === 0} onClick={() => onMove(-1)} aria-label={prevLabel} title={horizontal ? "Раньше" : "Выше"}>
        <Prev size={17} strokeWidth={1.5} />
      </button>
      <button type="button" className={cls} disabled={disabled || index >= count - 1} onClick={() => onMove(1)} aria-label={nextLabel} title={horizontal ? "Дальше" : "Ниже"}>
        <Next size={17} strokeWidth={1.5} />
      </button>
    </span>
  );
}

/** Подтверждение удаления: «Удалить «…»?» + «Удалить» / «Нет». */
export function ConfirmDelete({
  name,
  pending,
  onConfirm,
  onCancel,
  note,
}: {
  name: string;
  pending?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
  note?: string;
}) {
  return (
    <span className="inline-flex flex-wrap items-center gap-2 text-[13px]" role="group" aria-label="Подтверждение удаления">
      <span>
        Удалить «{name}»?{note ? <span className="block text-[12px] text-muted">{note}</span> : null}
      </span>
      <button type="button" disabled={pending} onClick={onConfirm} className="min-h-11 rounded-full bg-caramel-deep px-3.5 py-1.5 text-cream">
        Удалить
      </button>
      <button type="button" onClick={onCancel} className="min-h-11 rounded-full px-3.5 py-1.5 hover:bg-whip">
        Нет
      </button>
    </span>
  );
}
