"use client";

import { AnimatePresence, motion } from "framer-motion";
import { BarChart3, CakeSlice, CalendarDays, Images, Inbox, Link2, LogOut, Settings2, Type } from "lucide-react";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import type { AdminData } from "@/lib/server/admin-data";
import { Monogram } from "@/components/ui/Monogram";
import { NotifyProvider } from "./ui";
import { OrdersTab } from "./OrdersTab";
import { CalendarTab } from "./CalendarTab";
import { MenuTab } from "./MenuTab";
import { GalleryTab } from "./GalleryTab";
import { StatsTab } from "./StatsTab";
import { SettingsTab } from "./SettingsTab";
import { TextsTab } from "./TextsTab";
import { DemoTab } from "./DemoTab";

const TABS = [
  { id: "orders", label: "Заказы", icon: Inbox },
  { id: "calendar", label: "Календарь", icon: CalendarDays },
  { id: "menu", label: "Цены и меню", icon: CakeSlice },
  { id: "gallery", label: "Галерея", icon: Images },
  { id: "stats", label: "Аналитика", icon: BarChart3 },
  { id: "texts", label: "Тексты сайта", icon: Type },
  { id: "settings", label: "Настройки", icon: Settings2 },
  { id: "demo", label: "Демо", icon: Link2 },
] as const;
type TabId = (typeof TABS)[number]["id"];

// На телефоне внизу помещается 6 вкладок (подписи не обрезаются на 320 px), поэтому «Тексты сайта» и «Демо»
// там живут внутри «Настроек» — с переключателем «Основные / Тексты / Демо» над содержимым.
const MOBILE_TABS = TABS.filter((t) => t.id !== "texts" && t.id !== "demo");
const SETTINGS_SUBTABS = [
  { id: "settings", label: "Основные" },
  { id: "texts", label: "Тексты" },
  { id: "demo", label: "Демо" },
] as const;
const inSettings = (t: TabId) => t === "settings" || t === "texts" || t === "demo";

export function AdminApp({ data }: { data: AdminData }) {
  const router = useRouter();
  const [tab, setTab] = useState<TabId>("orders");
  const [toast, setToast] = useState<{ msg: string; kind: "ok" | "error" } | null>(null);

  useEffect(() => {
    try {
      const saved = sessionStorage.getItem("mira-admin-tab") as TabId | null;
      if (saved && TABS.some((t) => t.id === saved)) setTab(saved);
    } catch {}
  }, []);
  useEffect(() => {
    try {
      sessionStorage.setItem("mira-admin-tab", tab);
    } catch {}
  }, [tab]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2800);
    return () => clearTimeout(t);
  }, [toast]);

  const notify = useCallback((msg: string, kind: "ok" | "error" = "ok") => setToast({ msg, kind }), []);
  const newCount = data.orders.filter((o) => o.status === "NEW").length;

  const logout = async () => {
    await fetch("/api/admin/login", { method: "DELETE" });
    router.refresh();
  };

  return (
    <NotifyProvider value={notify}>
      <div className="min-h-dvh pb-[calc(84px+var(--sab))] md:pb-10">
        <header className="mx-auto flex max-w-6xl items-center justify-between px-4 pb-3 pt-4 sm:px-6">
          <a href="/" className="flex items-center gap-3" title="Открыть сайт">
            <Monogram size={36} />
            <span className="leading-tight">
              <span className="display block text-[20px]">{data.settings.brandName}</span>
              <span className="block text-[11px] text-muted">кабинет кондитера</span>
            </span>
          </a>
          <button type="button" onClick={logout} className="btn-ghost !px-4 !py-2.5 text-[13px]">
            <LogOut size={15} strokeWidth={1.5} /> Выйти
          </button>
        </header>

        {/* Вкладки: сверху на планшете/десктопе, снизу на телефоне */}
        <nav className="sticky top-0 z-30 hidden border-y border-line bg-cream md:block" aria-label="Разделы кабинета">
          <div className="no-scrollbar mx-auto flex max-w-6xl gap-1 overflow-x-auto px-4 py-2 sm:px-6">
            {TABS.map((t) => (
              <TabButton key={t.id} active={tab === t.id} onClick={() => setTab(t.id)} badge={t.id === "orders" ? newCount : 0} layoutId="admin-tab-top">
                {/* На планшете 7 вкладок с иконками не помещаются в строку — иконки только с 1024 px */}
                <t.icon size={16} strokeWidth={1.5} className="hidden lg:block" /> {t.label}
              </TabButton>
            ))}
          </div>
        </nav>

        <main className="mx-auto max-w-6xl px-4 pt-4 sm:px-6 md:pt-8">
          {tab === "orders" && <OrdersTab data={data} />}
          {tab === "calendar" && <CalendarTab data={data} />}
          {tab === "menu" && <MenuTab data={data} />}
          {tab === "gallery" && <GalleryTab data={data} />}
          {tab === "stats" && <StatsTab data={data} />}
          {inSettings(tab) && (
            <div className="mb-5 grid grid-cols-3 rounded-full border border-line-strong p-1 md:hidden" role="tablist" aria-label="Раздел настроек">
              {SETTINGS_SUBTABS.map(({ id, label }) => (
                <button
                  key={id}
                  type="button"
                  role="tab"
                  aria-selected={tab === id}
                  onClick={() => {
                    setTab(id);
                    window.scrollTo({ top: 0 });
                  }}
                  className={`min-h-11 rounded-full text-[14px] transition-colors ${tab === id ? "bg-choc text-cream" : "text-choc"}`}
                >
                  {label}
                </button>
              ))}
            </div>
          )}
          {tab === "texts" && <TextsTab data={data} />}
          {tab === "demo" && <DemoTab data={data} />}
          {tab === "settings" && <SettingsTab data={data} />}
        </main>

        <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-cream pb-[var(--sab)] md:hidden" aria-label="Разделы кабинета">
          <div className="grid grid-cols-6">
            {MOBILE_TABS.map((t) => {
              const active = t.id === "settings" ? inSettings(tab) : tab === t.id;
              return (
              <button
                key={t.id}
                type="button"
                onClick={() => {
                  setTab(t.id);
                  window.scrollTo({ top: 0 });
                }}
                className={`relative flex flex-col items-center gap-1 py-2.5 text-[10px] ${active ? "text-choc" : "text-muted"}`}
                aria-current={active ? "page" : undefined}
              >
                {active && <motion.span layoutId="admin-tab-bottom" className="absolute inset-x-3 top-0 h-[2px] bg-caramel" />}
                <span className="relative">
                  <t.icon size={20} strokeWidth={1.5} />
                  {t.id === "orders" && newCount > 0 && (
                    <span className="num absolute -right-2.5 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-caramel-deep px-1 text-[10px] text-cream">
                      {newCount}
                    </span>
                  )}
                </span>
                {/* Без боковых отступов «Календарь» и «Настройки» помещаются и на 320 px, а не обрезаются троеточием. */}
                <span className="max-w-full truncate tracking-[-0.01em]">{t.label.split(" ")[0]}</span>
              </button>
              );
            })}
          </div>
        </nav>

        <AnimatePresence>
          {toast && (
            <motion.div
              role="status"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 12 }}
              className={`fixed inset-x-4 bottom-[calc(88px+var(--sab))] z-50 mx-auto max-w-sm rounded-[14px] px-4 py-3 text-center text-[14px] md:bottom-6 ${
                toast.kind === "error" ? "bg-caramel-deep text-cream" : "bg-choc text-cream"
              }`}
            >
              {toast.msg}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </NotifyProvider>
  );
}

function TabButton({
  active,
  onClick,
  children,
  badge,
  layoutId,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
  badge?: number;
  layoutId: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={`relative flex shrink-0 items-center gap-2 whitespace-nowrap rounded-full px-3 py-2.5 text-[14px] transition-colors lg:px-4 ${active ? "text-cream" : "text-choc hover:bg-whip"}`}
    >
      {active && <motion.span layoutId={layoutId} className="absolute inset-0 rounded-full bg-choc" transition={{ type: "spring", stiffness: 500, damping: 40 }} />}
      <span className="relative flex items-center gap-2">{children}</span>
      {!!badge && (
        <span className={`num relative rounded-full px-1.5 text-[11px] ${active ? "bg-cream text-choc" : "bg-caramel-deep text-cream"}`}>{badge}</span>
      )}
    </button>
  );
}
