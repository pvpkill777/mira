"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { AdminData } from "@/lib/server/admin-data";
import { formatWeight } from "@/lib/format";
import { Labeled, Panel, Toggle, inputCls, useApi } from "./ui";
import { ImageField } from "./ImageField";
import { ConfirmDelete, MoveButtons, useReorder } from "./reorder";

type Item = AdminData["gallery"][number];
type Category = AdminData["galleryCategories"][number];
type GalleryValues = {
  title: string;
  description: string;
  imageUrl: string;
  category: string;
  weightGrams: number;
  sizeId: string | null;
  fillingId: string | null;
  decorIds: string;
};

export function GalleryTab({ data }: { data: AdminData }) {
  const { call, pending } = useApi();
  const reorder = useReorder("gallery");
  const [adding, setAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const editRef = useRef<HTMLDivElement>(null);
  const editing = data.gallery.find((g) => g.id === editingId) ?? null;
  const catLabel = (slug: string) => data.galleryCategories.find((c) => c.slug === slug)?.label;

  useEffect(() => {
    if (editingId) editRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [editingId]);

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="display text-[38px] sm:text-[46px]">Галерея работ</h1>
          <p className="mt-1 text-[14px] text-muted">Для каждого фото укажите вес и начинку — клиент сможет собрать такой же торт в один клик.</p>
        </div>
        <button
          className="btn-primary"
          onClick={() => {
            setEditingId(null);
            setAdding((v) => !v);
          }}
          aria-expanded={adding}
        >
          <Plus size={16} strokeWidth={1.5} /> Добавить работу
        </button>
      </div>

      <AnimatePresence>
        {adding && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
            <Panel className="mt-5" title="Новая работа">
              <GalleryForm
                data={data}
                pending={pending}
                submitLabel="Добавить в галерею"
                onCancel={() => setAdding(false)}
                onSubmit={async (v) => {
                  const ok = await call("POST", "/api/admin/entities/gallery", { ...v, sortOrder: 0 }, "Работа добавлена в галерею");
                  if (ok) setAdding(false);
                }}
              />
            </Panel>
          </motion.div>
        )}
      </AnimatePresence>

      <div ref={editRef} className="scroll-mt-4">
        {editing && (
          <Panel className="mt-5" title={`Изменить «${editing.title}»`}>
            <GalleryForm
              key={editing.id}
              data={data}
              initial={editing}
              pending={pending}
              submitLabel="Сохранить"
              onCancel={() => setEditingId(null)}
              onSubmit={async (v) => {
                const ok = await call("PATCH", `/api/admin/entities/gallery/${editing.id}`, v, "Работа сохранена");
                if (ok) setEditingId(null);
              }}
            />
          </Panel>
        )}
      </div>

      {data.gallery.length === 0 && !adding && (
        <div className="mt-6 rounded-[22px] border border-dashed border-line-strong px-6 py-12 text-center">
          <p className="display text-[26px]">Галерея пока пустая</p>
          <p className="mt-2 text-[14px] text-muted">Добавьте первую работу — клиенты увидят её на сайте и смогут заказать похожий торт.</p>
        </div>
      )}
      <ul className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {data.gallery.map((g, i) => {
          const filling = data.fillings.find((f) => f.id === g.fillingId);
          return (
            <li key={g.id} className={`flex flex-col rounded-[18px] border bg-white/45 p-2 ${editingId === g.id ? "border-choc" : "border-line-strong"}`}>
              <div className="relative">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={g.imageUrl} alt={g.title} className={`aspect-[4/5] w-full rounded-[12px] object-cover ${g.active ? "" : "opacity-50 grayscale"}`} loading="lazy" />
                <button
                  onClick={() => {
                    setAdding(false);
                    setEditingId(g.id);
                  }}
                  className="absolute right-1.5 top-1.5 flex h-11 w-11 items-center justify-center rounded-full border border-line-strong bg-cream/95 text-choc hover:bg-cream"
                  aria-label={`Изменить «${g.title}»`}
                  title="Изменить"
                >
                  <Pencil size={16} strokeWidth={1.5} />
                </button>
              </div>
              <div className="flex flex-1 flex-col px-1 pb-1 pt-2">
                <p className={`line-clamp-2 break-words text-[14px] font-medium ${g.active ? "" : "text-muted"}`}>{g.title}</p>
                <p className="num mt-0.5 text-[12px] leading-snug text-muted">
                  {catLabel(g.category) ?? "без категории"} · {formatWeight(g.weightGrams)} · {filling?.name ?? "начинка на выбор"}
                  {!g.active && " · скрыта"}
                </p>
                <div className="mt-auto pt-2">
                  <div className="flex items-center justify-between">
                    <Toggle on={g.active} label={g.active ? `Скрыть «${g.title}» с сайта` : `Показать «${g.title}» на сайте`} onChange={(v) => call("PATCH", `/api/admin/entities/gallery/${g.id}`, { active: v }, v ? "Фото на сайте" : "Фото скрыто")} />
                    <button onClick={() => setConfirmId(g.id)} className="flex h-11 w-11 items-center justify-center rounded-full text-muted hover:bg-whip hover:text-caramel-deep" aria-label={`Удалить «${g.title}»`} title="Удалить">
                      <Trash2 size={15} strokeWidth={1.5} />
                    </button>
                  </div>
                  {confirmId === g.id ? (
                    <ConfirmDelete
                      name={g.title}
                      pending={pending}
                      onConfirm={async () => {
                        const ok = await call("DELETE", `/api/admin/entities/gallery/${g.id}`, undefined, "Фото удалено");
                        if (ok && editingId === g.id) setEditingId(null);
                      }}
                      onCancel={() => setConfirmId(null)}
                    />
                  ) : (
                    <div className="flex justify-center">
                      <MoveButtons horizontal index={i} count={data.gallery.length} name={g.title} disabled={reorder.pending} onMove={(dir) => reorder.move(data.gallery.map((x) => x.id), i, dir)} />
                    </div>
                  )}
                </div>
              </div>
            </li>
          );
        })}
      </ul>

      <CategoriesPanel categories={data.galleryCategories} gallery={data.gallery} />
    </div>
  );
}

function GalleryForm({
  data,
  initial,
  pending,
  submitLabel,
  onSubmit,
  onCancel,
}: {
  data: AdminData;
  initial?: Item;
  pending: boolean;
  submitLabel: string;
  onSubmit: (v: GalleryValues) => void;
  onCancel: () => void;
}) {
  const activeCats = data.galleryCategories.filter((c) => c.active);
  const [v, setV] = useState(() => ({
    title: initial?.title ?? "",
    description: initial?.description ?? "",
    imageUrl: initial?.imageUrl ?? "",
    category: initial?.category ?? activeCats[0]?.slug ?? data.galleryCategories[0]?.slug ?? "",
    weightGrams: initial ? String(initial.weightGrams) : String(data.sizes.find((s) => s.fixedPrice == null)?.weightGrams ?? 1500),
    sizeId: initial ? initial.sizeId ?? "" : data.sizes.find((s) => s.fixedPrice == null)?.id ?? "",
    fillingId: initial ? initial.fillingId ?? "" : data.fillings[0]?.id ?? "",
    decorIds: initial ? initial.decorIds.split(",").filter((id) => id && data.decor.some((d) => d.id === id)) : ([] as string[]),
  }));
  const [error, setError] = useState<string | null>(null);
  // Категорию могли выключить: показываем её в списке, чтобы выбор не сбрасывался молча.
  const catOptions = data.galleryCategories.filter((c) => c.active || c.slug === v.category);
  const selectedSize = data.sizes.find((s) => s.id === v.sizeId);

  return (
    <form
      className="grid gap-3 sm:grid-cols-2"
      onSubmit={(e) => {
        e.preventDefault();
        setError(null);
        const grams = Number(v.weightGrams);
        if (!v.imageUrl) return setError("Добавьте фото — загрузите файл кнопкой справа или вставьте ссылку");
        if (!v.title.trim()) return setError("Введите название работы");
        if (!v.category) return setError("Сначала создайте категорию в блоке «Категории» ниже");
        if (!grams || grams < 100) return setError("Вес на фото — от 100 г");
        if (grams > 20_000) return setError("Вес на фото — не больше 20 000 г");
        onSubmit({ ...v, title: v.title.trim(), weightGrams: grams, sizeId: v.sizeId || null, fillingId: v.fillingId || null, decorIds: v.decorIds.join(",") });
      }}
    >
      <ImageField value={v.imageUrl} onChange={(url) => setV({ ...v, imageUrl: url })} label="Фото торта" />
      <Labeled label="Название">
        <input className={inputCls} maxLength={100} value={v.title} onChange={(e) => setV({ ...v, title: e.target.value })} placeholder="Белый минимализм" />
      </Labeled>
      <Labeled label="Категория">
        <select className={inputCls} value={v.category} onChange={(e) => setV({ ...v, category: e.target.value })}>
          {catOptions.length === 0 && <option value="">Нет категорий — создайте ниже</option>}
          {!data.galleryCategories.some((c) => c.slug === v.category) && v.category && <option value={v.category}>без категории</option>}
          {catOptions.map((c) => (
            <option key={c.slug} value={c.slug}>
              {c.active ? c.label : `${c.label} (выключена)`}
            </option>
          ))}
        </select>
      </Labeled>
      <Labeled label="Размер">
        <select
          className={inputCls}
          value={v.sizeId}
          onChange={(e) => {
            const s = data.sizes.find((x) => x.id === e.target.value);
            setV({ ...v, sizeId: e.target.value, weightGrams: s ? String(s.weightGrams) : v.weightGrams });
          }}
        >
          <option value="">Не указан</option>
          {data.sizes.map((s) => (
            <option key={s.id} value={s.id}>
              {s.active ? s.name : `${s.name} (скрыт)`}
            </option>
          ))}
        </select>
      </Labeled>
      <Labeled label="Вес на фото, г">
        <input
          className={`${inputCls} num`}
          inputMode="numeric"
          value={v.weightGrams}
          onChange={(e) => setV({ ...v, weightGrams: e.target.value.replace(/\D/g, "") })}
          readOnly={selectedSize?.fixedPrice != null}
          title={selectedSize?.fixedPrice != null ? "У бенто вес фиксированный — берётся из размера" : undefined}
        />
      </Labeled>
      <Labeled label="Начинка">
        <select className={inputCls} value={v.fillingId} onChange={(e) => setV({ ...v, fillingId: e.target.value })}>
          <option value="">На выбор клиента</option>
          {data.fillings.map((f) => (
            <option key={f.id} value={f.id}>
              {f.active ? f.name : `${f.name} (скрыта)`}
            </option>
          ))}
        </select>
      </Labeled>
      <fieldset className="sm:col-span-2">
        <legend className="mb-1 text-[12px] font-medium text-muted">Декор на фото</legend>
        {data.decor.length === 0 ? (
          <p className="text-[13px] text-muted">Опций декора пока нет — их можно добавить в «Цены и меню».</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {data.decor.map((d) => {
              const on = v.decorIds.includes(d.id);
              return (
                <button
                  key={d.id}
                  type="button"
                  aria-pressed={on}
                  onClick={() => setV({ ...v, decorIds: on ? v.decorIds.filter((x) => x !== d.id) : [...v.decorIds, d.id] })}
                  className={`min-h-11 rounded-full border px-3.5 py-2 text-[13px] ${on ? "border-choc bg-choc text-cream" : "border-line-strong"}`}
                >
                  {d.name}
                </button>
              );
            })}
          </div>
        )}
      </fieldset>
      <Labeled label="Короткое описание" className="sm:col-span-2">
        <input className={inputCls} maxLength={400} value={v.description} onChange={(e) => setV({ ...v, description: e.target.value })} placeholder="Гладкий крем, ничего лишнего" />
      </Labeled>
      {error && (
        <p role="alert" className="text-[13px] text-caramel-deep sm:col-span-2">
          {error}
        </p>
      )}
      <div className="flex flex-wrap gap-2 sm:col-span-2">
        <button type="submit" disabled={pending} className="btn-primary">
          {submitLabel}
        </button>
        <button type="button" onClick={onCancel} className="min-h-11 rounded-full px-4 text-[14px] hover:bg-whip">
          Отмена
        </button>
      </div>
    </form>
  );
}

/* ——— Категории галереи ——— */

function worksWord(n: number) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return "работа";
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return "работы";
  return "работ";
}

function CategoriesPanel({ categories, gallery }: { categories: Category[]; gallery: Item[] }) {
  const { call, pending } = useApi();
  const reorder = useReorder("categories");
  const [label, setLabel] = useState("");
  return (
    <Panel className="mt-8" title="Категории">
      <p className="mb-3 text-[14px] text-muted">
        Это фильтры над галереей на сайте. Пустые категории клиенты не видят. Работы из выключенной категории всё равно показываются во «Все».
      </p>
      {categories.length === 0 && <p className="text-[14px] text-muted">Категорий пока нет — добавьте первую ниже.</p>}
      <ul className="divide-y divide-line">
        {categories.map((c, i) => (
          <CategoryRow
            key={c.id}
            c={c}
            used={gallery.filter((g) => g.category === c.slug).length}
            index={i}
            count={categories.length}
            movePending={reorder.pending}
            onMove={(dir) => reorder.move(categories.map((x) => x.id), i, dir)}
          />
        ))}
      </ul>
      <form
        className="mt-4 flex gap-2 border-t border-line pt-4"
        onSubmit={async (e) => {
          e.preventDefault();
          if (!label.trim()) return;
          const ok = await call("POST", "/api/admin/entities/categories", { label: label.trim(), sortOrder: categories.length }, `Категория «${label.trim()}» добавлена`);
          if (ok) setLabel("");
        }}
      >
        <input className={`${inputCls} min-w-0 flex-1`} maxLength={40} placeholder="Новая категория, например «Детские»" value={label} onChange={(e) => setLabel(e.target.value)} aria-label="Название новой категории" />
        <button disabled={pending || !label.trim()} className="btn-primary min-h-11 !px-4 !py-2 text-[13px]">
          <Plus size={16} strokeWidth={1.5} /> Добавить
        </button>
      </form>
    </Panel>
  );
}

function CategoryRow({ c, used, index, count, onMove, movePending }: { c: Category; used: number; index: number; count: number; onMove: (dir: -1 | 1) => void; movePending: boolean }) {
  const { call, pending } = useApi();
  const [label, setLabel] = useState(c.label);
  useEffect(() => setLabel(c.label), [c.label]);
  const [confirm, setConfirm] = useState(false);
  const dirty = label.trim() !== c.label && label.trim() !== "";
  return (
    <li className="py-3">
      <div className="flex flex-wrap items-center gap-2">
        <input className={`${inputCls} min-w-[160px] flex-1 ${c.active ? "" : "text-muted"}`} maxLength={40} value={label} onChange={(e) => setLabel(e.target.value)} aria-label={`Название категории «${c.label}»`} />
        {dirty && (
          <button disabled={pending} onClick={() => call("PATCH", `/api/admin/entities/categories/${c.id}`, { label: label.trim() }, "Категория переименована")} className="btn-primary min-h-11 !px-3.5 !py-1.5 text-[12px]">
            Сохранить
          </button>
        )}
        <span className="num text-[12px] text-muted">
          {used} {worksWord(used)}
          {!c.active && " · выключена"}
        </span>
        <span className="ml-auto inline-flex items-center">
          <Toggle on={c.active} label={c.active ? `Выключить категорию «${c.label}»` : `Включить категорию «${c.label}»`} onChange={(v) => call("PATCH", `/api/admin/entities/categories/${c.id}`, { active: v }, v ? "Категория включена" : "Категория выключена")} />
          <MoveButtons index={index} count={count} name={c.label} onMove={onMove} disabled={movePending} />
          {!confirm && (
            <button onClick={() => setConfirm(true)} className="flex h-11 w-11 items-center justify-center rounded-full text-muted hover:bg-whip hover:text-caramel-deep" aria-label={`Удалить категорию «${c.label}»`} title="Удалить">
              <Trash2 size={15} strokeWidth={1.5} />
            </button>
          )}
        </span>
      </div>
      {confirm && (
        <div className="mt-2">
          {used > 0 ? (
            <p role="alert" className="flex flex-wrap items-center gap-2 text-[13px] text-caramel-deep">
              В категории {used} {worksWord(used)}. Сначала перенесите {used === 1 ? "её" : "их"} в другую категорию (карандаш на карточке работы) — или просто выключите категорию.
              <button onClick={() => setConfirm(false)} className="min-h-11 rounded-full px-3.5 text-choc hover:bg-whip">
                Понятно
              </button>
            </p>
          ) : (
            <ConfirmDelete name={c.label} pending={pending} onConfirm={() => call("DELETE", `/api/admin/entities/categories/${c.id}`, undefined, "Категория удалена")} onCancel={() => setConfirm(false)} />
          )}
        </div>
      )}
    </li>
  );
}
