"use client";

import { useRouter } from "next/navigation";
import { createContext, useCallback, useContext, useState, useTransition } from "react";
import { SwitchVisual } from "@/components/ui/Switch";

type Notify = (msg: string, kind?: "ok" | "error") => void;
const NotifyCtx = createContext<Notify>(() => {});
export const NotifyProvider = NotifyCtx.Provider;
export const useNotify = () => useContext(NotifyCtx);

/** Запрос к API кабинета + обновление серверных данных страницы. */
export function useApi() {
  const router = useRouter();
  const notify = useNotify();
  const [pending, startTransition] = useTransition();
  const [busy, setBusy] = useState(false);

  const call = useCallback(
    async <T = unknown,>(method: string, url: string, body?: unknown, okMessage?: string): Promise<T | null> => {
      setBusy(true);
      try {
        const res = await fetch(url, {
          method,
          headers: body instanceof FormData ? undefined : { "Content-Type": "application/json" },
          body: body instanceof FormData ? body : body !== undefined ? JSON.stringify(body) : undefined,
        });
        const data = await res.json().catch(() => ({}));
        if (res.status === 401) {
          notify("Сессия закончилась — войдите снова", "error");
          router.refresh();
          return null;
        }
        if (!res.ok) {
          notify(data.error ?? "Не получилось сохранить. Попробуйте ещё раз.", "error");
          return null;
        }
        if (okMessage) notify(okMessage);
        startTransition(() => router.refresh());
        return data as T;
      } catch {
        notify("Нет соединения с сервером. Проверьте интернет.", "error");
        return null;
      } finally {
        setBusy(false);
      }
    },
    [router, notify],
  );

  return { call, pending: pending || busy };
}

/** Копирование в буфер обмена с запасным путём для старых WebView и http. */
export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {}
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}

export function Panel({ title, action, children, className = "" }: { title?: string; action?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return (
    <section className={`min-w-0 rounded-[22px] border border-line-strong bg-white/45 p-4 sm:p-5 ${className}`}>
      {(title || action) && (
        <div className="mb-4 flex items-center justify-between gap-3">
          {title && <h3 className="display text-[24px] leading-none">{title}</h3>}
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button type="button" role="switch" aria-checked={on} aria-label={label} title={label} onClick={() => onChange(!on)} className="-my-2 inline-flex min-h-11 min-w-11 items-center justify-center">
      <SwitchVisual on={on} />
    </button>
  );
}

export function Labeled({ label, children, className = "" }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-1 block text-[12px] font-medium text-muted">{label}</span>
      {children}
    </label>
  );
}

// 16px, а не меньше: иначе iOS Safari приближает страницу при фокусе в поле.
export const inputCls = "field !rounded-[12px] !px-3 !py-2.5 text-[16px]";
