"use client";

import { useMemo, useState } from "react";
import { Check, Copy, Pencil, Plus, Trash2 } from "lucide-react";
import type { AdminData } from "@/lib/server/admin-data";
import type { PublicSettings } from "@/lib/types";
import { TEMPLATE_VARIABLES, fillTemplate, splitAccent } from "@/lib/content";
import { Labeled, Panel, Toggle, copyText, inputCls, useApi, useNotify } from "./ui";
import { ConfirmDelete, MoveButtons, useReorder } from "./reorder";

type Kind = "step" | "faq" | "principle" | "review";
type Item = AdminData["content"][number];

/** Подписи полей для каждого списка: что такое «заголовок» и «текст» у шага, вопроса, принципа и отзыва. */
const KINDS: Record<
  Kind,
  { title: string; hint: string; add: string; titleLabel: string; textLabel: string; detailLabel?: string; titleRequired: boolean; textRequired: boolean; empty: string }
> = {
  step: {
    title: "Шаги «Как это работает»",
    hint: "Нумеруются на сайте автоматически: 01, 02, 03…",
    add: "Добавить шаг",
    titleLabel: "Название шага",
    textLabel: "Описание",
    titleRequired: true,
    textRequired: false,
    empty: "Шагов нет — на сайте показываются только частые вопросы.",
  },
  faq: {
    title: "Частые вопросы",
    hint: "Клиент нажимает на вопрос — открывается ответ.",
    add: "Добавить вопрос",
    titleLabel: "Вопрос",
    textLabel: "Ответ",
    titleRequired: true,
    textRequired: true,
    empty: "Вопросов нет — блок на сайте скрыт.",
  },
  principle: {
    title: "Принципы",
    hint: "Короткий список рядом с рассказом «О кондитере».",
    add: "Добавить принцип",
    titleLabel: "Принцип",
    textLabel: "Пояснение",
    titleRequired: true,
    textRequired: false,
    empty: "Принципов нет — рассказ о кондитере занимает всю ширину.",
  },
  review: {
    title: "Отзывы",
    hint: "Только настоящие отзывы и с согласия клиента. Пока список пуст, блок отзывов на сайте скрыт.",
    add: "Добавить отзыв",
    titleLabel: "Имя клиента",
    textLabel: "Текст отзыва",
    detailLabel: "Что заказывали (необязательно)",
    titleRequired: false,
    textRequired: true,
    empty: "Отзывов пока нет — блок на сайте скрыт.",
  },
};

const TEXT_LIMITS = { heroTitle: 200, heroSubtitle: 600, aboutTitle: 200, aboutQuote: 600, aboutText: 1500, faqTitle: 200, seoTitle: 120, seoDescription: 300 };
type TextKey = keyof typeof TEXT_LIMITS;

/** Настройки кабинета → объект для подстановок в предпросмотре (функции нужны только числа и имена). */
function previewSettings(s: AdminData["settings"]): PublicSettings {
  return { ...s, timeSlots: s.timeSlots.split(",") } as unknown as PublicSettings;
}

export function TextsTab({ data }: { data: AdminData }) {
  const { call, pending } = useApi();
  const notify = useNotify();
  const s = data.settings;
  const initial = useMemo(
    () => ({
      heroTitle: s.heroTitle,
      heroSubtitle: s.heroSubtitle,
      aboutTitle: s.aboutTitle,
      aboutQuote: s.aboutQuote,
      aboutText: s.aboutText,
      faqTitle: s.faqTitle,
      seoTitle: s.seoTitle,
      seoDescription: s.seoDescription,
    }),
    [s],
  );
  const [v, setV] = useState(initial);
  // Сервер обрезает пробелы по краям — сравниваем так же, иначе после сохранения форма «вечно несохранённая».
  const dirty = (Object.keys(v) as TextKey[]).some((k) => v[k].trim() !== initial[k].trim());
  const set = (k: TextKey) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setV({ ...v, [k]: e.target.value });
  const ps = useMemo(() => previewSettings(s), [s]);

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!v.heroTitle.replace(/\*/g, "").trim()) {
      notify("Заполните заголовок первого экрана — это первое, что видит клиент", "error");
      return;
    }
    if ((v.heroTitle.match(/\*/g)?.length ?? 0) % 2 === 1) {
      notify("В заголовке непарная звёздочка: выделяемые слова пишутся между двумя *звёздочками*", "error");
      return;
    }
    call("PUT", "/api/admin/settings", v, "Тексты сохранены — сайт уже обновился");
  };

  const byKind = (k: Kind) => data.content.filter((c) => c.kind === k).sort((a, b) => a.sortOrder - b.sortOrder);

  return (
    <div>
      <form onSubmit={save}>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="display text-[38px] sm:text-[46px]">Тексты сайта</h1>
            <p className="mt-1 max-w-prose text-[14px] text-muted">Заголовки, рассказ о себе, вопросы и отзывы. Изменения видны на сайте сразу после сохранения.</p>
          </div>
          <button type="submit" disabled={pending || !dirty} className="btn-primary">
            {dirty ? "Сохранить тексты" : "Тексты сохранены"}
          </button>
        </div>

        <TemplateHint />

        <div className="mt-5 grid gap-5 lg:grid-cols-2">
          <Panel title="Первый экран">
            <div className="grid gap-3">
              <Labeled label="Заголовок">
                {/* Многострочное поле, чтобы длинный заголовок был виден целиком; переводы строк на сайте не нужны. */}
                <textarea
                  rows={2}
                  className={`${inputCls} resize-none`}
                  value={v.heroTitle}
                  onChange={(e) => setV({ ...v, heroTitle: e.target.value.replace(/\n/g, " ") })}
                  maxLength={TEXT_LIMITS.heroTitle}
                />
              </Labeled>
              <p className="-mt-1 text-[12px] leading-snug text-muted">
                Слова между звёздочками выделяются курсивом карамельного цвета: <span className="num">Авторские торты *из натуральных* ингредиентов</span>
              </p>
              {v.heroTitle.trim() && (
                <p className="display rounded-[12px] border border-line bg-cream px-3 py-2 text-[24px] leading-[1.1]" aria-label="Как заголовок выглядит на сайте">
                  {splitAccent(fillTemplate(v.heroTitle.trim(), ps)).map((p, i) =>
                    p.accent ? (
                      <em key={i} className="italic text-caramel">
                        {p.text}
                      </em>
                    ) : (
                      <span key={i}>{p.text}</span>
                    ),
                  )}
                </p>
              )}
              <Labeled label="Подзаголовок — пара предложений под заголовком">
                <textarea className={`${inputCls} min-h-[96px]`} value={v.heroSubtitle} onChange={set("heroSubtitle")} maxLength={TEXT_LIMITS.heroSubtitle} />
              </Labeled>
            </div>
          </Panel>

          <Panel title="О кондитере">
            <div className="grid gap-3">
              <Labeled label="Заголовок блока">
                <input className={inputCls} value={v.aboutTitle} onChange={set("aboutTitle")} maxLength={TEXT_LIMITS.aboutTitle} />
              </Labeled>
              <Labeled label="Цитата — кавычки добавятся сами (пусто — цитаты не будет)">
                <textarea className={`${inputCls} min-h-[70px]`} value={v.aboutQuote} onChange={set("aboutQuote")} maxLength={TEXT_LIMITS.aboutQuote} />
              </Labeled>
              <Labeled label="Рассказ о себе">
                <textarea className={`${inputCls} min-h-[120px]`} value={v.aboutText} onChange={set("aboutText")} maxLength={TEXT_LIMITS.aboutText} />
              </Labeled>
              <Counter value={v.aboutText} max={TEXT_LIMITS.aboutText} />
            </div>
          </Panel>

          <Panel title="Как это работает">
            <Labeled label="Заголовок блока с шагами и вопросами">
              <input className={inputCls} value={v.faqTitle} onChange={set("faqTitle")} maxLength={TEXT_LIMITS.faqTitle} />
            </Labeled>
          </Panel>

          <Panel title="Поисковики и превью ссылок">
            <div className="grid gap-3">
              <Labeled label="Заголовок вкладки браузера и превью в мессенджерах">
                <input className={inputCls} value={v.seoTitle} onChange={set("seoTitle")} maxLength={TEXT_LIMITS.seoTitle} placeholder={`${s.brandName} — авторские торты на заказ`} />
              </Labeled>
              <Counter value={v.seoTitle} max={TEXT_LIMITS.seoTitle} recommended={60} />
              <Labeled label="Описание для Яндекса, Google и превью ссылки">
                <textarea className={`${inputCls} min-h-[80px]`} value={v.seoDescription} onChange={set("seoDescription")} maxLength={TEXT_LIMITS.seoDescription} />
              </Labeled>
              <Counter value={v.seoDescription} max={TEXT_LIMITS.seoDescription} recommended={160} />
              <p className="text-[12px] leading-snug text-muted">Поисковики обновляют описание не сразу — обычно в течение нескольких дней.</p>
            </div>
          </Panel>
        </div>

        {dirty && (
          <div className="mt-4 flex flex-wrap items-center justify-end gap-3">
            <span className="text-[13px] text-muted">Есть несохранённые изменения</span>
            <button type="button" onClick={() => setV(initial)} className="btn-ghost min-h-11 !px-4 !py-2.5 text-[13px]">
              Отменить
            </button>
            <button type="submit" disabled={pending} className="btn-primary">
              Сохранить тексты
            </button>
          </div>
        )}
      </form>

      <div className="mt-8 grid gap-5 lg:grid-cols-2">
        {(["step", "faq", "principle", "review"] as Kind[]).map((k) => (
          <ContentList key={k} kind={k} items={byKind(k)} settings={ps} />
        ))}
      </div>
    </div>
  );
}

function Counter({ value, max, recommended }: { value: string; max: number; recommended?: number }) {
  const n = Array.from(value).length;
  const over = recommended != null && n > recommended;
  return (
    <p className={`-mt-2 text-right text-[12px] num ${over ? "text-caramel-deep" : "text-muted"}`}>
      {n} / {recommended ?? max}
      {over ? " — поисковик может обрезать" : ""}
    </p>
  );
}

/** Подсказка о подстановках: {предоплата} и т. п. заменяются числами из настроек. Нажатие копирует подстановку. */
function TemplateHint() {
  const notify = useNotify();
  const [copied, setCopied] = useState<string | null>(null);
  const copy = async (key: string) => {
    if (await copyText(key)) {
      setCopied(key);
      setTimeout(() => setCopied((c) => (c === key ? null : c)), 1500);
    } else notify("Не получилось скопировать — наберите подстановку вручную", "error");
  };
  return (
    <details className="group mt-5 rounded-[18px] border border-line bg-white/30 px-4 py-1">
      <summary className="flex min-h-11 cursor-pointer list-none items-center justify-between gap-3 text-[14px] font-medium [&::-webkit-details-marker]:hidden">
        Подстановки: цифры в текстах обновляются сами
        <Plus size={18} strokeWidth={1.5} aria-hidden className="shrink-0 text-muted transition-transform group-open:rotate-45" />
      </summary>
      <p className="max-w-prose text-[13px] leading-snug text-muted">
        Напишите в любом тексте, например, «Предоплата {"{предоплата}"}» — на сайте появится «Предоплата 50%». Поменяете процент в настройках — текст обновится сам. Нажмите, чтобы скопировать:
      </p>
      <ul className="mb-3 mt-2 grid gap-1 sm:grid-cols-2">
        {TEMPLATE_VARIABLES.map((t) => (
          <li key={t.key}>
            <button type="button" onClick={() => copy(t.key)} className="flex min-h-11 w-full items-center gap-2 rounded-[10px] px-2 text-left text-[13px] hover:bg-whip">
              {copied === t.key ? <Check size={14} strokeWidth={1.5} className="shrink-0 text-sage" /> : <Copy size={14} strokeWidth={1.5} className="shrink-0 text-muted" />}
              <span className="num shrink-0 font-medium">{t.key}</span>
              <span className="min-w-0 text-muted">— {t.hint}</span>
            </button>
          </li>
        ))}
      </ul>
    </details>
  );
}

type Draft = { title: string; text: string; detail: string };
const EMPTY: Draft = { title: "", text: "", detail: "" };

function ContentList({ kind, items, settings }: { kind: Kind; items: Item[]; settings: PublicSettings }) {
  const cfg = KINDS[kind];
  const { call, pending } = useApi();
  const notify = useNotify();
  const { move, pending: moving } = useReorder("content");
  const [editing, setEditing] = useState<string | "new" | null>(null);
  const [draft, setDraft] = useState<Draft>(EMPTY);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const startEdit = (it: Item) => {
    setEditing(it.id);
    setDraft({ title: it.title, text: it.text, detail: it.detail });
    setConfirmId(null);
  };
  const startNew = () => {
    setEditing("new");
    setDraft(EMPTY);
    setConfirmId(null);
  };

  const problem = (d: Draft) =>
    cfg.titleRequired && !d.title.trim()
      ? `Заполните поле «${cfg.titleLabel}»`
      : cfg.textRequired && !d.text.trim()
        ? `Заполните поле «${cfg.textLabel}»`
        : !d.title.trim() && !d.text.trim()
          ? "Пустой пункт не сохранить"
          : null;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const p = problem(draft);
    if (p) {
      notify(p, "error");
      return;
    }
    const body = { title: draft.title.trim(), text: draft.text.trim(), detail: draft.detail.trim() };
    const ok =
      editing === "new"
        ? await call("POST", "/api/admin/entities/content", { ...body, kind, active: true, sortOrder: items.length }, "Добавлено — уже на сайте")
        : await call("PATCH", `/api/admin/entities/content/${editing}`, body, "Сохранено");
    if (ok) setEditing(null);
  };

  const ids = items.map((i) => i.id);
  const label = (it: Item) => fillTemplate(it.title || it.text, settings).slice(0, 80) || "без названия";

  const form = (
    <form onSubmit={submit} className="grid gap-3 rounded-[16px] border border-line-strong bg-cream p-3">
      <Labeled label={cfg.titleLabel + (cfg.titleRequired ? "" : " (необязательно)")}>
        <input className={inputCls} value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} maxLength={200} autoFocus />
      </Labeled>
      <Labeled label={cfg.textLabel + (cfg.textRequired ? "" : " (необязательно)")}>
        <textarea className={`${inputCls} min-h-[96px]`} value={draft.text} onChange={(e) => setDraft({ ...draft, text: e.target.value })} maxLength={1500} />
      </Labeled>
      {cfg.detailLabel && (
        <Labeled label={cfg.detailLabel}>
          <input className={inputCls} value={draft.detail} onChange={(e) => setDraft({ ...draft, detail: e.target.value })} maxLength={200} placeholder="Медовик · 2,5 кг" />
        </Labeled>
      )}
      <div className="flex flex-wrap justify-end gap-2">
        <button type="button" onClick={() => setEditing(null)} className="btn-ghost min-h-11 !px-4 !py-2.5 text-[13px]">
          Отмена
        </button>
        <button type="submit" disabled={pending} className="btn-primary min-h-11 !px-5 !py-2.5 text-[14px]">
          {editing === "new" ? cfg.add : "Сохранить"}
        </button>
      </div>
    </form>
  );

  return (
    <Panel title={cfg.title}>
      <p className="-mt-2 mb-3 text-[13px] leading-snug text-muted">{cfg.hint}</p>
      {items.length === 0 && editing !== "new" && <p className="rounded-[14px] border border-dashed border-line-strong px-3 py-4 text-[14px] text-muted">{cfg.empty}</p>}
      <ul className="divide-y divide-line">
        {items.map((it, i) => (
          <li key={it.id} className="py-2">
            {editing === it.id ? (
              form
            ) : (
              // На телефоне кнопки — строкой под текстом, иначе тексту оставалось 30 px.
              <div className="flex flex-col gap-1 sm:flex-row sm:items-start">
                <div className={`min-w-0 flex-1 pt-2 sm:pb-2 ${it.active ? "" : "opacity-50"}`}>
                  <p className="text-[15px] font-medium leading-snug">
                    {kind === "step" || kind === "principle" ? <span className="num mr-1.5 text-caramel-deep">{String(i + 1).padStart(2, "0")}</span> : null}
                    {label(it)}
                  </p>
                  {it.title && it.text && <p className="mt-0.5 line-clamp-2 text-[13px] leading-snug text-muted">{fillTemplate(it.text, settings)}</p>}
                  {!it.active && <p className="mt-1 text-[12px] text-muted">скрыт на сайте</p>}
                </div>
                <div className="-mr-2 flex shrink-0 items-center justify-end">
                  <Toggle
                    on={it.active}
                    label={it.active ? `Скрыть «${label(it)}» на сайте` : `Показать «${label(it)}» на сайте`}
                    onChange={(on) => call("PATCH", `/api/admin/entities/content/${it.id}`, { active: on }, on ? "Показано на сайте" : "Скрыто на сайте")}
                  />
                  <MoveButtons index={i} count={items.length} name={label(it)} disabled={moving} onMove={(dir) => move(ids, i, dir)} />
                  <button type="button" onClick={() => startEdit(it)} aria-label={`Изменить «${label(it)}»`} title="Изменить" className="flex h-11 w-11 items-center justify-center rounded-full text-muted hover:bg-whip hover:text-choc">
                    <Pencil size={16} strokeWidth={1.5} />
                  </button>
                  <button type="button" onClick={() => setConfirmId(it.id)} aria-label={`Удалить «${label(it)}»`} title="Удалить" className="flex h-11 w-11 items-center justify-center rounded-full text-muted hover:bg-whip hover:text-caramel-deep">
                    <Trash2 size={16} strokeWidth={1.5} />
                  </button>
                </div>
              </div>
            )}
            {confirmId === it.id && editing !== it.id && (
              <div className="pb-2">
                <ConfirmDelete
                  name={label(it)}
                  pending={pending}
                  note="Удаление нельзя отменить. Чтобы убрать с сайта на время — выключите переключатель."
                  onConfirm={async () => {
                    if (await call("DELETE", `/api/admin/entities/content/${it.id}`, undefined, "Удалено")) setConfirmId(null);
                  }}
                  onCancel={() => setConfirmId(null)}
                />
              </div>
            )}
          </li>
        ))}
      </ul>
      {editing === "new" ? (
        <div className="mt-3">{form}</div>
      ) : (
        <button type="button" onClick={startNew} className="btn-ghost mt-3 min-h-11 !px-4 !py-2.5 text-[14px]">
          <Plus size={16} strokeWidth={1.5} /> {cfg.add}
        </button>
      )}
    </Panel>
  );
}
