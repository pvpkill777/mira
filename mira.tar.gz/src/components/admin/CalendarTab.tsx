"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Lock, Minus, Plus, Unlock } from "lucide-react";
import { useMemo, useState } from "react";
import type { AdminData } from "@/lib/server/admin-data";
import { MONTHS, WEEKDAYS_SHORT, fromKey, humanDate, todayKey, toKey } from "@/lib/dates";
import { formatWeight } from "@/lib/format";
import { Panel, useApi } from "./ui";

export function CalendarTab({ data }: { data: AdminData }) {
  const { call, pending } = useApi();
  const capMap = useMemo(() => new Map(data.capacity.map((c) => [c.date, c])), [data.capacity]);
  const first = fromKey(data.capacity[0].date);
  const last = fromKey(data.capacity.at(-1)!.date);
  const [cursor, setCursor] = useState(new Date(first.getFullYear(), first.getMonth(), 1));
  const [selected, setSelected] = useState<string>(todayKey());
  const today = todayKey();

  const cells = useMemo(() => {
    const y = cursor.getFullYear();
    const m = cursor.getMonth();
    const offset = (new Date(y, m, 1).getDay() + 6) % 7;
    const n = new Date(y, m + 1, 0).getDate();
    const out: (string | null)[] = Array(offset).fill(null);
    for (let d = 1; d <= n; d++) out.push(toKey(new Date(y, m, d)));
    return out;
  }, [cursor]);

  const sel = capMap.get(selected);
  const dayOrders = data.orders.filter((o) => o.date === selected && o.status !== "CANCELLED");

  const save = (patch: { closed?: boolean; limit?: number | null; note?: string }, msg: string) => {
    if (!sel) return;
    const body = {
      date: selected,
      closed: patch.closed ?? sel.closed,
      limit: patch.limit !== undefined ? patch.limit : sel.hasOverride && sel.limit !== data.settings.defaultDailyLimit ? sel.limit : null,
      note: patch.note ?? sel.note,
    };
    call("PUT", "/api/admin/calendar", body, msg);
  };

  const canPrev = cursor > new Date(first.getFullYear(), first.getMonth(), 1);
  const canNext = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1) <= last;

  return (
    <div>
      <h1 className="display text-[38px] sm:text-[46px]">Календарь загрузки</h1>
      <p className="mt-1 text-[14px] text-muted">
        По умолчанию — до <span className="num">{data.settings.defaultDailyLimit}</span> тортов в день. Когда лимит набран, дата закрывается на сайте сама.
      </p>

      <div className="mt-6 grid gap-5 lg:grid-cols-[1.2fr_1fr]">
        <Panel>
          <div className="mb-3 flex items-center justify-between">
            <button type="button" disabled={!canPrev} onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))} className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-whip disabled:opacity-25" aria-label="Предыдущий месяц">
              <ChevronLeft size={20} strokeWidth={1.5} />
            </button>
            <p className="display text-[24px] capitalize">
              {MONTHS[cursor.getMonth()]} <span className="num text-muted">{cursor.getFullYear()}</span>
            </p>
            <button type="button" disabled={!canNext} onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))} className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-whip disabled:opacity-25" aria-label="Следующий месяц">
              <ChevronRight size={20} strokeWidth={1.5} />
            </button>
          </div>
          <div className="grid grid-cols-7 text-center text-[11px] uppercase tracking-[0.1em] text-muted">
            {WEEKDAYS_SHORT.map((w) => (
              <div key={w} className="py-1">
                {w}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {cells.map((k, i) => {
              if (!k) return <div key={`e${i}`} />;
              const c = capMap.get(k);
              const past = k < today;
              const blocked = c?.closed || c?.weekdayOff;
              const full = c && !blocked && c.count >= c.limit;
              const isSel = k === selected;
              return (
                <button
                  key={k}
                  type="button"
                  onClick={() => {
                    setSelected(k);
                    // На телефоне карточка дня — под календарём, за краем экрана: показываем её.
                    if (window.matchMedia("(max-width: 1023px)").matches) {
                      setTimeout(() => document.getElementById("admin-day")?.scrollIntoView({ behavior: "smooth", block: "nearest" }), 260);
                    }
                  }}
                  className={`relative flex aspect-square flex-col items-center justify-center rounded-[12px] border text-[14px] transition-colors sm:aspect-[1/0.9] ${
                    isSel ? "border-choc bg-choc text-cream" : blocked ? "border-transparent bg-whip text-choc/40" : full ? "border-caramel/50 bg-caramel-soft/60" : "border-line hover:border-choc/40"
                  } ${past && !isSel ? "opacity-40" : ""}`}
                >
                  <span className={`num ${c?.closed ? "line-through" : ""}`}>{fromKey(k).getDate()}</span>
                  {c && !blocked && (
                    <span className={`num text-[10px] ${isSel ? "text-cream/75" : full ? "text-caramel-deep" : "text-muted"}`}>
                      {c.count}/{c.limit}
                    </span>
                  )}
                  {c?.closed && !isSel && <Lock size={10} strokeWidth={1.5} className="absolute right-1 top-1" />}
                </button>
              );
            })}
          </div>
          <p className="mt-3 text-[12px] text-muted">Цифры — заказов / лимит. Серые дни закрыты или выходные по графику.</p>
        </Panel>

        <AnimatePresence mode="wait">
          {sel && (
            <motion.div
              key={selected}
              id="admin-day"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="scroll-mb-[calc(96px+var(--sab))] scroll-mt-4"
            >
              <Panel>
                <p className="eyebrow">Выбранный день</p>
                <h2 className="display mt-1 text-[30px] first-letter:uppercase">{humanDate(selected)}</h2>
                <p className="mt-1 text-[14px] text-muted">
                  {sel.closed ? "Закрыт для записи" : sel.weekdayOff ? "Выходной по графику" : `Заказов: ${sel.count} из ${sel.limit}`}
                  {sel.note && ` · ${sel.note}`}
                </p>

                <div className="mt-5 grid gap-3">
                  {sel.weekdayOff && !sel.closed ? (
                    <button disabled={pending} onClick={() => save({ closed: false, limit: data.settings.defaultDailyLimit }, "День открыт для записи")} className="btn-primary">
                      <Unlock size={16} strokeWidth={1.5} /> Открыть день для записи
                    </button>
                  ) : sel.closed ? (
                    <button
                      disabled={pending}
                      // Закрытый выходной по графику без своего лимита после «открытия» снова становился выходным — передаём лимит явно.
                      onClick={() => save({ closed: false, note: "", ...(sel.weekdayOff ? { limit: sel.limit } : {}) }, "Дата снова открыта")}
                      className="btn-primary"
                    >
                      <Unlock size={16} strokeWidth={1.5} /> Открыть дату
                    </button>
                  ) : (
                    <button disabled={pending} onClick={() => save({ closed: true, note: "Мест нет" }, "Дата закрыта — «Мест нет»")} className="btn-primary">
                      <Lock size={16} strokeWidth={1.5} /> Закрыть дату · «Мест нет»
                    </button>
                  )}

                  {!sel.closed && !sel.weekdayOff && (
                    <div className="flex items-center justify-between gap-3 rounded-[16px] border border-line-strong px-4 py-3">
                      <div>
                        <p className="text-[14px] font-medium">Лимит тортов</p>
                        <p className="text-[12px] text-muted">{sel.hasOverride && sel.limit !== data.settings.defaultDailyLimit ? "свой лимит для этой даты" : "по умолчанию"}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button disabled={pending || sel.limit <= 0} onClick={() => save({ limit: sel.limit - 1 }, `Лимит: ${sel.limit - 1}`)} className="flex h-10 w-10 items-center justify-center rounded-full border border-line-strong disabled:opacity-30" aria-label="Уменьшить лимит">
                          <Minus size={16} strokeWidth={1.5} />
                        </button>
                        <span className="display num w-8 text-center text-[26px]">{sel.limit}</span>
                        <button disabled={pending} onClick={() => save({ limit: sel.limit + 1 }, `Лимит: ${sel.limit + 1}`)} className="flex h-10 w-10 items-center justify-center rounded-full border border-line-strong" aria-label="Увеличить лимит">
                          <Plus size={16} strokeWidth={1.5} />
                        </button>
                      </div>
                    </div>
                  )}
                  {sel.hasOverride && (
                    <button disabled={pending} onClick={() => call("PUT", "/api/admin/calendar", { date: selected, closed: false, limit: null, note: "" }, "Настройки дня сброшены")} className="text-[13px] text-muted underline decoration-line-strong underline-offset-4">
                      Сбросить к настройкам по умолчанию
                    </button>
                  )}
                </div>

                <div className="mt-6">
                  <p className="eyebrow mb-2">Заказы на день</p>
                  {dayOrders.length === 0 ? (
                    <p className="text-[14px] text-muted">Пока нет заказов.</p>
                  ) : (
                    <ul className="divide-y divide-line border-y border-line text-[14px]">
                      {dayOrders.map((o) => (
                        <li key={o.id} className="flex justify-between gap-3 py-2.5">
                          <span>
                            <span className="num text-muted">{o.timeSlot}</span> · {o.fillingName}
                          </span>
                          <span className="num shrink-0">{formatWeight(o.weightGrams)}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </Panel>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
