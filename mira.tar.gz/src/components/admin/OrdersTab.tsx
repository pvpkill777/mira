"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Check, CheckCheck, Copy, MapPin, MessageCircle, Phone, RotateCcw, Search, Send, Truck, X, Zap } from "lucide-react";
import { useMemo, useState } from "react";
import type { AdminData, AdminOrder } from "@/lib/server/admin-data";
import { formatPrice, formatWeight, normalizeHandle, phoneDigits } from "@/lib/format";
import { fromKey, humanDate, relativeDayLabel, todayKey, toKey } from "@/lib/dates";
import { copyText, inputCls, useApi, useNotify } from "./ui";
import { Lightbox } from "./Lightbox";

const STATUS_TABS = [
  { id: "NEW", label: "Новые" },
  { id: "CONFIRMED", label: "Подтверждены" },
  { id: "DONE", label: "Выполнены" },
  { id: "CANCELLED", label: "Отменены" },
] as const;

const STATUS_LABEL: Record<string, string> = { NEW: "Новый", CONFIRMED: "Подтверждён", DONE: "Выполнен", CANCELLED: "Отменён" };
const DAY_FILTERS = [
  { id: "all", label: "Все даты" },
  { id: "today", label: "Сегодня" },
  { id: "tomorrow", label: "Завтра" },
] as const;
type DayFilter = (typeof DAY_FILTERS)[number]["id"];

const asc = (a: AdminOrder, b: AdminOrder) => a.date.localeCompare(b.date) || a.timeSlot.localeCompare(b.timeSlot);

/** Поиск по имени, телефону (от 3 цифр), номеру заказа и контакту. */
function matches(o: AdminOrder, q: string) {
  const text = q.trim().toLowerCase().replace(/^№\s*/, "");
  if (!text) return true;
  if (o.customerName.toLowerCase().includes(text) || o.contact.toLowerCase().includes(text)) return true;
  const digits = text.replace(/\D/g, "");
  if (digits && String(o.number).includes(digits) && digits.length === text.replace(/[\s№#]/g, "").length) return true;
  if (digits.length >= 3) {
    const phone = o.phone.replace(/\D/g, "");
    const d = digits.length === 11 && /^[78]/.test(digits) ? digits.slice(1) : digits;
    if (phone.includes(d)) return true;
  }
  return false;
}

export function OrdersTab({ data }: { data: AdminData }) {
  const [status, setStatus] = useState<string>("NEW");
  const [day, setDay] = useState<DayFilter>("all");
  const [query, setQuery] = useState("");
  const searching = query.trim().length > 0;

  const today = todayKey();
  const tomorrow = useMemo(() => {
    const t = fromKey(today);
    return toKey(new Date(t.getFullYear(), t.getMonth(), t.getDate() + 1));
  }, [today]);
  const dayKey = day === "today" ? today : day === "tomorrow" ? tomorrow : null;

  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const o of data.orders) if (!dayKey || o.date === dayKey) c[o.status] = (c[o.status] ?? 0) + 1;
    return c;
  }, [data.orders, dayKey]);

  // Сколько активных заказов на сегодня/завтра — видно прямо на фильтре.
  const dayCounts = useMemo(() => {
    const active = data.orders.filter((o) => o.status === "NEW" || o.status === "CONFIRMED");
    return { all: null, today: active.filter((o) => o.date === today).length, tomorrow: active.filter((o) => o.date === tomorrow).length } as Record<DayFilter, number | null>;
  }, [data.orders, today, tomorrow]);

  const list = useMemo(() => {
    if (searching) return data.orders.filter((o) => matches(o, query)).sort((a, b) => -asc(a, b));
    const l = data.orders.filter((o) => o.status === status && (!dayKey || o.date === dayKey));
    return status === "NEW" || status === "CONFIRMED" ? l.sort(asc) : l.sort((a, b) => -asc(a, b));
  }, [data.orders, status, dayKey, searching, query]);

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-x-4 gap-y-3">
        <h1 className="display text-[38px] sm:text-[46px]">Заказы</h1>
        <label className="relative block w-full sm:w-[320px]">
          <span className="sr-only">Поиск по заказам</span>
          <Search size={17} strokeWidth={1.5} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" aria-hidden />
          <input
            type="search"
            enterKeyHint="search"
            className={`${inputCls} w-full !pl-10 !pr-11 [&::-webkit-search-cancel-button]:appearance-none`}
            placeholder="Имя, телефон или №"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Escape" && setQuery("")}
          />
          {searching && (
            <button type="button" onClick={() => setQuery("")} className="absolute right-0 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center text-muted hover:text-choc" aria-label="Очистить поиск">
              <X size={17} strokeWidth={1.5} />
            </button>
          )}
        </label>
      </div>
      {searching ? (
        <p className="mt-4 text-[14px] text-muted" aria-live="polite">
          {list.length ? (
            <>
              Найдено: <span className="num">{list.length}</span> — по всем статусам
            </>
          ) : (
            "Ничего не нашлось"
          )}
        </p>
      ) : (
        <>
      <div className="no-scrollbar -mx-4 mt-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0" role="tablist">
        {STATUS_TABS.map((t) => {
          const active = status === t.id;
          return (
            <button
              key={t.id}
              role="tab"
              aria-selected={active}
              onClick={() => setStatus(t.id)}
              className={`relative shrink-0 rounded-full border px-4 py-2.5 text-[14px] transition-colors ${
                active ? "border-choc text-cream" : "border-line-strong hover:border-choc/50"
              }`}
            >
              {active && <motion.span layoutId="order-status" className="absolute inset-0 rounded-full bg-choc" transition={{ type: "spring", stiffness: 500, damping: 40 }} />}
              <span className="relative">
                {t.label} <span className="num opacity-60">{counts[t.id] ?? 0}</span>
              </span>
            </button>
          );
        })}
      </div>
      <div className="mt-2 flex flex-wrap gap-2" role="group" aria-label="Дата выдачи">
        {DAY_FILTERS.map((f) => {
          const active = day === f.id;
          const n = dayCounts[f.id];
          return (
            <button
              key={f.id}
              type="button"
              aria-pressed={active}
              onClick={() => setDay(f.id)}
              className={`min-h-11 rounded-full border px-3.5 text-[13px] transition-colors ${active ? "border-caramel bg-caramel-soft/70 text-choc" : "border-line text-muted hover:border-choc/40 hover:text-choc"}`}
            >
              {f.label}
              {n ? <span className="num ml-1 text-caramel-deep">{n}</span> : null}
            </button>
          );
        })}
      </div>
        </>
      )}

      {/* Вход в поиск и выход из него — мгновенная смена списка, без «уезжающих» десятков карточек. */}
      <div key={searching ? "search" : "list"} className="mt-5 grid gap-4 lg:grid-cols-2">
        <AnimatePresence mode="popLayout" initial={false}>
          {list.map((o) => (
            <OrderCard key={o.id} order={o} data={data} showStatus={searching} />
          ))}
        </AnimatePresence>
      </div>
      {list.length === 0 && (
        <div className="mt-6 rounded-[22px] border border-dashed border-line-strong px-6 py-12 text-center">
          <p className="display text-[26px]">{searching ? "Не нашли такой заказ" : "Здесь пусто"}</p>
          <p className="mt-2 text-[14px] text-muted">
            {searching
              ? "Проверьте написание имени или введите последние 4 цифры телефона."
              : dayKey
                ? `На ${day === "today" ? "сегодня" : "завтра"} заказов с таким статусом нет.`
                : status === "NEW"
                  ? "Новые заявки с сайта появятся здесь — поделитесь ссылкой в шапке профиля."
                  : "Заказов с таким статусом пока нет."}
          </p>
          {(searching || dayKey) && (
            <button type="button" onClick={() => (searching ? setQuery("") : setDay("all"))} className="btn-ghost mt-4 !px-4 !py-2.5 text-[13px]">
              {searching ? "Очистить поиск" : "Показать все даты"}
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function OrderCard({ order: o, data, showStatus = false }: { order: AdminOrder; data: AdminData; showStatus?: boolean }) {
  const { call, pending } = useApi();
  const notify = useNotify();
  const [photo, setPhoto] = useState<number | null>(null);
  const rel = relativeDayLabel(o.date);
  const hot = (o.status === "NEW" || o.status === "CONFIRMED") && (rel === "Сегодня" || rel === "Завтра");
  const overdue = (o.status === "NEW" || o.status === "CONFIRMED") && o.date < todayKey();
  const s = data.settings;

  const greeting = [
    `Здравствуйте, ${o.customerName}! Это ${s.ownerName.split(" ")[0]}, кондитерская «${s.brandName}».`,
    `Получила вашу заявку №${o.number}: ${o.sizeName}, ${formatWeight(o.weightGrams)} — ${o.fillingName}${o.decor.length ? `, ${o.decor.map((d) => d.name.toLowerCase()).join(", ")}` : ""}.`,
    `${humanDate(o.date)}, ${o.timeSlot}, ${o.delivery ? "доставка" : "самовывоз"}.`,
    `Сумма — ${formatPrice(o.total)}. Чтобы закрепить дату, нужна предоплата ${formatPrice(o.prepayment)}.`,
    `Реквизиты: ${s.paymentDetails}`,
    `После оплаты пришлите, пожалуйста, скриншот — и я подтвержу заказ.`,
  ].join("\n");

  // Ник Telegram: 5–32 символа, латиница/цифры/«_». Раньше в ссылку попадали ники Instagram с точкой
  // и телефоны («t.me/+7 999…») — Telegram открывал «пользователь не найден». Без ника открываем чат по номеру.
  const handle = normalizeHandle(o.contact);
  const isInstagram = /instagram/i.test(o.contact);
  const tgHandle = !isInstagram && /^[a-z][a-z0-9_]{4,31}$/i.test(handle) ? handle : null;
  const digits = phoneDigits(o.phone);
  const tgLink = tgHandle ? `https://t.me/${tgHandle}` : digits.length === 10 ? `https://t.me/+7${digits}` : null;
  const waLink = `https://wa.me/7${digits}?text=${encodeURIComponent(greeting)}`;

  const copy = async (text: string, msg: string) => {
    if (await copyText(text)) notify(msg);
    else notify("Не получилось скопировать. Выделите текст вручную.", "error");
  };
  // Telegram не подставляет текст в личный чат по ссылке — кладём его в буфер, остаётся только вставить.
  const openTelegram = () => {
    copyText(greeting).then((ok) => ok && notify("Текст для клиента скопирован — вставьте его в чат"));
  };

  const setStatus = (status: string, msg: string) => call("PATCH", `/api/admin/orders/${o.id}`, { status }, msg);

  // Заказы, которые попали на то же время (могли появиться до исправления двойной записи).
  const isActive = (st: string) => st === "NEW" || st === "CONFIRMED";
  const clashes = isActive(o.status)
    ? data.orders.filter((x) => x.id !== o.id && isActive(x.status) && x.date === o.date && x.timeSlot === o.timeSlot).map((x) => x.number)
    : [];

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className={`relative overflow-hidden rounded-[22px] border bg-white/50 ${hot || overdue ? "border-caramel" : "border-line-strong"}`}
    >
      {(hot || overdue) && <span className="absolute inset-y-0 left-0 w-1 bg-caramel" aria-hidden />}
      <div className="p-4 sm:p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="num text-[13px] text-muted">№{o.number}</span>
              {showStatus && <span className={`chip ${o.status === "NEW" ? "!border-choc !text-choc" : ""}`}>{STATUS_LABEL[o.status] ?? o.status}</span>}
              {rel && <span className={`chip ${hot ? "!border-caramel !text-caramel-deep" : ""}`}>{rel}</span>}
              {overdue && <span className="chip !border-caramel !text-caramel-deep">Просрочен</span>}
              {o.urgent && (
                <span className="chip !border-caramel-deep !bg-caramel-deep !text-cream">
                  <Zap size={11} strokeWidth={1.5} /> Срочный
                </span>
              )}
            </div>
            <p className="display mt-1.5 text-[26px] leading-tight first-letter:uppercase">
              {humanDate(o.date)}
            </p>
            <p className="num text-[14px]">
              {o.timeSlot} · {o.delivery ? "доставка" : "самовывоз"}
            </p>
          </div>
          <div className="text-right">
            <p className="display num text-[26px] leading-none">{formatPrice(o.total)}</p>
            <p className="num mt-1 text-[12px] text-muted">предоплата {formatPrice(o.prepayment)}</p>
          </div>
        </div>

        {clashes.length > 0 && (
          <p role="alert" className="mt-3 rounded-[12px] border border-caramel bg-caramel-soft/70 px-3 py-2 text-[13px]">
            На это же время записан{clashes.length > 1 ? "ы" : ""} заказ{clashes.length > 1 ? "ы" : ""} <span className="num">№{clashes.join(", №")}</span>. Перенесите время с клиентом или отмените лишний заказ.
          </p>
        )}

        <dl className="mt-4 divide-y divide-line border-y border-line text-[14px]">
          <Row term="Торт">
            {o.sizeName}, <span className="num">{formatWeight(o.weightGrams)}</span>
          </Row>
          <Row term="Начинка">{o.fillingName}</Row>
          {o.decor.length > 0 && <Row term="Декор">{o.decor.map((d) => d.name).join(", ")}</Row>}
          {o.inscription && <Row term="Надпись">«{o.inscription}»</Row>}
          {o.wishes && <Row term="Пожелания">{o.wishes}</Row>}
          {o.designPhotos.length > 0 && (
            <Row term="Фото дизайна">
              <span className="flex flex-wrap gap-2">
                {o.designPhotos.map((url, i) => (
                  <button key={url} type="button" onClick={() => setPhoto(i)} className="block rounded-[10px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-caramel" aria-label={`Открыть фото дизайна ${i + 1} из ${o.designPhotos.length}`}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={url} alt="" className="h-16 w-16 rounded-[10px] border border-line object-cover" loading="lazy" />
                  </button>
                ))}
              </span>
              <Lightbox photos={o.designPhotos} index={photo} onIndex={setPhoto} onClose={() => setPhoto(null)} caption={`Дизайн к заказу №${o.number}`} />
            </Row>
          )}
          {o.delivery && (
            <Row term="Адрес">
              <span className="inline-flex items-start gap-1.5">
                <Truck size={14} strokeWidth={1.5} className="mt-1 shrink-0" />
                {o.address}
              </span>
            </Row>
          )}
          <Row term="Клиент">
            {o.customerName} · <span className="num">{o.phone}</span>
            {o.contact && <span className="text-muted"> · {o.contact}</span>}
          </Row>
        </dl>

        <div className="mt-4 flex flex-wrap gap-2">
          {tgLink && (
            <a href={tgLink} target="_blank" rel="noreferrer" onClick={openTelegram} className="btn-ghost min-h-11 !px-3.5 !py-2.5 text-[13px]" title={tgHandle ? `@${tgHandle}` : "Чат по номеру телефона"}>
              <Send size={15} strokeWidth={1.5} /> Telegram
            </a>
          )}
          <a href={waLink} target="_blank" rel="noreferrer" className="btn-ghost min-h-11 !px-3.5 !py-2.5 text-[13px]">
            <MessageCircle size={15} strokeWidth={1.5} /> WhatsApp
          </a>
          <a href={`tel:+7${digits}`} className="btn-ghost min-h-11 !px-3.5 !py-2.5 text-[13px]">
            <Phone size={15} strokeWidth={1.5} /> Позвонить
          </a>
          <button type="button" onClick={() => copy(greeting, "Текст для клиента скопирован")} className="btn-ghost min-h-11 !px-3.5 !py-2.5 text-[13px]" title="Приветствие, состав заказа, сумма и реквизиты">
            <Copy size={15} strokeWidth={1.5} /> Текст клиенту
          </button>
          <button type="button" onClick={() => copy(s.paymentDetails, "Реквизиты скопированы")} className="btn-ghost min-h-11 !px-3.5 !py-2.5 text-[13px]">
            <Copy size={15} strokeWidth={1.5} /> Реквизиты
          </button>
          {!o.delivery && (
            <span className="hidden items-center gap-1 text-[12px] text-muted sm:inline-flex">
              <MapPin size={13} strokeWidth={1.5} /> самовывоз
            </span>
          )}
        </div>

        <div className="mt-4 flex flex-wrap gap-2 border-t border-line pt-4">
          {o.status === "NEW" && (
            <>
              <button disabled={pending} onClick={() => setStatus("CONFIRMED", `Заказ №${o.number} подтверждён`)} className="btn-primary min-h-11 !px-4 !py-2.5 text-[13px]">
                <Check size={15} strokeWidth={1.5} /> Предоплата получена
              </button>
              <CancelButton disabled={pending} onConfirm={() => setStatus("CANCELLED", `Заказ №${o.number} отменён`)} number={o.number} />
            </>
          )}
          {o.status === "CONFIRMED" && (
            <>
              <button disabled={pending} onClick={() => setStatus("DONE", `Заказ №${o.number} выполнен`)} className="btn-primary min-h-11 !px-4 !py-2.5 text-[13px]">
                <CheckCheck size={15} strokeWidth={1.5} /> Торт выдан
              </button>
              <CancelButton disabled={pending} onConfirm={() => setStatus("CANCELLED", `Заказ №${o.number} отменён`)} number={o.number} />
            </>
          )}
          {(o.status === "DONE" || o.status === "CANCELLED") && (
            <button disabled={pending} onClick={() => setStatus("NEW", `Заказ №${o.number} возвращён в новые`)} className="btn-ghost min-h-11 !px-4 !py-2.5 text-[13px]">
              <RotateCcw size={15} strokeWidth={1.5} /> Вернуть в новые
            </button>
          )}
        </div>
      </div>
    </motion.article>
  );
}

function CancelButton({ onConfirm, disabled, number }: { onConfirm: () => void; disabled: boolean; number: number }) {
  const [ask, setAsk] = useState(false);
  if (!ask)
    return (
      <button disabled={disabled} onClick={() => setAsk(true)} className="btn-ghost min-h-11 !px-4 !py-2.5 text-[13px]">
        <X size={15} strokeWidth={1.5} /> Отменить
      </button>
    );
  return (
    // На узком экране (320 px) подтверждение не помещалось в одну строку и обрезалось краем карточки — разрешаем перенос.
    <span className="inline-flex max-w-full flex-wrap items-center gap-2 rounded-[22px] border border-caramel px-2 py-1 text-[13px]">
      <span className="pl-2">Отменить заказ №{number}?</span>
      <button disabled={disabled} onClick={onConfirm} className="min-h-11 rounded-full bg-caramel-deep px-3 py-2 text-cream">
        Да, отменить
      </button>
      <button onClick={() => setAsk(false)} className="min-h-11 rounded-full px-3 py-2 hover:bg-whip">
        Нет
      </button>
    </span>
  );
}

function Row({ term, children }: { term: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-[96px_1fr] gap-3 py-2.5">
      <dt className="text-muted">{term}</dt>
      <dd className="min-w-0 [overflow-wrap:anywhere]">{children}</dd>
    </div>
  );
}
