"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ChevronDown, Pencil, Plus, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import type { AdminData } from "@/lib/server/admin-data";
import { formatPrice, formatWeight } from "@/lib/format";
import { Labeled, Panel, Toggle, inputCls, useApi } from "./ui";
import { ImageField } from "./ImageField";
import { ConfirmDelete, MoveButtons, useReorder } from "./reorder";

type Filling = AdminData["fillings"][number];
type Decor = AdminData["decor"][number];
type Size = AdminData["sizes"][number];

export function MenuTab({ data }: { data: AdminData }) {
  return (
    <div>
      <h1 className="display text-[38px] sm:text-[46px]">Цены и меню</h1>
      <p className="mt-1 text-[14px] text-muted">Все изменения сразу появляются в конструкторе на сайте. Выключенная позиция скрыта от клиентов.</p>
      <div className="mt-6 grid gap-5">
        <FillingsPanel fillings={data.fillings} />
        <div className="grid gap-5 lg:grid-cols-2">
          <DecorPanel decor={data.decor} />
          <SizesPanel sizes={data.sizes} />
        </div>
        <WeightRangePanel minGrams={data.settings.customMinGrams} maxGrams={data.settings.customMaxGrams} sizes={data.sizes} />
      </div>
    </div>
  );
}

/* ——— Начинки ——— */

function FillingsPanel({ fillings }: { fillings: Filling[] }) {
  const { call, pending } = useApi();
  const reorder = useReorder("fillings");
  const [adding, setAdding] = useState(false);
  return (
    <Panel
      title="Начинки"
      action={
        <button className="btn-ghost min-h-11 !px-3.5 !py-2 text-[13px]" onClick={() => setAdding((v) => !v)} aria-expanded={adding}>
          <Plus size={15} strokeWidth={1.5} /> Новая
        </button>
      }
    >
      <AnimatePresence>
        {adding && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
            <FillingForm
              submitLabel="Добавить начинку"
              pending={pending}
              onSubmit={async (v) => {
                const ok = await call("POST", "/api/admin/entities/fillings", { ...v, sortOrder: fillings.length }, "Начинка добавлена");
                if (ok) setAdding(false);
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>
      {fillings.length === 0 && !adding && <p className="text-[14px] text-muted">Начинок пока нет. Нажмите «Новая», чтобы добавить первую — без начинок заказать торт на сайте нельзя.</p>}
      <ul className="divide-y divide-line">
        {fillings.map((f, i) => (
          <FillingRow key={f.id} f={f} index={i} count={fillings.length} onMove={(dir) => reorder.move(fillings.map((x) => x.id), i, dir)} movePending={reorder.pending} />
        ))}
      </ul>
    </Panel>
  );
}

function FillingRow({ f, index, count, onMove, movePending }: { f: Filling; index: number; count: number; onMove: (dir: -1 | 1) => void; movePending: boolean }) {
  const { call, pending } = useApi();
  const [open, setOpen] = useState(false);
  const [price, setPrice] = useState(String(f.pricePerKg));
  // Цену могли поменять в форме «Описание и фото» — иначе здесь оставалось старое значение
  // с кнопкой «Сохранить цену», которая откатывала новую цену.
  useEffect(() => setPrice(String(f.pricePerKg)), [f.pricePerKg]);
  const dirtyPrice = price !== String(f.pricePerKg);

  return (
    <li className="py-3">
      <div className="flex items-center gap-3">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={f.imageUrl} alt="" className={`h-14 w-14 shrink-0 rounded-[12px] object-cover ${f.active ? "" : "opacity-40 grayscale"}`} />
        <div className="min-w-0 flex-1">
          <p className={`truncate text-[15px] font-medium ${f.active ? "" : "text-muted line-through"}`}>{f.name}</p>
          <p className="truncate text-[12px] text-muted">{f.active ? f.tags || "без тегов" : "скрыта — закончились продукты?"}</p>
        </div>
        <Toggle on={f.active} label={f.active ? "Скрыть начинку" : "Показать начинку"} onChange={(v) => call("PATCH", `/api/admin/entities/fillings/${f.id}`, { active: v }, v ? "Начинка снова в меню" : "Начинка скрыта")} />
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-2 pl-[68px]">
        <span className="flex items-center gap-1.5">
          <input
            className={`${inputCls} num !w-[96px] text-right`}
            inputMode="numeric"
            value={price}
            onChange={(e) => setPrice(e.target.value.replace(/\D/g, ""))}
            aria-label={`Цена за кг: ${f.name}`}
          />
          <span className="text-[12px] text-muted">₽/кг</span>
        </span>
        <AnimatePresence>
          {dirtyPrice && (
            <motion.button
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              disabled={pending || !price}
              onClick={() => call("PATCH", `/api/admin/entities/fillings/${f.id}`, { pricePerKg: Number(price) }, `Цена обновлена: ${formatPrice(Number(price))}/кг`)}
              className="btn-primary min-h-11 !px-3.5 !py-1.5 text-[12px]"
            >
              Сохранить цену
            </motion.button>
          )}
        </AnimatePresence>
        <button onClick={() => setOpen((v) => !v)} className="inline-flex min-h-11 items-center gap-1 text-[13px] text-muted hover:text-choc" aria-expanded={open}>
          Описание и фото <ChevronDown size={14} strokeWidth={1.5} className={`transition-transform ${open ? "rotate-180" : ""}`} />
        </button>
        <span className="ml-auto">
          <MoveButtons index={index} count={count} name={f.name} onMove={onMove} disabled={movePending} />
        </span>
      </div>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
            <div className="pt-3">
              <FillingForm
                initial={f}
                submitLabel="Сохранить"
                pending={pending}
                onSubmit={async (v) => {
                  const ok = await call("PATCH", `/api/admin/entities/fillings/${f.id}`, v, "Начинка сохранена");
                  if (ok) setOpen(false);
                }}
                onDelete={() => call("DELETE", `/api/admin/entities/fillings/${f.id}`, undefined, "Начинка удалена")}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </li>
  );
}

function FillingForm({
  initial,
  submitLabel,
  pending,
  onSubmit,
  onDelete,
}: {
  initial?: Filling;
  submitLabel: string;
  pending: boolean;
  onSubmit: (v: { name: string; description: string; pricePerKg: number; imageUrl: string; tags: string }) => void;
  onDelete?: () => void;
}) {
  const [v, setV] = useState({
    name: initial?.name ?? "",
    description: initial?.description ?? "",
    pricePerKg: String(initial?.pricePerKg ?? 2800),
    imageUrl: initial?.imageUrl ?? "",
    tags: initial?.tags ?? "",
  });
  const [confirmDelete, setConfirmDelete] = useState(false);
  return (
    <form
      className="mb-4 grid gap-3 rounded-[16px] bg-whip/70 p-3 sm:grid-cols-2"
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit({ ...v, pricePerKg: Number(v.pricePerKg) });
      }}
    >
      <Labeled label="Название">
        <input className={inputCls} required value={v.name} onChange={(e) => setV({ ...v, name: e.target.value })} placeholder="Фисташка — Малина" />
      </Labeled>
      <Labeled label="Цена за 1 кг, ₽">
        <input className={`${inputCls} num`} inputMode="numeric" required value={v.pricePerKg} onChange={(e) => setV({ ...v, pricePerKg: e.target.value.replace(/\D/g, "") })} />
      </Labeled>
      <Labeled label="Описание вкуса" className="sm:col-span-2">
        <textarea className={`${inputCls} min-h-[80px]`} value={v.description} onChange={(e) => setV({ ...v, description: e.target.value })} />
      </Labeled>
      <Labeled label="Теги через запятую">
        <input className={inputCls} value={v.tags} onChange={(e) => setV({ ...v, tags: e.target.value })} placeholder="Хит, Без орехов, Нежный" />
      </Labeled>
      <div>
        <ImageField value={v.imageUrl} onChange={(url) => setV({ ...v, imageUrl: url })} label="Фото разреза (обязательно)" />
        {!v.imageUrl && <p className="mt-1 text-[12px] text-muted">Загрузите фото кнопкой справа или вставьте ссылку — без фото начинку не сохранить.</p>}
      </div>
      <div className="flex flex-wrap items-center gap-2 sm:col-span-2">
        <button type="submit" disabled={pending || !v.name.trim() || !v.pricePerKg || !v.imageUrl} className="btn-primary !px-4 !py-2.5 text-[13px]">
          {submitLabel}
        </button>
        {(!v.name.trim() || !v.imageUrl) && (
          <span className="text-[12px] text-muted">
            {!v.name.trim() && !v.imageUrl ? "Нужны название и фото" : !v.name.trim() ? "Нужно название" : "Нужно фото"}
          </span>
        )}
        {onDelete &&
          (confirmDelete ? (
            <ConfirmDelete name={initial?.name ?? ""} pending={pending} onConfirm={onDelete} onCancel={() => setConfirmDelete(false)} note="В работах галереи начинка станет «на выбор клиента». Прошлые заказы не изменятся." />
          ) : (
            <button type="button" onClick={() => setConfirmDelete(true)} className="inline-flex min-h-11 items-center gap-1.5 px-2 text-[13px] text-muted hover:text-caramel-deep">
              <Trash2 size={14} strokeWidth={1.5} /> Удалить
            </button>
          ))}
      </div>
    </form>
  );
}

/* ——— Декор ——— */

function DecorPanel({ decor }: { decor: Decor[] }) {
  const { call, pending } = useApi();
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const reorder = useReorder("decor");
  return (
    <Panel title="Декор и опции">
      {decor.length === 0 && <p className="text-[14px] text-muted">Опций пока нет — добавьте первую ниже.</p>}
      <ul className="divide-y divide-line">
        {decor.map((d, i) => (
          <DecorRow key={d.id} d={d} index={i} count={decor.length} onMove={(dir) => reorder.move(decor.map((x) => x.id), i, dir)} movePending={reorder.pending} />
        ))}
      </ul>
      <form
        className="mt-4 flex gap-2 border-t border-line pt-4"
        onSubmit={async (e) => {
          e.preventDefault();
          const ok = await call("POST", "/api/admin/entities/decor", { name, price: Number(price || 0), sortOrder: decor.length }, "Опция добавлена");
          if (ok) {
            setName("");
            setPrice("");
          }
        }}
      >
        <input className={`${inputCls} flex-1`} placeholder="Новая опция" value={name} onChange={(e) => setName(e.target.value)} required aria-label="Название опции" />
        <input className={`${inputCls} num !w-[90px]`} placeholder="₽" inputMode="numeric" value={price} onChange={(e) => setPrice(e.target.value.replace(/\D/g, ""))} aria-label="Цена опции" />
        <button disabled={pending || !name} className="btn-primary !px-3.5 !py-2 text-[13px]" aria-label="Добавить опцию">
          <Plus size={16} strokeWidth={1.5} />
        </button>
      </form>
    </Panel>
  );
}

function DecorRow({ d, index, count, onMove, movePending }: { d: Decor; index: number; count: number; onMove: (dir: -1 | 1) => void; movePending: boolean }) {
  const { call, pending } = useApi();
  const [price, setPrice] = useState(String(d.price));
  useEffect(() => setPrice(String(d.price)), [d.price]);
  const [confirm, setConfirm] = useState(false);
  const [open, setOpen] = useState(false);
  const dirty = price !== String(d.price);
  return (
    <li className="py-3">
      <div className="flex flex-wrap items-center gap-2">
        <span className="min-w-[140px] flex-1">
          <span className={`block break-words text-[14px] ${d.active ? "" : "text-muted line-through"}`}>{d.name}</span>
          {d.description && <span className="block break-words text-[12px] text-muted">{d.description}</span>}
        </span>
        <input className={`${inputCls} num !w-[84px] text-right`} inputMode="numeric" value={price} onChange={(e) => setPrice(e.target.value.replace(/\D/g, ""))} aria-label={`Цена: ${d.name}`} />
        <span className="text-[12px] text-muted">₽</span>
        {dirty && (
          <button disabled={pending} onClick={() => call("PATCH", `/api/admin/entities/decor/${d.id}`, { price: Number(price || 0) }, "Цена декора обновлена")} className="btn-primary min-h-11 !px-3 !py-1.5 text-[12px]">
            Сохранить
          </button>
        )}
        <Toggle on={d.active} label={d.active ? "Скрыть опцию" : "Показать опцию"} onChange={(v) => call("PATCH", `/api/admin/entities/decor/${d.id}`, { active: v }, v ? "Опция включена" : "Опция скрыта")} />
      </div>
      <div className="mt-1 flex flex-wrap items-center gap-1">
        <button onClick={() => setOpen((v) => !v)} className="inline-flex min-h-11 items-center gap-1 pr-2 text-[13px] text-muted hover:text-choc" aria-expanded={open}>
          <Pencil size={13} strokeWidth={1.5} /> Название и описание
        </button>
        <span className="ml-auto inline-flex items-center">
          <MoveButtons index={index} count={count} name={d.name} onMove={onMove} disabled={movePending} />
          {!confirm && (
            <button onClick={() => setConfirm(true)} className="flex h-11 w-11 items-center justify-center rounded-full text-muted hover:bg-whip hover:text-caramel-deep" aria-label={`Удалить «${d.name}»`} title="Удалить">
              <Trash2 size={15} strokeWidth={1.5} />
            </button>
          )}
        </span>
      </div>
      {confirm && (
        <div className="mt-1">
          <ConfirmDelete
            name={d.name}
            pending={pending}
            onConfirm={() => call("DELETE", `/api/admin/entities/decor/${d.id}`, undefined, "Опция удалена")}
            onCancel={() => setConfirm(false)}
            note="Опция пропадёт и из работ галереи. Прошлые заказы не изменятся."
          />
        </div>
      )}
      {open && <DecorEditForm d={d} onDone={() => setOpen(false)} />}
    </li>
  );
}

function DecorEditForm({ d, onDone }: { d: Decor; onDone: () => void }) {
  const { call, pending } = useApi();
  const [name, setName] = useState(d.name);
  const [description, setDescription] = useState(d.description);
  return (
    <form
      className="mt-2 grid gap-3 rounded-[16px] bg-whip/70 p-3"
      onSubmit={async (e) => {
        e.preventDefault();
        const ok = await call("PATCH", `/api/admin/entities/decor/${d.id}`, { name, description }, "Опция сохранена");
        if (ok) onDone();
      }}
    >
      <Labeled label="Название">
        <input className={inputCls} required maxLength={80} value={name} onChange={(e) => setName(e.target.value)} />
      </Labeled>
      <Labeled label="Описание для клиента (необязательно)">
        <input className={inputCls} maxLength={200} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Например: до 15 знаков, шоколадом" />
      </Labeled>
      <div className="flex flex-wrap gap-2">
        <button type="submit" disabled={pending || !name.trim()} className="btn-primary min-h-11 !px-4 !py-2 text-[13px]">
          Сохранить
        </button>
        <button type="button" onClick={onDone} className="min-h-11 rounded-full px-3.5 text-[13px] hover:bg-cream">
          Отмена
        </button>
      </div>
    </form>
  );
}

/* ——— Размеры ——— */

/* ——— Вес торта: границы ползунка и кнопок ± в конструкторе ——— */

const kgText = (g: number) => (g / 1000).toString().replace(".", ",");
/** «1,5» / «1.5» / «1» → граммы, округлённые до 100 г; null, если не число. */
const parseKg = (s: string) => {
  const n = Number(s.trim().replace(",", "."));
  return Number.isFinite(n) && n > 0 ? Math.round((n * 1000) / 100) * 100 : null;
};

function WeightRangePanel({ minGrams, maxGrams, sizes }: { minGrams: number; maxGrams: number; sizes: Size[] }) {
  const { call, pending } = useApi();
  const [min, setMin] = useState(kgText(minGrams));
  const [max, setMax] = useState(kgText(maxGrams));
  const [error, setError] = useState<string | null>(null);

  // После сохранения сервер присылает новые значения — подтягиваем их в поля.
  useEffect(() => setMin(kgText(minGrams)), [minGrams]);
  useEffect(() => setMax(kgText(maxGrams)), [maxGrams]);

  const minG = parseKg(min);
  const maxG = parseKg(max);
  const dirty = minG !== minGrams || maxG !== maxGrams;
  // Размеры, вес которых не попадает в новые границы: на сайте их вес прижмётся к границе.
  const outside = sizes.filter(
    (s) => s.active && s.fixedPrice == null && minG != null && maxG != null && (s.weightGrams < minG || s.weightGrams > maxG),
  );

  const save = () => {
    setError(null);
    if (minG == null || maxG == null) return setError("Введите вес числом, например 1 или 1,5");
    if (minG < 100) return setError("Минимальный вес — от 0,1 кг");
    if (maxG > 50_000) return setError("Максимальный вес — не больше 50 кг");
    if (minG >= maxG) return setError("Минимальный вес должен быть меньше максимального");
    call("PUT", "/api/admin/settings", { customMinGrams: minG, customMaxGrams: maxG }, `Вес торта: от ${kgText(minG)} до ${kgText(maxG)} кг`);
  };

  return (
    <Panel title="Вес торта">
      <p className="text-[14px] leading-relaxed text-muted">
        В этих границах клиент выбирает вес ползунком и кнопками ±. Шаг — 100 г. На бенто с фиксированной ценой не влияет.
      </p>
      <div className="mt-4 grid max-w-md grid-cols-2 gap-3">
        <Labeled label="Минимум, кг">
          <input className={`${inputCls} num`} inputMode="decimal" value={min} onChange={(e) => setMin(e.target.value)} aria-label="Минимальный вес торта, кг" />
        </Labeled>
        <Labeled label="Максимум, кг">
          <input className={`${inputCls} num`} inputMode="decimal" value={max} onChange={(e) => setMax(e.target.value)} aria-label="Максимальный вес торта, кг" />
        </Labeled>
      </div>
      {outside.length > 0 && (
        <p className="mt-3 text-[13px] text-caramel-deep">
          Вне этих границ: {outside.map((s) => `${s.name} (${formatWeight(s.weightGrams)})`).join(", ")}. На сайте вес такого размера прижмётся к ближайшей границе — поправьте его в «Размерах» или раздвиньте границы.
        </p>
      )}
      {error && (
        <p role="alert" className="mt-3 text-[13px] text-caramel-deep">
          {error}
        </p>
      )}
      {dirty && (
        <button type="button" disabled={pending} onClick={save} className="btn-primary mt-4 min-h-11 !px-4 !py-2.5 text-[13px]">
          Сохранить вес
        </button>
      )}
    </Panel>
  );
}

type SizeValues = { name: string; weightGrams: number; guestsLabel: string; fixedPrice: number | null; adjustable: boolean };

function SizesPanel({ sizes }: { sizes: Size[] }) {
  const { call, pending } = useApi();
  const reorder = useReorder("sizes");
  const [adding, setAdding] = useState(false);
  const activeCount = sizes.filter((s) => s.active).length;
  return (
    <Panel
      title="Размеры"
      action={
        <button className="btn-ghost min-h-11 !px-3.5 !py-2 text-[13px]" onClick={() => setAdding((v) => !v)} aria-expanded={adding}>
          <Plus size={15} strokeWidth={1.5} /> Новый
        </button>
      }
    >
      {adding && (
        <SizeForm
          submitLabel="Добавить размер"
          pending={pending}
          onCancel={() => setAdding(false)}
          onSubmit={async (v) => {
            const ok = await call("POST", "/api/admin/entities/sizes", { ...v, sortOrder: sizes.length }, `Размер «${v.name}» добавлен`);
            if (ok) setAdding(false);
          }}
        />
      )}
      {sizes.length === 0 && !adding && <p className="text-[14px] text-muted">Размеров пока нет. Нажмите «Новый» — без размеров заказать торт на сайте нельзя.</p>}
      {sizes.length > 0 && activeCount === 0 && (
        <p role="alert" className="mb-2 text-[13px] text-caramel-deep">Все размеры выключены — на сайте не из чего выбрать. Включите хотя бы один.</p>
      )}
      <ul className="divide-y divide-line">
        {sizes.map((s, i) => (
          <SizeRow key={s.id} s={s} index={i} count={sizes.length} onMove={(dir) => reorder.move(sizes.map((x) => x.id), i, dir)} movePending={reorder.pending} />
        ))}
      </ul>
      <p className="mt-3 text-[12px] leading-relaxed text-muted">
        Фиксированная цена — для бенто: цена всегда одна, вес клиент не меняет. Если поле пустое, цена = вес × цена начинки, и вес можно подобрать ползунком.
      </p>
    </Panel>
  );
}

function sizeSummary(s: Size) {
  const parts = [formatWeight(s.weightGrams)];
  if (s.guestsLabel) parts.push(s.guestsLabel);
  parts.push(s.fixedPrice != null ? `${formatPrice(s.fixedPrice)} фикс.` : "цена по весу");
  return parts.join(" · ");
}

function SizeRow({ s, index, count, onMove, movePending }: { s: Size; index: number; count: number; onMove: (dir: -1 | 1) => void; movePending: boolean }) {
  const { call, pending } = useApi();
  const [open, setOpen] = useState(false);
  return (
    <li className="py-3">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className={`break-words text-[15px] font-medium ${s.active ? "" : "text-muted line-through"}`}>{s.name}</p>
          <p className="num text-[12px] text-muted">{s.active ? sizeSummary(s) : `скрыт · ${sizeSummary(s)}`}</p>
        </div>
        <Toggle on={s.active} label={s.active ? `Скрыть размер «${s.name}»` : `Показать размер «${s.name}»`} onChange={(a) => call("PATCH", `/api/admin/entities/sizes/${s.id}`, { active: a }, a ? "Размер включён" : "Размер скрыт")} />
      </div>
      <div className="mt-1 flex flex-wrap items-center gap-1">
        <button onClick={() => setOpen((v) => !v)} className="inline-flex min-h-11 items-center gap-1 pr-2 text-[13px] text-muted hover:text-choc" aria-expanded={open}>
          <Pencil size={13} strokeWidth={1.5} /> Изменить
        </button>
        <span className="ml-auto">
          <MoveButtons index={index} count={count} name={s.name} onMove={onMove} disabled={movePending} />
        </span>
      </div>
      {open && (
        <SizeForm
          initial={s}
          submitLabel="Сохранить"
          pending={pending}
          onCancel={() => setOpen(false)}
          onSubmit={async (v) => {
            const ok = await call("PATCH", `/api/admin/entities/sizes/${s.id}`, v, "Размер сохранён");
            if (ok) setOpen(false);
          }}
          onDelete={() => call("DELETE", `/api/admin/entities/sizes/${s.id}`, undefined, `Размер «${s.name}» удалён`)}
        />
      )}
    </li>
  );
}

function SizeForm({
  initial,
  submitLabel,
  pending,
  onSubmit,
  onCancel,
  onDelete,
}: {
  initial?: Size;
  submitLabel: string;
  pending: boolean;
  onSubmit: (v: SizeValues) => void;
  onCancel: () => void;
  onDelete?: () => void;
}) {
  const [v, setV] = useState({
    name: initial?.name ?? "",
    weightGrams: initial ? String(initial.weightGrams) : "",
    guestsLabel: initial?.guestsLabel ?? "",
    fixedPrice: initial?.fixedPrice == null ? "" : String(initial.fixedPrice),
  });
  const [error, setError] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const grams = Number(v.weightGrams);
  const fixed = v.fixedPrice === "" ? null : Number(v.fixedPrice);

  return (
    <form
      className="mb-3 mt-2 grid gap-3 rounded-[16px] bg-whip/70 p-3 sm:grid-cols-2"
      onSubmit={(e) => {
        e.preventDefault();
        setError(null);
        if (!v.name.trim()) return setError("Введите название размера, например «Средний»");
        if (!grams || grams < 100) return setError("Вес — от 100 г");
        if (grams > 20_000) return setError("Вес — не больше 20 000 г (20 кг)");
        if (fixed != null && fixed < 100) return setError("Фиксированная цена — от 100 ₽, или оставьте поле пустым");
        onSubmit({ name: v.name.trim(), weightGrams: grams, guestsLabel: v.guestsLabel.trim(), fixedPrice: fixed, adjustable: fixed == null });
      }}
    >
      <Labeled label="Название">
        <input className={inputCls} maxLength={60} value={v.name} onChange={(e) => setV({ ...v, name: e.target.value })} placeholder="Средний" />
      </Labeled>
      <Labeled label="Вес, граммы (1 кг = 1000)">
        <input className={`${inputCls} num`} inputMode="numeric" value={v.weightGrams} onChange={(e) => setV({ ...v, weightGrams: e.target.value.replace(/\D/g, "") })} placeholder="2000" />
      </Labeled>
      <Labeled label="Сколько гостей">
        <input className={inputCls} maxLength={40} value={v.guestsLabel} onChange={(e) => setV({ ...v, guestsLabel: e.target.value })} placeholder="8–10 гостей" />
      </Labeled>
      <Labeled label="Фиксированная цена, ₽ (для бенто)">
        <input className={`${inputCls} num`} inputMode="numeric" value={v.fixedPrice} onChange={(e) => setV({ ...v, fixedPrice: e.target.value.replace(/\D/g, "") })} placeholder="пусто — цена по весу" />
      </Labeled>
      <p className="text-[12px] leading-relaxed text-muted sm:col-span-2">
        {fixed == null
          ? "Цена считается так: вес × цена начинки за 1 кг. Клиент может подобрать вес ползунком."
          : `Цена всегда ${formatPrice(fixed)}, с любой начинкой. Вес клиент не меняет.`}
      </p>
      {error && (
        <p role="alert" className="text-[13px] text-caramel-deep sm:col-span-2">
          {error}
        </p>
      )}
      <div className="flex flex-wrap items-center gap-2 sm:col-span-2">
        <button type="submit" disabled={pending} className="btn-primary min-h-11 !px-4 !py-2.5 text-[13px]">
          {submitLabel}
        </button>
        <button type="button" onClick={onCancel} className="min-h-11 rounded-full px-3.5 text-[13px] hover:bg-cream">
          Отмена
        </button>
        {onDelete &&
          (confirmDelete ? (
            <ConfirmDelete name={initial?.name ?? ""} pending={pending} onConfirm={onDelete} onCancel={() => setConfirmDelete(false)} note="Работы галереи с этим размером останутся, размер в них сбросится. Прошлые заказы не изменятся." />
          ) : (
            <button type="button" onClick={() => setConfirmDelete(true)} className="ml-auto inline-flex min-h-11 items-center gap-1.5 px-2 text-[13px] text-muted hover:text-caramel-deep">
              <Trash2 size={14} strokeWidth={1.5} /> Удалить
            </button>
          ))}
      </div>
    </form>
  );
}
