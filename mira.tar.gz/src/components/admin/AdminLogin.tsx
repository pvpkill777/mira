"use client";

import { motion } from "framer-motion";
import { Delete, Loader2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { Monogram } from "@/components/ui/Monogram";

/** pinLength приходит с сервера: длина PIN из кабинета или из .env (4–8 цифр), сам PIN в браузер не попадает. */
export function AdminLogin({ pinLength }: { pinLength: number }) {
  const PIN_LENGTH = pinLength;
  const router = useRouter();
  const [pin, setPin] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [shake, setShake] = useState(0);

  // Одна попытка за раз: Enter или «Войти» во время автоотправки не должны отправлять PIN второй раз
  // (иначе одна ошибка считалась за две и вход блокировался вдвое быстрее).
  const inFlight = useRef(false);
  const submit = useCallback(
    async (value: string) => {
      if (inFlight.current) return;
      inFlight.current = true;
      setLoading(true);
      setError(null);
      try {
        const res = await fetch("/api/admin/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ pin: value }),
        });
        if (res.ok) {
          router.refresh();
          return;
        }
        const data = await res.json().catch(() => ({}));
        setError(data.error ?? "Не получилось войти");
        setShake((s) => s + 1);
        setPin("");
      } catch {
        setError("Нет соединения. Проверьте интернет и попробуйте снова.");
      } finally {
        inFlight.current = false;
        setLoading(false);
      }
    },
    [router],
  );

  const press = (d: string) => {
    if (loading) return;
    setError(null);
    setPin((p) => {
      const next = (p + d).slice(0, Math.max(PIN_LENGTH, 8));
      return next;
    });
  };

  // Автоотправка, как только введено столько цифр, сколько в PIN.
  useEffect(() => {
    if (pin.length === PIN_LENGTH) submit(pin);
  }, [pin, submit]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (/^\d$/.test(e.key)) press(e.key);
      else if (e.key === "Backspace") setPin((p) => p.slice(0, -1));
      else if (e.key === "Enter" && pin.length > 0) submit(pin);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  return (
    <main className="mx-auto flex min-h-dvh max-w-sm flex-col items-center justify-center px-6 py-10">
      <Monogram size={56} />
      <p className="eyebrow mt-6">Кабинет кондитера</p>
      <h1 className="display mt-2 text-[40px]">Введите PIN</h1>

      <motion.div
        key={shake}
        animate={shake ? { x: [0, -10, 10, -6, 6, 0] } : {}}
        transition={{ duration: 0.4 }}
        className="mt-8 flex h-6 items-center gap-4"
        aria-live="polite"
        aria-label={`Введено цифр: ${pin.length}`}
      >
        {Array.from({ length: Math.max(PIN_LENGTH, pin.length) }).map((_, i) => (
          <motion.span
            key={i}
            animate={{ scale: i < pin.length ? 1 : 0.7 }}
            className={`h-3.5 w-3.5 rounded-full border ${i < pin.length ? "border-choc bg-choc" : "border-line-strong"}`}
          />
        ))}
        {loading && <Loader2 size={16} className="animate-spin text-muted" />}
      </motion.div>
      <p className="mt-4 h-5 text-center text-[13px] text-caramel-deep">{error}</p>

      <div className="mt-6 grid w-full grid-cols-3 gap-3">
        {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((d) => (
          <Key key={d} onClick={() => press(d)}>
            {d}
          </Key>
        ))}
        <Key onClick={() => pin && submit(pin)} label="Войти" small>
          Войти
        </Key>
        <Key onClick={() => press("0")}>0</Key>
        <Key onClick={() => setPin((p) => p.slice(0, -1))} label="Стереть цифру">
          <Delete size={22} strokeWidth={1.5} />
        </Key>
      </div>
      <a href="/" className="mt-10 text-[13px] text-muted underline decoration-line-strong underline-offset-4">
        Вернуться на сайт
      </a>
    </main>
  );
}

function Key({ children, onClick, label, small }: { children: React.ReactNode; onClick: () => void; label?: string; small?: boolean }) {
  return (
    <motion.button
      type="button"
      whileTap={{ scale: 0.92 }}
      onClick={onClick}
      aria-label={label}
      className={`num flex h-[68px] items-center justify-center rounded-full border border-line-strong bg-white/40 transition-colors hover:border-choc ${
        small ? "text-[14px] font-medium" : "display text-[30px]"
      }`}
    >
      {children}
    </motion.button>
  );
}
