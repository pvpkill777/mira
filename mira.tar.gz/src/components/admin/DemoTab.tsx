"use client";

import { Check, Copy, ExternalLink, ImagePlus, Loader2, Trash2, X } from "lucide-react";
import { useRef, useState } from "react";
import type { AdminData } from "@/lib/server/admin-data";
import { Labeled, Panel, copyText, inputCls, useApi, useNotify } from "./ui";
import { ConfirmDelete } from "./reorder";

type Demo = AdminData["demos"][number];

const PRICE_LEVELS = [
  { pct: 80, label: "Дешевле" },
  { pct: 100, label: "Как в шаблоне" },
  { pct: 125, label: "Дороже" },
] as const;

const MAX_PHOTOS = 12;
const EMPTY = { brandName: "", ownerName: "", city: "", instagram: "", telegram: "", whatsapp: "" };

const demoUrl = (slug: string) => `${window.location.origin}/demo/${slug}`;

/** Готовое сообщение кондитеру — вставить в директ или мессенджер. */
function demoMessage(d: Pick<Demo, "slug" | "ownerName">) {
  const name = d.ownerName.trim().split(/\s+/)[0];
  return [
    `${name ? `${name}, здравствуйте` : "Здравствуйте"}! Вот как может выглядеть ваш сайт для заказов тортов: ${demoUrl(d.slug)}`,
    "",
    "Клиент сам собирает торт, сразу видит цену и свободные даты — а вам приходит готовая заявка, без «сколько стоит торт на 10 человек?» в директе.",
    "Если понравится — настрою под вас: ваши цены, начинки и фото.",
  ].join("\n");
}

export function DemoTab({ data }: { data: AdminData }) {
  const { call, pending } = useApi();
  const notify = useNotify();
  const [form, setForm] = useState(EMPTY);
  const [pricePct, setPricePct] = useState(100);
  const [photos, setPhotos] = useState<string[]>([]);
  const [uploading, setUploading] = useState(0);
  const [created, setCreated] = useState<Demo | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const set = (k: keyof typeof EMPTY) => (e: React.ChangeEvent<HTMLInputElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const upload = async (files: File[]) => {
    const free = MAX_PHOTOS - photos.length;
    if (files.length > free) notify(`Можно добавить ещё ${free} фото — лишние пропущены`, "error");
    const list = files.slice(0, free);
    setUploading((n) => n + list.length);
    // По одному: телефон на мобильном интернете не тянет 10 загрузок разом.
    for (const file of list) {
      try {
        const fd = new FormData();
        fd.append("file", file);
        const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
        const body = await res.json().catch(() => ({}));
        if (res.ok && body.url) setPhotos((p) => [...p, body.url]);
        else notify(body.error ?? "Одно фото не загрузилось", "error");
      } catch {
        notify("Нет соединения — фото не загрузилось", "error");
      } finally {
        setUploading((n) => n - 1);
      }
    }
  };

  const copy = async (key: string, text: string, okMsg: string) => {
    if (await copyText(text)) {
      setCopied(key);
      notify(okMsg);
      setTimeout(() => setCopied((c) => (c === key ? null : c)), 2000);
    } else notify("Не получилось скопировать — выделите текст вручную", "error");
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.brandName.trim()) {
      notify("Впишите название — его увидит кондитер", "error");
      return;
    }
    if (uploading > 0) {
      notify("Фото ещё загружаются — подождите пару секунд", "error");
      return;
    }
    const demo = await call<Demo>("POST", "/api/admin/entities/demos", { ...form, pricePct, photos: photos.join(",") }, "Демо готово");
    if (demo) {
      setCreated(demo);
      setForm(EMPTY);
      setPricePct(100);
      setPhotos([]);
    }
  };

  return (
    <div>
      <h1 className="display text-[38px] sm:text-[46px]">Демо для кондитеров</h1>
      <p className="mt-1 max-w-2xl text-[14px] text-muted">
        Впишите название и контакты кондитера — получите ссылку на сайт с её именем. Основной сайт не меняется, заявки из демо не отправляются.
      </p>

      {created && (
        <Panel className="mt-5 border-sage" title="Ссылка готова">
          <p className="break-all text-[15px]">{demoUrl(created.slug)}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <button type="button" className="btn-primary" onClick={() => copy(`msg-${created.id}`, demoMessage(created), "Сообщение скопировано — вставьте его кондитеру")}>
              {copied === `msg-${created.id}` ? <Check size={16} strokeWidth={1.5} /> : <Copy size={16} strokeWidth={1.5} />} Скопировать сообщение
            </button>
            <button type="button" className="btn-ghost" onClick={() => copy(`url-${created.id}`, demoUrl(created.slug), "Ссылка скопирована")}>
              <Copy size={16} strokeWidth={1.5} /> Только ссылку
            </button>
            <a className="btn-ghost" href={`/demo/${created.slug}`} target="_blank" rel="noreferrer">
              <ExternalLink size={16} strokeWidth={1.5} /> Открыть
            </a>
          </div>
        </Panel>
      )}

      <Panel className="mt-5" title="Новое демо">
        <form onSubmit={submit} className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <Labeled label="Название *">
              <input className={inputCls} value={form.brandName} onChange={set("brandName")} placeholder="например, Торты от Оксаны" maxLength={60} required />
            </Labeled>
            <Labeled label="Имя кондитера">
              <input className={inputCls} value={form.ownerName} onChange={set("ownerName")} placeholder="например, Оксана" maxLength={40} />
            </Labeled>
            <Labeled label="Instagram — ник или ссылка">
              <input className={inputCls} value={form.instagram} onChange={set("instagram")} placeholder="например, oksana.cakes" autoCapitalize="off" autoCorrect="off" />
            </Labeled>
            <Labeled label="Telegram — ник или ссылка">
              <input className={inputCls} value={form.telegram} onChange={set("telegram")} placeholder="например, oksana_cakes" autoCapitalize="off" autoCorrect="off" />
            </Labeled>
            <Labeled label="WhatsApp — номер">
              <input className={inputCls} value={form.whatsapp} onChange={set("whatsapp")} placeholder="+7 999 123-45-67" inputMode="tel" />
            </Labeled>
            <Labeled label="Город">
              <input className={inputCls} value={form.city} onChange={set("city")} placeholder="например, Казань" maxLength={40} />
            </Labeled>
          </div>

          <div>
            <span className="mb-1 block text-[12px] font-medium text-muted">Цены</span>
            <div className="grid grid-cols-3 rounded-full border border-line-strong p-1" role="radiogroup" aria-label="Уровень цен">
              {PRICE_LEVELS.map((p) => (
                <button
                  key={p.pct}
                  type="button"
                  role="radio"
                  aria-checked={pricePct === p.pct}
                  onClick={() => setPricePct(p.pct)}
                  className={`min-h-11 rounded-full px-2 text-[14px] transition-colors ${pricePct === p.pct ? "bg-choc text-cream" : "text-choc hover:bg-whip"}`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <span className="mb-1 block text-[12px] font-medium text-muted">Её фото — по желанию. Первое встанет на главный экран, все — в «Работы»</span>
            <div className="flex flex-wrap gap-2">
              {photos.map((url) => (
                <span key={url} className="relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={url} alt="" className="h-16 w-16 rounded-[10px] object-cover" />
                  <button
                    type="button"
                    onClick={() => setPhotos((p) => p.filter((x) => x !== url))}
                    className="absolute -right-2 -top-2 flex h-7 w-7 items-center justify-center rounded-full bg-choc text-cream"
                    aria-label="Убрать фото"
                  >
                    <X size={14} />
                  </button>
                </span>
              ))}
              {Array.from({ length: uploading }, (_, i) => (
                <span key={`u${i}`} className="flex h-16 w-16 items-center justify-center rounded-[10px] border border-line-strong">
                  <Loader2 size={18} className="animate-spin text-muted" />
                </span>
              ))}
              {photos.length + uploading < MAX_PHOTOS && (
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className="flex h-16 min-w-16 items-center justify-center gap-1.5 rounded-[10px] border border-dashed border-line-strong px-3 text-[13px] text-choc hover:bg-whip"
                >
                  <ImagePlus size={18} strokeWidth={1.5} /> {photos.length ? "" : "Добавить фото"}
                </button>
              )}
              <input
                ref={fileRef}
                type="file"
                multiple
                accept="image/jpeg,image/png,image/webp,image/avif"
                className="hidden"
                onChange={(e) => {
                  const files = [...(e.target.files ?? [])];
                  e.target.value = "";
                  if (files.length) upload(files);
                }}
              />
            </div>
          </div>

          <button type="submit" className="btn-primary w-full sm:w-auto" disabled={pending}>
            {pending && <Loader2 size={16} className="animate-spin" />} Создать демо
          </button>
        </form>
      </Panel>

      <Panel className="mt-5" title={`Мои демо${data.demos.length ? ` · ${data.demos.length}` : ""}`}>
        {data.demos.length === 0 ? (
          <p className="text-[14px] text-muted">Пока пусто. Создайте первое демо выше — займёт полминуты.</p>
        ) : (
          <ul className="divide-y divide-line">
            {data.demos.map((d) => (
              <li key={d.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                <div className="min-w-0">
                  <p className="text-[16px] [overflow-wrap:anywhere]">{d.brandName}</p>
                  <p className="text-[12px] text-muted">
                    {[d.ownerName, d.city].filter(Boolean).join(", ")}
                    {(d.ownerName || d.city) && " · "}
                    {d.viewCount > 0 ? (
                      <span className="text-choc">
                        открывали {d.viewCount} {plural(d.viewCount, "раз", "раза", "раз")}, последний — {shortDate(d.lastViewedAt)}
                      </span>
                    ) : (
                      "ещё не открывали"
                    )}
                  </p>
                </div>
                {confirmId === d.id ? (
                  <ConfirmDelete
                    name={d.brandName}
                    note="Ссылка перестанет открываться"
                    pending={pending}
                    onCancel={() => setConfirmId(null)}
                    onConfirm={async () => {
                      if (await call("DELETE", `/api/admin/entities/demos/${d.id}`, undefined, "Демо удалено")) setConfirmId(null);
                      if (created?.id === d.id) setCreated(null);
                    }}
                  />
                ) : (
                  <div className="flex items-center gap-1">
                    <IconBtn label="Скопировать сообщение со ссылкой" onClick={() => copy(`msg-${d.id}`, demoMessage(d), "Сообщение скопировано")}>
                      {copied === `msg-${d.id}` ? <Check size={18} strokeWidth={1.5} /> : <Copy size={18} strokeWidth={1.5} />}
                    </IconBtn>
                    <a href={`/demo/${d.slug}`} target="_blank" rel="noreferrer" title="Открыть демо" aria-label="Открыть демо" className={iconCls}>
                      <ExternalLink size={18} strokeWidth={1.5} />
                    </a>
                    <IconBtn label="Удалить демо" onClick={() => setConfirmId(d.id)}>
                      <Trash2 size={18} strokeWidth={1.5} />
                    </IconBtn>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}

const iconCls = "inline-flex h-11 w-11 items-center justify-center rounded-full text-choc transition-colors hover:bg-whip";

function IconBtn({ label, onClick, children }: { label: string; onClick: () => void; children: React.ReactNode }) {
  return (
    <button type="button" onClick={onClick} title={label} aria-label={label} className={iconCls}>
      {children}
    </button>
  );
}

function shortDate(iso: string | null) {
  if (!iso) return "";
  return new Date(iso).toLocaleString("ru-RU", { timeZone: "Europe/Moscow", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

function plural(n: number, one: string, few: string, many: string) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return one;
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return few;
  return many;
}
