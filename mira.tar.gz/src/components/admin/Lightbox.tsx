"use client";

import { ChevronLeft, ChevronRight, ExternalLink, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

/** Просмотр фото во весь экран внутри кабинета: Esc / стрелки, фокус возвращается на миниатюру. */
export function Lightbox({
  photos,
  index,
  onIndex,
  onClose,
  caption,
}: {
  photos: string[];
  index: number | null;
  onIndex: (i: number) => void;
  onClose: () => void;
  caption: string;
}) {
  const closeRef = useRef<HTMLButtonElement>(null);
  const open = index !== null;
  const many = photos.length > 1;

  useEffect(() => {
    if (!open) return;
    const prevFocus = document.activeElement as HTMLElement | null;
    closeRef.current?.focus();
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prevOverflow;
      prevFocus?.focus?.();
    };
  }, [open]);

  useEffect(() => {
    if (index === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      else if (many && e.key === "ArrowRight") onIndex((index + 1) % photos.length);
      else if (many && e.key === "ArrowLeft") onIndex((index - 1 + photos.length) % photos.length);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [index, many, photos.length, onClose, onIndex]);

  const btn = "flex h-11 w-11 items-center justify-center rounded-full border border-cream/30 text-cream hover:bg-cream/10";

  // Портал в body: карточка заказа анимируется transform-ом, а fixed внутри transform «прилипает» к карточке.
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return null;

  return createPortal(
    <>
      {index !== null && (
        // Без анимации прозрачности: в фоновой вкладке/WebView она «застревала» на полупрозрачном фоне.
        <div
          role="dialog"
          aria-modal="true"
          aria-label={caption}
          className="fixed inset-0 z-[60] flex flex-col bg-choc pb-[var(--sab)]"
          onClick={onClose}
        >
          <div className="flex items-center justify-between gap-3 px-4 py-3 text-cream" onClick={(e) => e.stopPropagation()}>
            <p className="min-w-0 truncate text-[14px]">
              {caption}
              {many && (
                <span className="num text-cream/60">
                  {" "}
                  · {index + 1} из {photos.length}
                </span>
              )}
            </p>
            <div className="flex shrink-0 gap-2">
              <a href={photos[index]} target="_blank" rel="noreferrer" className={btn} aria-label="Открыть оригинал в новой вкладке" title="Открыть оригинал">
                <ExternalLink size={18} strokeWidth={1.5} />
              </a>
              <button ref={closeRef} type="button" onClick={onClose} className={btn} aria-label="Закрыть просмотр" title="Закрыть (Esc)">
                <X size={20} strokeWidth={1.5} />
              </button>
            </div>
          </div>
          <div className="relative flex min-h-0 flex-1 items-center justify-center px-4 pb-4">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={photos[index]}
              alt={`${caption}, фото ${index + 1}`}
              className="max-h-full max-w-full rounded-[12px] object-contain"
              onClick={(e) => e.stopPropagation()}
            />
            {many && (
              <>
                <button type="button" className={`${btn} absolute left-3 top-1/2 -translate-y-1/2 bg-choc/60`} aria-label="Предыдущее фото" onClick={(e) => { e.stopPropagation(); onIndex((index - 1 + photos.length) % photos.length); }}>
                  <ChevronLeft size={22} strokeWidth={1.5} />
                </button>
                <button type="button" className={`${btn} absolute right-3 top-1/2 -translate-y-1/2 bg-choc/60`} aria-label="Следующее фото" onClick={(e) => { e.stopPropagation(); onIndex((index + 1) % photos.length); }}>
                  <ChevronRight size={22} strokeWidth={1.5} />
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </>,
    document.body,
  );
}
