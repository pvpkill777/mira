"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { KeyRound, Loader2, ShieldOff } from "lucide-react";
import type { AdminData } from "@/lib/server/admin-data";
import { Labeled, Panel, Toggle, inputCls, useApi, useNotify } from "./ui";
import { ImageField } from "./ImageField";

const WEEKDAYS = [
  { d: 1, l: "Пн" },
  { d: 2, l: "Вт" },
  { d: 3, l: "Ср" },
  { d: 4, l: "Чт" },
  { d: 5, l: "Пт" },
  { d: 6, l: "Сб" },
  { d: 0, l: "Вс" },
];

export function SettingsTab({ data }: { data: AdminData }) {
  const { call, pending } = useApi();
  const s = data.settings;
  const [v, setV] = useState({
    brandName: s.brandName,
    ownerName: s.ownerName,
    tagline: s.tagline,
    city: s.city,
    avatarUrl: s.avatarUrl,
    heroImageUrl: s.heroImageUrl,
    telegram: s.telegram,
    whatsapp: s.whatsapp,
    instagram: s.instagram,
    pickupAddress: s.pickupAddress,
    paymentDetails: s.paymentDetails,
    timeSlots: s.timeSlots.split(",").join("\n"),
    closedWeekdays: s.closedWeekdays.split(",").filter(Boolean).map(Number),
    defaultDailyLimit: String(s.defaultDailyLimit),
    urgentSurchargePct: String(s.urgentSurchargePct),
    prepaymentPct: String(s.prepaymentPct),
    deliveryFee: String(s.deliveryFee),
    bookingHorizonDays: String(s.bookingHorizonDays),
    minLeadHours: String(s.minLeadHours),
    urgentHours: String(s.urgentHours),
    pickupEnabled: s.pickupEnabled,
    deliveryEnabled: s.deliveryEnabled,
  });
  const set = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setV({ ...v, [k]: e.target.value });
  const num = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement>) => setV({ ...v, [k]: e.target.value.replace(/\D/g, "") });

  const notify = useNotify();
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    // Пустые поля превращались в 0, а предоплата могла стать больше 100 % — сайт переставал принимать заказы.
    const problem =
      !v.timeSlots.trim()
        ? "Укажите хотя бы один интервал выдачи"
        : Number(v.prepaymentPct) > 100
          ? "Предоплата — не больше 100 %"
          : !v.defaultDailyLimit || Number(v.defaultDailyLimit) < 1
            ? "Лимит тортов в день — от 1. Чтобы взять паузу, закройте даты в календаре."
            : !v.bookingHorizonDays || Number(v.bookingHorizonDays) < 1
              ? "Запись вперёд — хотя бы на 1 день"
              : v.minLeadHours === "" || Number(v.minLeadHours) > 72
                ? "Приём заказа закрывается — от 0 до 72 часов до интервала"
                : v.urgentHours === "" || Number(v.urgentHours) > 168
                  ? "Срочный заказ — от 0 до 168 часов (неделя)"
                  : !v.pickupEnabled && !v.deliveryEnabled
                    ? "Оставьте включённым хотя бы один способ получения — самовывоз или доставку"
                    : null;
    if (problem) {
      notify(problem, "error");
      return;
    }
    call(
      "PUT",
      "/api/admin/settings",
      {
        ...v,
        timeSlots: v.timeSlots
          .split(/\n|,/)
          .map((x) => x.trim().replace(/\s*-\s*/, "–"))
          .filter(Boolean)
          .join(","),
        closedWeekdays: v.closedWeekdays.join(","),
        defaultDailyLimit: Number(v.defaultDailyLimit),
        urgentSurchargePct: Number(v.urgentSurchargePct),
        prepaymentPct: Number(v.prepaymentPct),
        deliveryFee: Number(v.deliveryFee),
        bookingHorizonDays: Number(v.bookingHorizonDays),
        minLeadHours: Number(v.minLeadHours),
        urgentHours: Number(v.urgentHours),
      },
      "Настройки сохранены",
    );
  };

  return (
    <form onSubmit={save}>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h1 className="display text-[38px] sm:text-[46px]">Настройки</h1>
        <button type="submit" disabled={pending} className="btn-primary">
          Сохранить настройки
        </button>
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <Panel title="Бренд">
          <div className="grid gap-3 sm:grid-cols-2">
            <Labeled label="Название">
              <input className={inputCls} value={v.brandName} onChange={set("brandName")} />
            </Labeled>
            <Labeled label="Имя кондитера">
              <input className={inputCls} value={v.ownerName} onChange={set("ownerName")} />
            </Labeled>
            <Labeled label="Короткое УТП" className="sm:col-span-2">
              <input className={inputCls} value={v.tagline} onChange={set("tagline")} />
            </Labeled>
            <Labeled label="Город">
              <input className={inputCls} value={v.city} onChange={set("city")} />
            </Labeled>
            <ImageField label="Фото кондитера (необязательно)" value={v.avatarUrl} onChange={(url) => setV({ ...v, avatarUrl: url })} />
            <div className="sm:col-span-2">
              <ImageField label="Главное фото на сайте" value={v.heroImageUrl} onChange={(url) => setV({ ...v, heroImageUrl: url })} />
            </div>
          </div>
        </Panel>

        <Panel title="Контакты и оплата">
          <div className="grid gap-3 sm:grid-cols-2">
            <Labeled label="Telegram (ник)">
              <input className={inputCls} value={v.telegram} onChange={set("telegram")} placeholder="mira_cakes" />
            </Labeled>
            <Labeled label="WhatsApp (номер)">
              <input className={`${inputCls} num`} value={v.whatsapp} onChange={set("whatsapp")} placeholder="79990001122" />
            </Labeled>
            <Labeled label="Instagram">
              <input className={inputCls} value={v.instagram} onChange={set("instagram")} />
            </Labeled>
            <Labeled label="Адрес самовывоза">
              <input className={inputCls} value={v.pickupAddress} onChange={set("pickupAddress")} />
            </Labeled>
            <Labeled label="Реквизиты для предоплаты — подставляются в сообщение клиенту" className="sm:col-span-2">
              <textarea className={`${inputCls} min-h-[70px]`} value={v.paymentDetails} onChange={set("paymentDetails")} />
            </Labeled>
          </div>
        </Panel>

        <Panel title="Запись и цены">
          <div className="grid grid-cols-2 gap-3">
            <Labeled label="Тортов в день (по умолчанию)">
              <input className={`${inputCls} num`} inputMode="numeric" value={v.defaultDailyLimit} onChange={num("defaultDailyLimit")} />
            </Labeled>
            <Labeled label="Запись вперёд, дней">
              <input className={`${inputCls} num`} inputMode="numeric" value={v.bookingHorizonDays} onChange={num("bookingHorizonDays")} />
            </Labeled>
            <Labeled label="Предоплата, %">
              <input className={`${inputCls} num`} inputMode="numeric" value={v.prepaymentPct} onChange={num("prepaymentPct")} />
            </Labeled>
            <Labeled label="Срочный заказ, +%">
              <input className={`${inputCls} num`} inputMode="numeric" value={v.urgentSurchargePct} onChange={num("urgentSurchargePct")} />
            </Labeled>
            <Labeled label="Доставка, ₽">
              <input className={`${inputCls} num`} inputMode="numeric" value={v.deliveryFee} onChange={num("deliveryFee")} />
            </Labeled>
          </div>
          <fieldset className="mt-4">
            <legend className="mb-1.5 text-[12px] font-medium text-muted">Выходные по графику</legend>
            <div className="flex flex-wrap gap-1.5">
              {WEEKDAYS.map(({ d, l }) => {
                const on = v.closedWeekdays.includes(d);
                return (
                  <button
                    key={d}
                    type="button"
                    aria-pressed={on}
                    onClick={() => setV({ ...v, closedWeekdays: on ? v.closedWeekdays.filter((x) => x !== d) : [...v.closedWeekdays, d] })}
                    className={`h-11 w-11 rounded-full border text-[13px] ${on ? "border-choc bg-choc text-cream" : "border-line-strong"}`}
                  >
                    {l}
                  </button>
                );
              })}
            </div>
          </fieldset>
        </Panel>

        <Panel title="Время выдачи">
          <Labeled label="Интервалы — каждый с новой строки">
            <textarea className={`${inputCls} num min-h-[150px]`} value={v.timeSlots} onChange={set("timeSlots")} />
          </Labeled>
        </Panel>

        <Panel title="Правила записи">
          <div className="grid gap-3 sm:grid-cols-2">
            <Labeled label="Приём заказа закрывается за N часов до интервала">
              <input className={`${inputCls} num`} inputMode="numeric" maxLength={2} value={v.minLeadHours} onChange={num("minLeadHours")} />
            </Labeled>
            <Labeled label="Срочным считается заказ меньше чем за N часов">
              <input className={`${inputCls} num`} inputMode="numeric" maxLength={3} value={v.urgentHours} onChange={num("urgentHours")} />
            </Labeled>
          </div>
          <p className="mt-2 text-[12px] leading-snug text-muted">
            {v.minLeadHours !== "" && v.urgentHours !== "" ? rulesHint(Number(v.minLeadHours), Number(v.urgentHours), v.urgentSurchargePct) : "Заполните оба поля — можно 0."}
          </p>

          <p className="mb-1 mt-4 text-[12px] font-medium text-muted">Способы получения</p>
          <ul className="divide-y divide-line border-y border-line">
            {(
              [
                ["pickupEnabled", "Самовывоз", v.pickupAddress ? `по адресу: ${v.pickupAddress}` : "адрес — в «Контактах и оплате»"],
                ["deliveryEnabled", "Доставка", Number(v.deliveryFee) ? `${v.deliveryFee} ₽ к заказу` : "бесплатно"],
              ] as const
            ).map(([k, label, hint]) => (
              <li key={k} className="flex min-h-[52px] items-center justify-between gap-3 py-1.5">
                <span className="min-w-0">
                  <span className="block text-[15px]">{label}</span>
                  <span className="block truncate text-[12px] text-muted">{v[k] ? hint : "выключено — клиенты не увидят этот вариант"}</span>
                </span>
                <Toggle
                  on={v[k]}
                  label={label}
                  onChange={(on) => {
                    const other = k === "pickupEnabled" ? v.deliveryEnabled : v.pickupEnabled;
                    if (!on && !other) {
                      notify("Хотя бы один способ получения должен остаться включённым", "error");
                      return;
                    }
                    setV({ ...v, [k]: on });
                  }}
                />
              </li>
            ))}
          </ul>
          <p className="mt-2 text-[12px] leading-snug text-muted">Если оставить один способ, на сайте не будет переключателя — клиент сразу увидит, как получит торт.</p>
        </Panel>

        <PinPanel pinLength={s.adminPinLength} fromCabinet={s.pinFromCabinet} />

        <SecurityPanel />
      </div>
    </form>
  );
}

/** Пояснение правил записи простыми словами — чтобы было видно, что именно поменяется для клиента. */
function rulesHint(lead: number, urgent: number, pct: string): string {
  const h = (n: number) => `${n} ${n % 10 === 1 && n % 100 !== 11 ? "час" : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14) ? "часа" : "часов"}`;
  const first =
    lead === 0
      ? "Интервал можно заказать до самого его начала."
      : `Заказ на интервал принимается не позже чем за ${h(lead)} до начала${lead < 14 ? ` — например, на 14:00 до ${String(14 - lead).padStart(2, "0")}:00` : ""}.`;
  const second =
    urgent === 0
      ? "Срочных заказов нет — наценка не начисляется."
      : urgent <= lead
        ? `Срочность не сработает: приём и так закрывается за ${h(lead)}, а срочным считается заказ меньше чем за ${h(urgent)}.`
        : `Заказ меньше чем за ${h(urgent)} до начала — срочный, к цене +${pct || 0}%.`;
  return `${first} ${second}`;
}

/** Смена PIN: текущий + новый дважды. После смены все сессии завершаются — входить нужно с новым PIN. */
function PinPanel({ pinLength, fromCabinet }: { pinLength: number; fromCabinet: boolean }) {
  const router = useRouter();
  const notify = useNotify();
  const [cur, setCur] = useState("");
  const [next, setNext] = useState("");
  const [repeat, setRepeat] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const digits = (fn: (v: string) => void) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    fn(e.target.value.replace(/\D/g, "").slice(0, 8));
  };

  const submit = async () => {
    const problem = !cur
      ? "Введите текущий PIN"
      : !/^\d{4,8}$/.test(next)
        ? "Новый PIN — от 4 до 8 цифр"
        : next !== repeat
          ? "Новый PIN и повтор не совпадают"
          : next === cur
            ? "Новый PIN совпадает с текущим"
            : null;
    if (problem) {
      setError(problem);
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/admin/pin", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ currentPin: cur, newPin: next }) });
      const data = await res.json().catch(() => ({}));
      if (res.status === 401) {
        notify("Сессия закончилась — войдите снова", "error");
        router.refresh();
        return;
      }
      if (!res.ok) {
        setError(data.error ?? "Не получилось сменить PIN. Попробуйте ещё раз.");
        return;
      }
      setDone(true);
    } catch {
      setError("Нет соединения с сервером. Проверьте интернет и попробуйте ещё раз.");
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    return (
      <Panel title="PIN для входа" className="lg:col-span-2">
        <p className="max-w-prose text-[15px] leading-relaxed">PIN изменён. Все устройства вышли из кабинета — войдите с новым PIN.</p>
        <button type="button" onClick={() => router.refresh()} className="btn-primary mt-4">
          Войти с новым PIN
        </button>
      </Panel>
    );
  }

  return (
    <Panel title="PIN для входа" className="lg:col-span-2">
      <p className="max-w-prose text-[14px] leading-relaxed text-muted">
        {fromCabinet ? `Сейчас PIN из ${pinLength} цифр задан здесь, в кабинете.` : "Сейчас действует PIN, заданный при установке сайта."} После смены все устройства
        выйдут из кабинета, войти можно будет только с новым PIN. Запишите его в надёжном месте.
      </p>
      {/* Не <form>: панель находится внутри формы настроек, вложенные формы недопустимы. Enter обрабатываем сами. */}
      <div
        className="mt-4 grid gap-3 sm:grid-cols-3"
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            submit();
          }
        }}
      >
        <Labeled label="Текущий PIN">
          <input className={`${inputCls} num`} type="password" inputMode="numeric" autoComplete="current-password" value={cur} onChange={digits(setCur)} />
        </Labeled>
        <Labeled label="Новый PIN — 4–8 цифр">
          <input className={`${inputCls} num`} type="password" inputMode="numeric" autoComplete="new-password" value={next} onChange={digits(setNext)} />
        </Labeled>
        <Labeled label="Новый PIN ещё раз">
          <input className={`${inputCls} num`} type="password" inputMode="numeric" autoComplete="new-password" value={repeat} onChange={digits(setRepeat)} />
        </Labeled>
      </div>
      {error && (
        <p role="alert" className="mt-3 text-[13px] text-caramel-deep">
          {error}
        </p>
      )}
      <button type="button" disabled={busy} onClick={submit} className="btn-ghost mt-4 min-h-11 !px-4 !py-2.5 text-[14px]">
        {busy ? <Loader2 size={15} strokeWidth={1.5} className="animate-spin" /> : <KeyRound size={15} strokeWidth={1.5} />} Сменить PIN
      </button>
    </Panel>
  );
}

/** Выход на всех устройствах — если телефон потерян или в кабинет заходили с чужого устройства. */
function SecurityPanel() {
  const router = useRouter();
  const notify = useNotify();
  const [ask, setAsk] = useState(false);
  const [busy, setBusy] = useState(false);

  const logoutAll = async () => {
    setBusy(true);
    try {
      const res = await fetch("/api/admin/logout-all", { method: "POST" });
      if (!res.ok) throw new Error();
      router.refresh();
    } catch {
      notify("Не получилось завершить сессии. Проверьте интернет и попробуйте ещё раз.", "error");
      setBusy(false);
    }
  };

  return (
    <Panel title="Безопасность" className="lg:col-span-2">
      <p className="max-w-prose text-[14px] leading-relaxed text-muted">
        Если телефон потерян или вы входили в кабинет на чужом устройстве — завершите все сессии. Войти снова можно будет по PIN. Если PIN мог кто-то узнать — смените его в блоке «PIN для входа».
      </p>
      {ask ? (
        <div className="mt-4 flex flex-wrap items-center gap-2 text-[14px]">
          <span>Выйти на всех устройствах, включая это?</span>
          <button type="button" disabled={busy} onClick={logoutAll} className="btn-primary min-h-11 !bg-caramel-deep !px-4 !py-2.5 text-[13px]">
            {busy && <Loader2 size={15} strokeWidth={1.5} className="animate-spin" />}
            Да, выйти везде
          </button>
          <button type="button" onClick={() => setAsk(false)} className="btn-ghost min-h-11 !px-4 !py-2.5 text-[13px]">
            Отмена
          </button>
        </div>
      ) : (
        <button type="button" onClick={() => setAsk(true)} className="btn-ghost mt-4 min-h-11 !px-4 !py-2.5 text-[13px]">
          <ShieldOff size={15} strokeWidth={1.5} /> Выйти на всех устройствах
        </button>
      )}
    </Panel>
  );
}
