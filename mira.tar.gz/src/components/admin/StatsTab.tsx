"use client";

import { Copy, Printer } from "lucide-react";
import type { AdminData, BakePlanDay } from "@/lib/server/admin-data";
import { formatPrice, formatWeight } from "@/lib/format";
import { humanDate, relativeDayLabel } from "@/lib/dates";
import { Panel, copyText, useNotify } from "./ui";

/** План выпечки простым текстом — для заметок, чата с помощницей или печати с телефона. */
function bakePlanText(plan: BakePlanDay[]): string {
  const out: string[] = ["План выпечки"];
  for (const day of plan) {
    const total = day.orders.reduce((a, o) => a + o.weightGrams, 0);
    out.push("", `${relativeDayLabel(day.date) ?? ""} ${humanDate(day.date)}${day.orders.length ? ` — ${formatWeight(total)}` : ""}`.trim());
    if (!day.orders.length) out.push("  свободный день");
    for (const o of day.orders) {
      const extra = [o.decor.join(", "), o.inscription && `надпись «${o.inscription}»`, !o.confirmed && "без предоплаты", o.delivery && "доставка"].filter(Boolean);
      out.push(`  ${o.timeSlot.split("–")[0]} · №${o.number} · ${o.fillingName} · ${formatWeight(o.weightGrams)}${extra.length ? ` (${extra.join("; ")})` : ""}`);
    }
  }
  return out.join("\n").replace(/ /g, " ");
}

export function StatsTab({ data }: { data: AdminData }) {
  const s = data.stats;
  const notify = useNotify();
  const maxGrams = Math.max(1, ...s.fillingTotals.map((f) => f.grams));

  return (
    <div>
      <h1 className="display text-[38px] sm:text-[46px]">Аналитика</h1>
      <p className="mt-1 text-[14px] text-muted">Выручка — по подтверждённым и выполненным заказам, по дате выдачи.</p>

      <div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Выручка за неделю" value={formatPrice(s.weekRevenue)} sub={s.weekExpected ? `ещё ${formatPrice(s.weekExpected)} ждут предоплаты` : `${s.weekOrders} заказов`} />
        <Stat label="Выручка за месяц" value={formatPrice(s.monthRevenue)} sub={s.monthExpected ? `ещё ${formatPrice(s.monthExpected)} ждут предоплаты` : `${s.monthOrders} заказов`} />
        <Stat label="Заказов в месяце" value={String(s.monthOrders)} sub={`на неделе — ${s.weekOrders}`} />
        <Stat label="Средний чек" value={s.avgCheck ? formatPrice(s.avgCheck) : "—"} sub="за текущий месяц" />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1.3fr_1fr]">
        <Panel
          title="Выпечка на 3 дня"
          className="print-area"
          action={
            <div className="flex gap-2 print:hidden">
              <button
                type="button"
                onClick={async () =>
                  (await copyText(bakePlanText(s.bakePlan)))
                    ? notify("План скопирован — можно вставить в заметки или чат")
                    : notify("Не получилось скопировать. Выделите план и скопируйте вручную.", "error")
                }
                className="btn-ghost h-11 w-11 !p-0"
                aria-label="Скопировать план выпечки текстом"
                title="Скопировать текстом"
              >
                <Copy size={16} strokeWidth={1.5} />
              </button>
              <button type="button" onClick={() => window.print()} className="btn-ghost h-11 w-11 !p-0" aria-label="Распечатать план выпечки" title="Распечатать">
                <Printer size={16} strokeWidth={1.5} />
              </button>
            </div>
          }
        >
          <div className="grid gap-4">
            {s.bakePlan.map((day) => (
              <div key={day.date}>
                <div className="flex items-baseline justify-between border-b border-line pb-1.5">
                  <p className="text-[14px] font-medium first-letter:uppercase">
                    {relativeDayLabel(day.date) ?? ""} <span className="text-muted">· {humanDate(day.date)}</span>
                  </p>
                  <p className="num text-[12px] text-muted">{formatWeight(day.orders.reduce((a, o) => a + o.weightGrams, 0))}</p>
                </div>
                {day.orders.length === 0 ? (
                  <p className="py-2 text-[13px] text-muted">Свободный день</p>
                ) : (
                  <ul className="divide-y divide-line text-[14px]">
                    {day.orders.map((o) => (
                      <li key={o.number} className="grid grid-cols-[auto_1fr_auto] items-baseline gap-3 py-2">
                        <span className="num text-[12px] text-muted">{o.timeSlot.split("–")[0]}</span>
                        <span>
                          {o.fillingName} <span className="num text-[12px] text-muted">№{o.number}</span>
                          {o.decor.length > 0 && <span className="block text-[12px] text-muted">{o.decor.join(", ")}</span>}
                          {o.inscription && <span className="block text-[12px] text-muted">Надпись: «{o.inscription}»</span>}
                          {(!o.confirmed || o.delivery) && (
                            <span className="block text-[12px] text-caramel-deep">
                              {[!o.confirmed && "предоплата ещё не получена", o.delivery && "доставка"].filter(Boolean).join(" · ")}
                            </span>
                          )}
                        </span>
                        <span className="num">{formatWeight(o.weightGrams)}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </Panel>

        <div className="grid content-start gap-5">
          <Panel title="Закупка: начинки">
            {s.fillingTotals.length === 0 ? (
              <p className="text-[14px] text-muted">На ближайшие 3 дня заказов нет.</p>
            ) : (
              <ul className="grid gap-3">
                {s.fillingTotals.map((f) => (
                  <li key={f.name}>
                    <div className="flex justify-between gap-3 text-[14px]">
                      <span>{f.name}</span>
                      <span className="num">
                        {formatWeight(f.grams)} <span className="text-muted">· {f.count} шт.</span>
                      </span>
                    </div>
                    <div className="mt-1.5 h-[3px] rounded-full bg-line">
                      <div className="h-full rounded-full bg-caramel" style={{ width: `${(f.grams / maxGrams) * 100}%` }} />
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
          {s.decorTotals.length > 0 && (
            <Panel title="Декор">
              <ul className="divide-y divide-line text-[14px]">
                {s.decorTotals.map((d) => (
                  <li key={d.name} className="flex justify-between py-2">
                    <span>{d.name}</span>
                    <span className="num">{d.count} шт.</span>
                  </li>
                ))}
              </ul>
            </Panel>
          )}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="rounded-[20px] border border-line-strong bg-white/45 p-4">
      <p className="text-[12px] text-muted">{label}</p>
      <p className="display num mt-2 text-[30px] leading-none sm:text-[34px]">{value}</p>
      <p className="mt-2 text-[12px] text-muted">{sub}</p>
    </div>
  );
}
