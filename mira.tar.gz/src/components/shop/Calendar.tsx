"use client";

import { motion } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useMemo, useState } from "react";
import type { Availability } from "@/lib/types";
import { MONTHS, MONTHS_GEN, WEEKDAYS_SHORT, bakeryNow, fromKey, toKey } from "@/lib/dates";

export function Calendar({
  availability,
  value,
  onChange,
}: {
  availability: Availability;
  value: string | null;
  onChange: (date: string) => void;
}) {
  const keys = useMemo(() => Object.keys(availability).sort(), [availability]);
  const first = keys[0] ? fromKey(keys[0]) : bakeryNow();
  const last = keys.at(-1) ? fromKey(keys.at(-1)!) : bakeryNow();
  const initial = value ? fromKey(value) : first;
  const [cursor, setCursor] = useState(new Date(initial.getFullYear(), initial.getMonth(), 1));
  const [dir, setDir] = useState(0);

  const canPrev = cursor > new Date(first.getFullYear(), first.getMonth(), 1);
  const canNext = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1) <= last;

  const cells = useMemo(() => {
    const y = cursor.getFullYear();
    const m = cursor.getMonth();
    const offset = (new Date(y, m, 1).getDay() + 6) % 7; // понедельник — первый
    const daysInMonth = new Date(y, m + 1, 0).getDate();
    const out: (string | null)[] = Array(offset).fill(null);
    for (let d = 1; d <= daysInMonth; d++) out.push(toKey(new Date(y, m, d)));
    return out;
  }, [cursor]);

  const move = (n: number) => {
    setDir(n);
    setCursor((c) => new Date(c.getFullYear(), c.getMonth() + n, 1));
  };

  return (
    <div className="rounded-[24px] border border-line-strong bg-white/40 p-3 sm:p-5">
      <div className="mb-3 flex items-center justify-between px-1">
        <button
          type="button"
          onClick={() => move(-1)}
          disabled={!canPrev}
          aria-label="Предыдущий месяц"
          className="flex h-11 w-11 items-center justify-center rounded-full transition-colors hover:bg-whip disabled:opacity-25"
        >
          <ChevronLeft size={20} strokeWidth={1.5} />
        </button>
        <motion.p key={cursor.getTime()} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} className="display text-[24px] capitalize">
          {MONTHS[cursor.getMonth()]} <span className="num text-muted">{cursor.getFullYear()}</span>
        </motion.p>
        <button
          type="button"
          onClick={() => move(1)}
          disabled={!canNext}
          aria-label="Следующий месяц"
          className="flex h-11 w-11 items-center justify-center rounded-full transition-colors hover:bg-whip disabled:opacity-25"
        >
          <ChevronRight size={20} strokeWidth={1.5} />
        </button>
      </div>

      <div className="grid grid-cols-7 text-center text-[11px] uppercase tracking-[0.1em] text-muted">
        {WEEKDAYS_SHORT.map((w) => (
          <div key={w} className="py-1.5">
            {w}
          </div>
        ))}
      </div>

      <motion.div
        key={cursor.getTime()}
        initial={{ opacity: 0, x: dir * 24 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ type: "spring", stiffness: 320, damping: 32 }}
        className="grid grid-cols-7 gap-y-1"
        role="grid"
      >
        {cells.map((key, i) => {
          if (!key) return <div key={`e${i}`} />;
          const info = availability[key] ?? { status: "past", left: 0 };
          const selectable = info.status === "free" || info.status === "few";
          const selected = key === value;
          const day = fromKey(key).getDate();
          const label =
            info.status === "free"
              ? "свободно"
              : info.status === "few"
                ? "осталось 1 место"
                : info.status === "full"
                  ? "мест нет"
                  : info.status === "closed"
                    ? "закрыто"
                    : info.status === "off"
                      ? "выходной"
                      : "недоступно";
          return (
            <div key={key} className="flex justify-center">
              <button
                type="button"
                disabled={!selectable}
                onClick={() => onChange(key)}
                aria-pressed={selected}
                aria-label={`${day} ${MONTHS_GEN[cursor.getMonth()]}, ${label}`}
                className={`relative flex h-12 w-full max-w-12 flex-col items-center justify-center rounded-full text-[15px] transition-colors ${
                  selectable ? "hover:bg-whip" : "cursor-not-allowed"
                } ${info.status === "past" ? "text-choc/20" : ""} ${
                  info.status === "full" || info.status === "closed" || info.status === "off" ? "text-choc/35" : ""
                }`}
              >
                {selected && (
                  <motion.span layoutId="cal-selected" className="absolute inset-0 rounded-full bg-choc" transition={{ type: "spring", stiffness: 500, damping: 36 }} />
                )}
                {selectable && !selected && <span className="absolute inset-[3px] rounded-full border border-line-strong bg-white/60" aria-hidden />}
                <span
                  className={`num relative ${selected ? "text-cream" : ""} ${
                    info.status === "full" || info.status === "closed" ? "line-through decoration-choc/40" : ""
                  }`}
                >
                  {day}
                </span>
                {info.status === "few" && (
                  <span className={`absolute bottom-[7px] h-1 w-1 rounded-full ${selected ? "bg-cream" : "bg-caramel"}`} aria-hidden />
                )}
              </button>
            </div>
          );
        })}
      </motion.div>

      <ul className="mt-4 flex flex-wrap gap-x-4 gap-y-2 border-t border-line px-1 pt-3 text-[12px] text-muted">
        <li className="flex items-center gap-1.5">
          <span className="h-3 w-3 rounded-full border border-line-strong bg-white" /> свободно
        </li>
        <li className="flex items-center gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-caramel" /> последнее место
        </li>
        <li className="flex items-center gap-1.5">
          <span className="line-through">12</span> мест нет
        </li>
        <li className="flex items-center gap-1.5">
          <span className="text-choc/35">12</span> выходной
        </li>
      </ul>
    </div>
  );
}
