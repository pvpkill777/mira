"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Clock } from "lucide-react";
import type { DecorDTO } from "@/lib/types";
import { formatPrice } from "@/lib/format";
import { hoursLabel } from "@/lib/dates";
import { typograph } from "@/lib/content";
import { SwitchVisual } from "@/components/ui/Switch";
import { SectionTitle } from "./SectionTitle";

export function DecorStep({
  decor,
  decorIds,
  onToggle,
  urgent,
  urgentPct,
  urgentFee,
  urgentLocked,
  onUrgent,
  urgentHours,
}: {
  urgentHours: number;
  decor: DecorDTO[];
  decorIds: string[];
  onToggle: (id: string) => void;
  urgent: boolean;
  urgentPct: number;
  urgentFee: number;
  urgentLocked: string | null;
  onUrgent: (v: boolean) => void;
}) {
  return (
    <section aria-labelledby="decor-title" className="scroll-mt-20" id="decor">
      <SectionTitle index="03 — Декор" title="Финальные штрихи" hint="Можно выбрать несколько" id="decor-title" />
      {/* Без верхней линии: она дублировала линию под заголовком раздела */}
      <ul className="-mt-2 divide-y divide-line border-b border-line">
        {decor.map((d) => {
          const on = decorIds.includes(d.id);
          return (
            <li key={d.id}>
              <button
                type="button"
                role="switch"
                aria-checked={on}
                onClick={() => onToggle(d.id)}
                className="flex w-full items-center gap-4 py-4 text-left"
              >
                <span className="min-w-0 flex-1">
                  <span className="block text-[15px] font-medium">{typograph(d.name)}</span>
                  {d.description && <span className="mt-0.5 block text-[13px] text-muted">{typograph(d.description)}</span>}
                </span>
                <span className={`num shrink-0 text-[14px] ${d.price === 0 ? "text-sage" : ""}`}>
                  {d.price === 0 ? "бесплатно" : `+${formatPrice(d.price)}`}
                </span>
                <SwitchVisual on={on} />
              </button>
            </li>
          );
        })}
        {/* Порог срочности задаётся в кабинете; 0 — срочные заказы не принимаются, строку не показываем. */}
        {urgentHours > 0 && (
        <li>
          <button
            type="button"
            role="switch"
            aria-checked={urgent}
            onClick={() => onUrgent(!urgent)}
            className="flex w-full items-center gap-4 py-4 text-left"
          >
            <span className="min-w-0 flex-1">
              <span className="flex items-center gap-2 text-[15px] font-medium">
                <Clock size={16} strokeWidth={1.5} className="text-caramel" />
                Срочный заказ
              </span>
              <span className="mt-0.5 block text-[13px] text-muted">До выдачи меньше {hoursLabel(urgentHours)}</span>
            </span>
            <span className="num shrink-0 text-[14px] text-caramel-deep">
              +{urgentPct}%{urgent && urgentFee > 0 ? <span className="block text-right text-[12px] text-muted">{formatPrice(urgentFee)}</span> : null}
            </span>
            <SwitchVisual on={urgent} />
          </button>
        </li>
        )}
      </ul>
      <AnimatePresence>
        {urgentLocked && (
          <motion.p
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="mt-3 text-[13px] text-muted"
          >
            {urgentLocked}
          </motion.p>
        )}
      </AnimatePresence>
    </section>
  );
}
