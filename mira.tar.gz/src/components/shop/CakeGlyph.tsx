/** Силуэт торта в профиль — визуальная подсказка размера. Масштаб зависит от веса. */
export function CakeGlyph({ grams, active }: { grams: number; active: boolean }) {
  const stroke = active ? "#231F1E" : "rgba(35,31,30,0.55)";
  const fill = active ? "#F1E1D7" : "#F2ECE4";
  const twoTier = grams >= 3200;
  const t = Math.min(1, Math.max(0, (grams - 400) / 3200));
  const w = 26 + t * 36; // ширина нижнего яруса
  const h = 14 + t * 10;
  const baseY = 54;
  const cx = 40;
  const tiers: { w: number; h: number }[] = twoTier ? [{ w, h: h * 0.85 }, { w: w * 0.62, h: h * 0.75 }] : [{ w, h }];
  let y = baseY;
  return (
    <svg viewBox="0 0 80 60" className="h-[52px] w-[72px]" aria-hidden>
      <line x1={cx - w / 2 - 8} x2={cx + w / 2 + 8} y1={baseY + 0.5} y2={baseY + 0.5} stroke={stroke} strokeWidth="1" />
      {tiers.map((tier, i) => {
        y -= tier.h;
        const x = cx - tier.w / 2;
        const drip = `M ${x} ${y + 4} q ${tier.w / 8} 4 ${tier.w / 4} 0 t ${tier.w / 4} 0 t ${tier.w / 4} 0 t ${tier.w / 4} 0`;
        return (
          <g key={i}>
            <rect x={x} y={y} width={tier.w} height={tier.h} rx="2.5" fill={fill} stroke={stroke} strokeWidth="1.2" />
            <path d={drip} fill="none" stroke={stroke} strokeWidth="1" opacity="0.7" />
          </g>
        );
      })}
      <circle cx={cx} cy={y - 3.5} r="2.6" fill="#B86B4B" />
    </svg>
  );
}
