"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, ChevronUp, Loader2, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { Quote } from "@/lib/pricing";
import { formatWeight } from "@/lib/format";
import { AnimatedPrice } from "@/components/ui/AnimatedPrice";
import { useFocusTrap } from "@/lib/useFocusTrap";
import { Receipt } from "./Receipt";

/** Плавающая нижняя панель (мобильные): вес, цена, кнопка заказа и раскрывающийся чек. */
export function StickyBar({
  quote,
  prepaymentPct,
  date,
  slot,
  delivery,
  inCheckout,
  submitting,
  onCheckout,
}: {
  quote: Quote;
  prepaymentPct: number;
  date: string | null;
  slot: string | null;
  delivery: boolean;
  inCheckout: boolean;
  submitting: boolean;
  onCheckout: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [typing, setTyping] = useState(false);
  // На первом экране панель не нужна: клиент ещё ничего не выбрал, а кнопка дублирует «Собрать торт».
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    let frame = 0;
    const check = () => {
      frame = 0;
      const el = document.getElementById("builder");
      setRevealed(el ? el.getBoundingClientRect().top < window.innerHeight * 0.85 : true);
    };
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(check);
    };
    check();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  const hidden = typing || !revealed;

  // Пока открыта клавиатура (фокус в поле ввода), панель уезжает вниз и не перекрывает поля.
  useEffect(() => {
    const isField = (el: EventTarget | null) =>
      el instanceof HTMLElement && (el.tagName === "TEXTAREA" || (el.tagName === "INPUT" && !["range", "checkbox", "radio", "button"].includes((el as HTMLInputElement).type)));
    const onIn = (e: FocusEvent) => isField(e.target) && setTyping(true);
    const onOut = (e: FocusEvent) => isField(e.target) && setTyping(false);
    document.addEventListener("focusin", onIn);
    document.addEventListener("focusout", onOut);
    return () => {
      document.removeEventListener("focusin", onIn);
      document.removeEventListener("focusout", onOut);
    };
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    // Страница под открытым чеком не должна прокручиваться.
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open]);

  // Длинный чек на низком экране (320×568, много декора) не помещается — тогда шторка прокручивается,
  // а свайп вниз отключаем: он перехватывал бы вертикальную прокрутку содержимого.
  const sheetRef = useRef<HTMLDivElement>(null);
  useFocusTrap(sheetRef, open);
  const [sheetScrolls, setSheetScrolls] = useState(false);
  useEffect(() => {
    const el = sheetRef.current;
    if (!open || !el) return;
    const measure = () => setSheetScrolls(el.scrollHeight > el.clientHeight + 1);
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    if (el.firstElementChild) ro.observe(el.firstElementChild);
    return () => ro.disconnect();
  }, [open, quote.lines.length]);

  return (
    <>
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              className="fixed inset-0 z-40 bg-choc/30 lg:hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
            />
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-label="Состав заказа"
              ref={sheetRef}
              tabIndex={-1}
              className="fixed inset-x-0 bottom-0 z-50 max-h-[calc(100dvh-12px)] overflow-y-auto overscroll-contain rounded-t-[28px] border-t border-line bg-whip px-5 pb-[calc(110px+var(--sab))] pt-2 lg:hidden"
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 380, damping: 38 }}
              drag={sheetScrolls ? false : "y"}
              dragConstraints={{ top: 0, bottom: 0 }}
              dragElastic={{ top: 0, bottom: 0.6 }}
              onDragEnd={(_, info) => info.offset.y > 80 && setOpen(false)}
            >
              <div>
                {/* Ручка и крестик — отдельной строкой, чтобы крестик не наезжал на вес в шапке чека */}
                <div className="relative mb-1 flex h-11 items-center justify-center">
                  <div className="h-1 w-10 rounded-full bg-choc/20" />
                  <button
                    type="button"
                    onClick={() => setOpen(false)}
                    className="absolute -right-2 top-0 flex h-11 w-11 items-center justify-center rounded-full hover:bg-cream"
                    aria-label="Закрыть чек"
                  >
                    <X size={18} strokeWidth={1.5} />
                  </button>
                </div>
                <Receipt quote={quote} prepaymentPct={prepaymentPct} date={date} slot={slot} delivery={delivery} compact />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <motion.div
        initial={{ y: 120 }}
        animate={{ y: hidden ? 140 : 0 }}
        transition={{ type: "spring", stiffness: 260, damping: 30 }}
        inert={!revealed}
        className="fixed inset-x-0 bottom-0 z-[60] px-3 pb-[calc(10px+var(--sab))] lg:hidden"
      >
        <div className="mx-auto flex max-w-xl items-center gap-2 rounded-[24px] border border-line-strong bg-cream p-2 pl-4 shadow-[0_12px_40px_-12px_rgba(35,31,30,0.28)]">
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="flex min-w-0 flex-1 items-center gap-2 py-1 text-left"
            aria-expanded={open}
            aria-label="Показать состав заказа"
          >
            <span className="min-w-0 flex-1">
              <span className="num block truncate text-[12px] text-muted">
                {quote.weightGrams ? formatWeight(quote.weightGrams) : "—"}
                {quote.filling ? ` · ${quote.filling.name}` : ""}
              </span>
              {/* На 320 px пятизначная цена при кнопке «Отправить заявку» наезжала на стрелку — шрифт сжимается по ширине экрана */}
              <AnimatedPrice value={quote.total} className="display block whitespace-nowrap text-[clamp(22px,7.2vw,28px)] leading-[1.05]" />
            </span>
            <ChevronUp size={18} strokeWidth={1.5} className={`shrink-0 text-muted transition-transform ${open ? "rotate-180" : ""}`} />
          </button>
          {inCheckout ? (
            <button type="submit" form="order-form" disabled={submitting} onClick={() => setOpen(false)} className="btn-primary shrink-0 !px-4 py-[15px] text-[14px] min-[360px]:!px-5">
              {submitting ? <Loader2 size={16} className="animate-spin" /> : null}
              Отправить заявку
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                onCheckout();
              }}
              className="btn-primary shrink-0 !px-4 py-[15px] text-[14px] min-[360px]:!px-5"
            >
              {date ? "Оформить заказ" : "Выбрать дату"}
              <ArrowRight size={16} strokeWidth={1.5} />
            </button>
          )}
        </div>
      </motion.div>
    </>
  );
}
