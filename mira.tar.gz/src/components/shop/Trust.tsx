"use client";

import { motion } from "framer-motion";
import { Quote as QuoteIcon } from "lucide-react";
import type { PublicSettings, SiteContent } from "@/lib/types";
import { Monogram } from "@/components/ui/Monogram";
import { fillTemplate, typograph } from "@/lib/content";

/*
 * Блок доверия: «О кондитере» и отзывы. Все тексты редактируются в кабинете («Тексты сайта»).
 * Пустые поля и списки скрываются; блок отзывов виден, только если есть хотя бы один включённый отзыв.
 */
export function Trust({ settings, content }: { settings: PublicSettings; content: Pick<SiteContent, "principles" | "reviews"> }) {
  const t = (s: string) => typograph(fillTemplate(s.trim(), settings));
  const title = t(settings.aboutTitle);
  // Кавычки-ёлочки добавляем сами; если кондитер написала их в тексте — не удваиваем.
  // Учитываем и вариант «…на фото». — кавычка перед финальной точкой.
  const quote = t(settings.aboutQuote).replace(/^[«"„]+/, "").replace(/[»"“]+([.!?…]*)$/, "$1");
  const story = t(settings.aboutText);
  const principles = content.principles.map((p) => ({ id: p.id, title: t(p.title), text: t(p.text) })).filter((p) => p.title || p.text);
  const reviews = content.reviews.map((r) => ({ id: r.id, name: t(r.title), text: t(r.text), detail: t(r.detail) })).filter((r) => r.text);

  return (
    <section aria-labelledby="about-title" className="scroll-mt-20" id="about">
      <div className="mb-6 border-b border-line pb-4">
        <p className="eyebrow">О кондитере</p>
        <h2 id="about-title" className="display mt-2 text-[36px] sm:text-[44px]">
          {title || settings.ownerName}
        </h2>
      </div>

      <div className={principles.length ? "grid gap-8 md:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] md:gap-10" : ""}>
        <div>
          <div className="flex items-center gap-4">
            {settings.avatarUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={settings.avatarUrl} alt={settings.ownerName} className="h-16 w-16 rounded-full border border-line object-cover" />
            ) : (
              <Monogram size={64} />
            )}
            <div>
              <p className="display text-[26px] leading-none">{settings.ownerName}</p>
              <p className="mt-1.5 text-[13px] text-muted">кондитер{settings.city ? ` · ${settings.city}` : ""}</p>
            </div>
          </div>
          {quote && (
            <p className="display mt-6 max-w-xl text-[23px] italic leading-[1.25] text-choc sm:text-[26px]">
              {/* По правилам точка ставится после закрывающей кавычки: «…на фото». */}
              {/(?<!\.)\.$/.test(quote) ? `«${quote.slice(0, -1)}».` : `«${quote}»`}
            </p>
          )}
          {story && <p className="mt-4 max-w-md whitespace-pre-line text-[15px] leading-relaxed text-muted">{story}</p>}
        </div>

        {principles.length > 0 && (
          <ul className="divide-y divide-line border-y border-line md:-mt-4 md:border-t-0">
            {principles.map((p, i) => (
              <li key={p.id} className="grid grid-cols-[32px_1fr] gap-x-3 py-4">
                <span className="display num pt-0.5 text-[20px] leading-none text-caramel-deep">{String(i + 1).padStart(2, "0")}</span>
                <span>
                  {p.title && <span className="block text-[15px] font-medium">{p.title}</span>}
                  {p.text && <span className={`${p.title ? "mt-1 " : ""}block text-[14px] leading-snug text-muted`}>{p.text}</span>}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {reviews.length > 0 && (
        <div className="mt-12">
          <div className="flex items-baseline justify-between gap-4">
            <p className="eyebrow">Отзывы</p>
            {settings.instagram && (
              <a
                href={`https://instagram.com/${settings.instagram}`}
                target="_blank"
                rel="noreferrer"
                className="text-[13px] text-muted underline decoration-line-strong underline-offset-4 hover:text-choc hover:decoration-choc"
              >
                Ещё отзывы в Instagram
              </a>
            )}
          </div>
          <ul className="no-scrollbar -mx-4 mt-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-1 sm:mx-0 sm:grid sm:grid-cols-3 sm:overflow-visible sm:px-0">
            {reviews.map((r, i) => (
              <motion.li
                key={r.id}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ type: "spring", stiffness: 200, damping: 26, delay: i * 0.05 }}
                className={`flex shrink-0 snap-start flex-col rounded-[22px] border border-line-strong bg-white/40 p-5 sm:w-auto lg:p-4 ${reviews.length === 1 ? "w-full" : "w-[84%]"}`}
              >
                <QuoteIcon size={18} strokeWidth={1.5} className="text-caramel" aria-hidden />
                <blockquote className="mt-3 flex-1 whitespace-pre-line text-[15px] leading-relaxed sm:text-[14px] sm:leading-[1.55]">{r.text}</blockquote>
                {(r.name || r.detail) && (
                  <p className="mt-4 border-t border-line pt-3 text-[13px]">
                    {r.name && <span className="font-medium">{r.name}</span>}
                    {r.detail && (
                      <span className="text-muted">
                        {r.name ? " · " : ""}
                        {r.detail}
                      </span>
                    )}
                  </p>
                )}
              </motion.li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
