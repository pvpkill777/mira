"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Check, Minus, Plus, Users } from "lucide-react";
import type { Catalog, SizeDTO } from "@/lib/types";
import { formatPrice, formatWeight, guestsForWeight } from "@/lib/format";
import { clampWeight } from "@/lib/pricing";
import { CakeGlyph } from "./CakeGlyph";
import { SectionTitle } from "./SectionTitle";

const spring = { type: "spring", stiffness: 500, damping: 38 } as const;

export function SizeStep({
  catalog,
  sizeId,
  weight,
  onSize,
  onWeight,
}: {
  catalog: Catalog;
  sizeId: string | null;
  weight: number;
  onSize: (s: SizeDTO) => void;
  /** Принимает новый вес или функцию от текущего — чтобы быстрые нажатия «+» не терялись. */
  onWeight: (g: number | ((prev: number) => number)) => void;
}) {
  const minKgPrice = catalog.fillings.length ? Math.min(...catalog.fillings.map((f) => f.pricePerKg)) : null;
  const n = catalog.sizes.length;
  // Колонки под число размеров (1–8): без «дырки» в последнем ряду на десктопе.
  const lgCols = n <= 2 ? "lg:grid-cols-2" :n === 3 || n === 5 || n === 6 ? "lg:grid-cols-3" : "lg:grid-cols-4";
  const selected = catalog.sizes.find((s) => s.id === sizeId);
  const { customMinGrams: min, customMaxGrams: max } = catalog.settings;
  const adjustable = selected && selected.adjustable && selected.fixedPrice == null;
  // Вес «по весу»-размера всегда в границах «Вес торта» из кабинета — так же считает цену сервер.
  const presetWeight = (s: SizeDTO) => (s.fixedPrice == null && s.adjustable ? clampWeight(s.weightGrams, catalog) : s.weightGrams);
  const isCustom = adjustable && weight !== presetWeight(selected);
  const pct = max > min ? ((weight - min) / (max - min)) * 100 : 100;

  return (
    <section aria-labelledby="size-title" className="scroll-mt-20" id="builder">
      <SectionTitle index="01 — Размер" title="Сколько будет гостей?" hint="Считаем ~180–230 г на человека" id="size-title" />

      <div className={`grid grid-cols-2 gap-3 ${lgCols}`}>
        {catalog.sizes.map((s) => {
          const active = s.id === sizeId;
          const grams = presetWeight(s);
          const price = s.fixedPrice ?? (minKgPrice == null ? null : Math.round(((grams / 1000) * minKgPrice) / 10) * 10);
          return (
            <button
              key={s.id}
              type="button"
              onClick={() => onSize(s)}
              aria-pressed={active}
              className={`group relative flex flex-col items-start overflow-hidden rounded-[22px] border p-3.5 text-left transition-colors duration-300 min-[360px]:p-4 ${
                active ? "border-choc" : "border-line-strong hover:border-choc/50"
              }`}
            >
              {active && (
                <motion.span layoutId="size-bg" transition={spring} className="absolute inset-0 -z-0 bg-white/70" aria-hidden />
              )}
              <span className="relative z-[1] flex w-full items-start justify-between">
                <CakeGlyph grams={grams} active={active} />
                <span
                  className={`flex h-6 w-6 items-center justify-center rounded-full border transition-colors ${
                    active ? "border-choc bg-choc text-cream" : "border-line-strong"
                  }`}
                >
                  {active && <Check size={14} strokeWidth={2} />}
                </span>
              </span>
              <span className="relative z-[1] mt-3 display w-full text-[length:clamp(19px,calc(7.5vw_-_5px),24px)] leading-[1.05] hyphens-auto [overflow-wrap:anywhere]">{s.name}</span>
              <span className="relative z-[1] num mt-2 text-[13px] font-semibold">{formatWeight(grams)}</span>
              {s.guestsLabel && (
                <span className="relative z-[1] mt-1 flex w-full items-start gap-1.5 text-[12px] leading-snug text-muted [overflow-wrap:anywhere]">
                  <Users size={13} strokeWidth={1.5} className="mt-[2px] shrink-0" /> <span className="min-w-0">{s.guestsLabel}</span>
                </span>
              )}
              {/* mt-auto: цена прижата к низу карточки, даже если у соседей название в две строки */}
              <span className="relative z-[1] mt-auto w-full pt-3">
                <span className="block border-t border-line pt-2.5 text-[12px] text-muted">
                  {s.fixedPrice != null ? (
                    <>
                      <span className="num font-semibold text-choc">{formatPrice(s.fixedPrice)}</span> · фикс.
                    </>
                  ) : price != null ? (
                    <>
                      от <span className="num font-semibold text-choc">{formatPrice(price)}</span>
                    </>
                  ) : (
                    "цена по весу"
                  )}
                </span>
              </span>
            </button>
          );
        })}
      </div>

      <AnimatePresence initial={false}>
        {adjustable && (
          <motion.div
            key="weight"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 34 }}
            className="overflow-hidden"
          >
            <div className="mt-4 rounded-[22px] border border-line-strong bg-white/40 p-4 sm:p-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-[13px] text-muted">{isCustom ? "Свой вес" : "Точный вес"}</p>
                  <p className="text-[12px] text-muted">{selected && weight === selected.weightGrams && selected.guestsLabel ? selected.guestsLabel : guestsForWeight(weight)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <StepButton label="Уменьшить вес на 100 г" disabled={weight <= min} onClick={() => onWeight((w) => w - 100)}>
                    <Minus size={18} strokeWidth={1.5} />
                  </StepButton>
                  <span className="display num w-[92px] text-center text-[30px] leading-none">{formatWeight(weight)}</span>
                  <StepButton label="Увеличить вес на 100 г" disabled={weight >= max} onClick={() => onWeight((w) => w + 100)}>
                    <Plus size={18} strokeWidth={1.5} />
                  </StepButton>
                </div>
              </div>
              <input
                type="range"
                className="range mt-4"
                min={min}
                max={max}
                step={100}
                value={weight}
                onChange={(e) => onWeight(Number(e.target.value))}
                style={{ ["--p" as string]: `${pct}%` }}
                aria-label="Вес торта"
                aria-valuetext={formatWeight(weight)}
              />
              <div className="num mt-1 flex justify-between text-[11px] text-muted">
                <span>{formatWeight(min)}</span>
                <span>{formatWeight(max)}</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

function StepButton({ children, onClick, disabled, label }: { children: React.ReactNode; onClick: () => void; disabled?: boolean; label: string }) {
  return (
    <motion.button
      type="button"
      whileTap={{ scale: 0.9 }}
      onClick={onClick}
      disabled={disabled}
      aria-label={label}
      className="flex h-11 w-11 items-center justify-center rounded-full border border-line-strong transition-colors hover:border-choc disabled:opacity-30"
    >
      {children}
    </motion.button>
  );
}
