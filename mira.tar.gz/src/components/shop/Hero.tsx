"use client";

import { motion } from "framer-motion";
import { ArrowDown, AtSign, MessageCircle, Send } from "lucide-react";
import type { PublicSettings } from "@/lib/types";
import { Monogram } from "@/components/ui/Monogram";
import { humanDate } from "@/lib/dates";
import { formatPrice } from "@/lib/format";
import { responsiveImage } from "@/lib/images";
import { fillTemplate, splitAccent, typograph } from "@/lib/content";

const ease = [0.22, 1, 0.36, 1] as const;

export function Hero({
  settings,
  nearestDate,
  fillingsCount,
  minPrice,
  demo = false,
}: {
  /** Демо для другого кондитера: логотип ведёт не на основной сайт, в монограмме — её буква */
  demo?: boolean;
  settings: PublicSettings;
  nearestDate: string | null;
  fillingsCount: number;
  minPrice: number;
}) {
  const tg = `https://t.me/${settings.telegram}`;
  const wa = `https://wa.me/${settings.whatsapp}`;
  const ig = `https://instagram.com/${settings.instagram}`;
  const titleParts = splitAccent(typograph(fillTemplate(settings.heroTitle.trim(), settings)));
  const subtitle = typograph(fillTemplate(settings.heroSubtitle.trim(), settings));
  const norm = (t: string) => t.replace(/[*\s ]+/g, " ").trim().toLowerCase();
  const captionText = norm(settings.tagline) && norm(settings.tagline) !== norm(fillTemplate(settings.heroTitle, settings)) ? settings.tagline : "";

  return (
    <header className="mx-auto w-full max-w-6xl px-4 pt-4 sm:px-6 lg:px-10">
      {/* Верхняя строка: логотип и быстрые ссылки */}
      <div className="flex items-center justify-between py-2">
        <a href={demo ? "#main" : "/"} className="flex items-center gap-3" aria-label={`${settings.brandName} — на главную`}>
          {settings.avatarUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={settings.avatarUrl} alt="" width={40} height={40} className="h-10 w-10 rounded-full object-cover" />
          ) : (
            <Monogram size={40} letter={demo ? settings.brandName.trim().charAt(0).toUpperCase() || undefined : undefined} />
          )}
          <span className="leading-tight">
            <span className="display block text-[22px]">{settings.brandName}</span>
            <span className="block text-[11px] tracking-wide text-muted">кондитер {settings.ownerName}</span>
          </span>
        </a>
        <nav className="flex items-center gap-1" aria-label="Связаться">
          {settings.telegram && (
            <SocialIcon href={tg} label="Telegram">
              <Send size={18} strokeWidth={1.5} />
            </SocialIcon>
          )}
          {settings.whatsapp && (
            <SocialIcon href={wa} label="WhatsApp">
              <MessageCircle size={18} strokeWidth={1.5} />
            </SocialIcon>
          )}
          {settings.instagram && (
            <SocialIcon href={ig} label="Instagram">
              <AtSign size={18} strokeWidth={1.5} />
            </SocialIcon>
          )}
        </nav>
      </div>

      <div className="grid items-end gap-7 pb-10 pt-3 md:grid-cols-[1.15fr_0.85fr] md:gap-12 md:pb-16 md:pt-12">
        {/* На телефоне фото идёт первым: первый экран кондитерской должен показывать торт, а не только текст */}
        {/* Без opacity: 0 на старте — иначе LCP-фото не считается отрисованным до гидратации JS. */}
        <motion.figure
          initial={{ scale: 0.98 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1, ease }}
          className="relative order-first mx-auto w-full md:order-last md:max-w-[420px]"
        >
          <div className="relative overflow-hidden rounded-[24px] border border-line bg-whip md:rounded-t-[999px] md:rounded-b-[28px]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              {...responsiveImage(settings.heroImageUrl, [480, 720, 960, 1280])}
              sizes="(min-width: 768px) 420px, calc(100vw - 32px)"
              width={1200}
              height={825}
              alt={`Авторский торт — работа кондитера ${settings.ownerName}`}
              className="aspect-[16/11] w-full object-cover md:aspect-[4/5]"
              fetchPriority="high"
              decoding="async"
            />
            <div className="absolute bottom-3 left-3 right-3 md:hidden">
              <OpenDates nearestDate={nearestDate} />
            </div>
          </div>
          <figcaption className="mt-3 hidden items-baseline justify-between gap-4 text-[12px] text-muted md:flex">
            {/* Подпись к фото — «Короткое УТП» из настроек кабинета; если оно повторяет заголовок, не дублируем. */}
            <span className="display min-w-0 text-[17px] italic text-choc [overflow-wrap:anywhere]">{captionText}</span>
            <span className="num">{settings.city}</span>
          </figcaption>
        </motion.figure>

        <div>
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease }}
            className="hidden md:block"
          >
            <OpenDates nearestDate={nearestDate} />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease, delay: 0.05 }}
            className="display text-[42px] leading-[1.02] [overflow-wrap:anywhere] sm:text-[58px] md:mt-6 lg:text-[74px]"
          >
            {titleParts.length
              ? titleParts.map((p, i) =>
                  p.accent ? (
                    <em key={i} className="font-normal italic text-caramel">
                      {p.text}
                    </em>
                  ) : (
                    <span key={i}>{p.text}</span>
                  ),
                )
              : settings.brandName}
          </motion.h1>

          {subtitle && (
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease, delay: 0.15 }}
              className="mt-4 max-w-md whitespace-pre-line text-[15px] leading-relaxed text-muted sm:mt-5 sm:text-base"
            >
              {subtitle}
            </motion.p>
          )}

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease, delay: 0.25 }}
            className="mt-7 grid grid-cols-2 gap-3 sm:flex sm:flex-wrap sm:items-center"
          >
            <a href="#builder" className="btn-primary col-span-2">
              Собрать торт
              <ArrowDown size={16} strokeWidth={1.5} />
            </a>
            {settings.telegram && (
              <a href={tg} target="_blank" rel="noreferrer" className="btn-ghost">
                <Send size={16} strokeWidth={1.5} /> Telegram
              </a>
            )}
            {settings.whatsapp && (
              <a href={wa} target="_blank" rel="noreferrer" className="btn-ghost">
                <MessageCircle size={16} strokeWidth={1.5} /> WhatsApp
              </a>
            )}
          </motion.div>

          <dl className="mt-10 grid max-w-md grid-cols-3 border-y border-line text-left">
            <Fact term="начинок" value={String(fillingsCount)} />
            <Fact term="торт от" value={formatPrice(minPrice)} />
            <Fact term="предоплата" value={`${settings.prepaymentPct}%`} last />
          </dl>
        </div>
      </div>
    </header>
  );
}

/** Статус записи: спокойная точка без «пульса» — бутику не нужен индикатор как у SaaS-дашборда. */
function OpenDates({ nearestDate }: { nearestDate: string | null }) {
  return (
    <p className="inline-flex max-w-full items-center gap-2.5 rounded-full border border-line-strong bg-cream py-1.5 pl-3 pr-4 text-[13px]">
      <span className={`h-2 w-2 shrink-0 rounded-full ${nearestDate ? "bg-sage" : "bg-caramel"}`} aria-hidden />
      {nearestDate ? (
        <span className="truncate">
          Ближайшая свободная дата —&nbsp;<span className="num font-semibold">{humanDate(nearestDate, false)}</span>
        </span>
      ) : (
        <span className="truncate">Онлайн-запись закрыта — напишите, подберём дату</span>
      )}
    </p>
  );
}

function SocialIcon({ href, label, children }: { href: string; label: string; children: React.ReactNode }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      aria-label={label}
      title={label}
      className="inline-flex h-11 w-11 items-center justify-center rounded-full text-choc transition-colors hover:bg-whip"
    >
      {children}
    </a>
  );
}

function Fact({ term, value, unit, last }: { term: string; value: string; unit?: string; last?: boolean }) {
  return (
    <div className={`py-4 pr-3 ${last ? "" : "border-r border-line"} [&:not(:first-child)]:pl-4`}>
      <dt className="sr-only">{term}</dt>
      <dd className="display num text-[30px] leading-none">
        {value}
        {unit && <span className="ml-0.5 text-[18px]">{unit}</span>}
      </dd>
      <dd className="mt-1.5 text-[12px] text-muted">{term}</dd>
    </div>
  );
}
