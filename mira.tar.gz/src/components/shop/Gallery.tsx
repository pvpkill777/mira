"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useFocusTrap } from "@/lib/useFocusTrap";
import { responsiveImage } from "@/lib/images";
import type { Catalog, GalleryCategory, GalleryDTO } from "@/lib/types";
import { calculateQuote } from "@/lib/pricing";
import { formatPrice, formatWeight } from "@/lib/format";
import { typograph } from "@/lib/content";
import { SectionTitle } from "./SectionTitle";

export function Gallery({ catalog, onRepeat }: { catalog: Catalog; onRepeat: (g: GalleryDTO) => void }) {
  const [filter, setFilter] = useState<GalleryCategory | "all">("all");
  const [open, setOpen] = useState<GalleryDTO | null>(null);
  // Фильтры — только включённые категории, в которых есть работы. Работы из выключенной
  // или удалённой категории видны во «Все».
  const categories = useMemo(
    () => catalog.galleryCategories.filter((c) => catalog.gallery.some((g) => g.category === c.slug)),
    [catalog.galleryCategories, catalog.gallery],
  );
  // Выбранную категорию могли выключить, пока страница открыта, — тогда показываем всё.
  const activeFilter = filter !== "all" && categories.some((c) => c.slug === filter) ? filter : "all";
  const items = useMemo(
    () => (activeFilter === "all" ? catalog.gallery : catalog.gallery.filter((g) => g.category === activeFilter)),
    [catalog.gallery, activeFilter],
  );
  const filters = [{ id: "all", label: "Все" }, ...categories.map((c) => ({ id: c.slug, label: c.label }))];
  // Ориентир цены на карточке: клиент видит порядок сумм, не открывая каждую работу.
  const prices = useMemo(() => {
    const out: Record<string, number> = {};
    for (const g of catalog.gallery) {
      const q = calculateQuote(
        { sizeId: g.sizeId, weightGrams: g.weightGrams, fillingId: g.fillingId, decorIds: g.decorIds, urgent: false, delivery: false },
        catalog,
      );
      if (q.complete) out[g.id] = q.total;
    }
    return out;
  }, [catalog]);

  return (
    <section aria-labelledby="gallery-title" className="scroll-mt-20" id="gallery">
      <SectionTitle index="Работы" title="Хочу так же" hint="Нажмите на фото — соберём такой же" id="gallery-title" />

      <div className={`no-scrollbar -mx-4 mb-5 gap-1 overflow-x-auto px-4 sm:mx-0 sm:px-0 ${categories.length > 0 ? "flex" : "hidden"}`} role="group" aria-label="Категории работ">
        {filters.map((f) => {
          const active = activeFilter === f.id;
          return (
            <button
              key={f.id}
              type="button"
              aria-pressed={active}
              onClick={() => setFilter(f.id)}
              className={`relative shrink-0 rounded-full px-4 py-2.5 text-[14px] transition-colors ${active ? "text-cream" : "text-choc hover:bg-whip"}`}
            >
              {active && (
                <motion.span layoutId="gallery-filter" className="absolute inset-0 rounded-full bg-choc" transition={{ type: "spring", stiffness: 500, damping: 38 }} />
              )}
              <span className="relative">{f.label}</span>
            </button>
          );
        })}
      </div>

      <motion.ul layout className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <AnimatePresence mode="popLayout" initial={false}>
          {items.map((g) => (
            <motion.li
              key={g.id}
              layout
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
            >
              <button type="button" onClick={() => setOpen(g)} className="group block w-full text-left">
                <span className="block overflow-hidden rounded-[18px] bg-whip">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    {...responsiveImage(g.imageUrl, [320, 480, 640])}
                    sizes="(min-width: 1024px) 230px, (min-width: 640px) 31vw, 47vw"
                    width={480}
                    height={600}
                    alt={g.title}
                    loading="lazy"
                    decoding="async"
                    className="aspect-[4/5] w-full object-cover transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.04]"
                  />
                </span>
                {/* Название переносится на две строки вместо обрезки «Бенто с голубик…», под ним — вес и ориентир цены */}
                <span className="display mt-2.5 line-clamp-2 block text-[19px] leading-[1.1]">{typograph(g.title)}</span>
                <span className="num mt-1 block text-[12px] text-muted">
                  {formatWeight(g.weightGrams)}
                  {prices[g.id] ? ` · ≈ ${formatPrice(prices[g.id])}` : ""}
                </span>
              </button>
            </motion.li>
          ))}
        </AnimatePresence>
      </motion.ul>

      <GalleryModal item={open} catalog={catalog} onClose={() => setOpen(null)} onRepeat={(g) => { setOpen(null); onRepeat(g); }} />
    </section>
  );
}

function GalleryModal({
  item,
  catalog,
  onClose,
  onRepeat,
}: {
  item: GalleryDTO | null;
  catalog: Catalog;
  onClose: () => void;
  onRepeat: (g: GalleryDTO) => void;
}) {
  const dialogRef = useRef<HTMLDivElement>(null);
  useFocusTrap(dialogRef, Boolean(item));
  useEffect(() => {
    if (!item) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [item, onClose]);

  const filling = item ? catalog.fillings.find((f) => f.id === item.fillingId) : null;
  const decor = item ? catalog.decor.filter((d) => item.decorIds.includes(d.id)) : [];
  const categoryLabel = item ? catalog.galleryCategories.find((c) => c.slug === item.category)?.label : undefined;
  const quote = item
    ? calculateQuote(
        { sizeId: item.sizeId, weightGrams: item.weightGrams, fillingId: item.fillingId, decorIds: item.decorIds, urgent: false, delivery: false },
        catalog,
      )
    : null;

  return (
    <AnimatePresence>
      {item && (
        <motion.div className="fixed inset-0 z-[70] flex items-end justify-center md:items-center md:p-6" initial={{ opacity: 1 }} exit={{ opacity: 1 }}>
          <motion.div
            className="absolute inset-0 bg-choc/40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.div
            ref={dialogRef}
            tabIndex={-1}
            role="dialog"
            aria-modal="true"
            aria-label={item.title}
            initial={{ y: "100%", opacity: 0.6 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: "100%", opacity: 0.6 }}
            transition={{ type: "spring", stiffness: 340, damping: 36 }}
            className="relative max-h-[92dvh] w-full overflow-y-auto rounded-t-[28px] bg-cream md:grid md:max-w-4xl md:grid-cols-2 md:rounded-[28px]"
          >
            <button
              type="button"
              onClick={onClose}
              aria-label="Закрыть"
              className="absolute right-3 top-3 z-10 flex h-11 w-11 items-center justify-center rounded-full bg-cream/90 text-choc"
            >
              <X size={20} strokeWidth={1.5} />
            </button>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              {...responsiveImage(item.imageUrl, [480, 720, 960])}
              sizes="(min-width: 768px) 450px, 100vw"
              width={720}
              height={900}
              alt={item.title}
              decoding="async"
              className="aspect-[4/5] max-h-[44dvh] w-full object-cover md:max-h-none md:h-full" />
            <div className="flex flex-col p-5 pb-[calc(20px+var(--sab))] md:p-8">
              {categoryLabel && <p className="eyebrow">{categoryLabel}</p>}
              <h3 className={`display text-[34px] leading-[1.05] break-words ${categoryLabel ? "mt-2" : ""}`}>{typograph(item.title)}</h3>
              {item.description && <p className="mt-2 text-[14px] leading-relaxed text-muted">{typograph(item.description)}</p>}
              <dl className="mt-5 divide-y divide-line border-y border-line text-[14px]">
                <Row term="Вес на фото" value={formatWeight(item.weightGrams)} />
                <Row term="Начинка" value={filling?.name ?? "на ваш выбор"} />
                <Row term="Декор" value={decor.length ? decor.map((d) => d.name).join(", ") : "без доп. декора"} />
                {quote && quote.complete && <Row term="Ориентировочно" value={formatPrice(quote.total)} strong />}
              </dl>
              <div className="sticky bottom-0 -mx-5 mt-auto bg-cream px-5 pb-1 pt-5 md:static md:mx-0 md:px-0">
                <button type="button" onClick={() => onRepeat(item)} className="btn-primary w-full">
                  Собрать такой же в конструкторе
                  <ArrowRight size={16} strokeWidth={1.5} />
                </button>
                <p className="mt-2.5 text-center text-[12px] text-muted">Параметры подставятся автоматически — останется выбрать дату</p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function Row({ term, value, strong }: { term: string; value: string; strong?: boolean }) {
  return (
    <div className="flex justify-between gap-4 py-3">
      <dt className="text-muted">{term}</dt>
      <dd className={`num text-right ${strong ? "font-semibold" : ""}`}>{value}</dd>
    </div>
  );
}
