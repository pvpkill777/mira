"use client";

import { motion } from "framer-motion";
import { Images } from "lucide-react";
import { useEffect, useState } from "react";

// Номера совпадают с надзаголовками разделов (01 — Размер … 05 — Контакты); «Работы» — вдохновение, а не шаг, поэтому без номера.
const STEPS: { id: string; label: string; n: number | null }[] = [
  { id: "builder", label: "Размер", n: 1 },
  { id: "filling", label: "Начинка", n: 2 },
  { id: "decor", label: "Декор", n: 3 },
  { id: "gallery", label: "Работы", n: null },
  { id: "checkout", label: "Дата", n: 4 },
  { id: "order-form", label: "Контакты", n: 5 },
];

/** Тонкая липкая навигация по шагам со scroll-spy. */
export function StepNav({ done }: { done: Record<string, boolean> }) {
  const [active, setActive] = useState("builder");

  // Активный шаг — последний раздел, чей верх уже прошёл линию на 35% высоты экрана.
  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      const line = window.innerHeight * 0.35;
      let current = STEPS[0].id;
      for (const s of STEPS) {
        const el = document.getElementById(s.id);
        if (el && el.getBoundingClientRect().top <= line) current = s.id;
      }
      setActive(current);
    };
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  // Держим активный пункт в видимой части горизонтальной ленты на телефоне.
  useEffect(() => {
    const item = document.querySelector<HTMLElement>(`[data-step="${active}"]`);
    const list = item?.closest("ol");
    if (item && list) list.scrollTo({ left: item.offsetLeft - list.clientWidth / 2 + item.clientWidth / 2, behavior: "smooth" });
  }, [active]);

  return (
    <nav className="sticky top-0 z-30 border-b border-line bg-cream" aria-label="Шаги заказа">
      <ol className="no-scrollbar mx-auto flex max-w-6xl gap-1 overflow-x-auto px-3 py-2 sm:px-5 lg:px-9">
        {STEPS.map((s) => {
          const isActive = active === s.id;
          return (
            <li key={s.id} className="shrink-0">
              <a
                href={`#${s.id}`}
                data-step={s.id}
                aria-current={isActive ? "step" : undefined}
                className={`relative flex items-center gap-2 rounded-full px-3 py-2 text-[13px] transition-colors ${
                  isActive ? "text-choc" : "text-muted hover:text-choc"
                }`}
              >
                {isActive && (
                  <motion.span layoutId="step-pill" className="absolute inset-0 rounded-full bg-whip" transition={{ type: "spring", stiffness: 500, damping: 40 }} />
                )}
                <span
                  className={`num relative flex h-5 w-5 items-center justify-center rounded-full border text-[10px] ${
                    done[s.id] ? "border-caramel-deep bg-caramel-deep text-cream" : isActive ? "border-choc" : "border-line-strong"
                  }`}
                >
                  {s.n ?? <Images size={11} strokeWidth={1.5} aria-hidden />}
                </span>
                <span className="relative">{s.label}</span>
              </a>
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
