"use client";

import { motion } from "framer-motion";
import { Check, Copy, MessageCircle, Send } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useFocusTrap } from "@/lib/useFocusTrap";
import { formatPrice } from "@/lib/format";
import type { PublicSettings } from "@/lib/types";

export type ConfirmedOrder = {
  number: number;
  total: number;
  prepayment: number;
  details: string;
};

export function Confirmation({ order, settings, onClose }: { order: ConfirmedOrder; settings: PublicSettings; onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  const dialogRef = useRef<HTMLDivElement>(null);
  useFocusTrap(dialogRef, true);

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(order.details);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = order.details;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  // Без «Оставил(а)»: нейтральная формулировка звучит по-человечески и не требует угадывать род.
  const message = `Здравствуйте! Пишу по заявке №${order.number} с сайта.\n\n${order.details}`;
  const tg = `https://t.me/${settings.telegram}?text=${encodeURIComponent(message)}`;
  const wa = `https://wa.me/${settings.whatsapp}?text=${encodeURIComponent(message)}`;

  return (
    <motion.div
      className="fixed inset-0 z-[80] overflow-y-auto bg-cream"
      ref={dialogRef}
      tabIndex={-1}
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-title"
      initial={{ y: "100%" }}
      animate={{ y: 0 }}
      exit={{ y: "100%" }}
      transition={{ type: "spring", stiffness: 260, damping: 34 }}
    >
      <div className="mx-auto flex min-h-full max-w-lg flex-col px-5 pb-[calc(28px+var(--sab))] pt-14 lg:pt-20">
        {/* Мягкая пружина без «резинового» перелёта: это подтверждение, а не салют */}
        <motion.span
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 260, damping: 22, delay: 0.25 }}
          className="flex h-16 w-16 items-center justify-center rounded-full bg-choc text-cream"
        >
          <Check size={30} strokeWidth={1.5} />
        </motion.span>
        <p className="eyebrow mt-8">Заявка принята</p>
        <h2 id="confirm-title" className="display mt-2 text-[48px] sm:text-[56px]">
          Заказ <span className="num">№{order.number}</span>
        </h2>
        <p className="mt-3 text-[15px] leading-relaxed text-muted">
          {settings.ownerName.split(" ")[0]} свяжется с&nbsp;вами в&nbsp;течение часа, уточнит детали и&nbsp;пришлёт реквизиты.
          {settings.prepaymentPct ? " Дата закрепится за вами после предоплаты." : " После этого дата закрепится за вами."}
        </p>

        <div className="mt-8 rounded-[24px] border border-line-strong bg-white/50 p-5">
          <div className="flex items-baseline justify-between gap-4">
            <span className="text-[14px] text-muted">Сумма заказа</span>
            <span className="display num text-[28px] leading-none">{formatPrice(order.total)}</span>
          </div>
          {settings.prepaymentPct > 0 && (
            <div className="mt-3 flex items-baseline justify-between gap-4 border-t border-line pt-3">
              <span className="text-[14px] text-muted">
                Предоплата <span className="num">{settings.prepaymentPct}%</span>
              </span>
              <span className="display num text-[34px] leading-none text-caramel-deep">{formatPrice(order.prepayment)}</span>
            </div>
          )}
          {/* [overflow-wrap:anywhere] — длинные ссылки на фото дизайна иначе вылезают за карточку на 320px */}
          <pre className="num mt-4 whitespace-pre-wrap [overflow-wrap:anywhere] border-t border-dashed border-line-strong pt-4 font-sans text-[13px] leading-relaxed text-muted">
            {order.details}
          </pre>
        </div>

        {/* Главное действие — написать кондитеру; подпись над кнопками объясняет их, копирование — запасной путь ниже */}
        <div className="mt-8">
          <p className="mb-3 text-[13px] text-muted">Написать кондитеру — детали заказа уже будут в&nbsp;сообщении</p>
          <div className={`grid gap-3 ${settings.telegram && settings.whatsapp ? "grid-cols-2" : "grid-cols-1"}`}>
            {settings.telegram && (
              <a href={tg} target="_blank" rel="noreferrer" className="btn-primary">
                <Send size={16} strokeWidth={1.5} /> Telegram
              </a>
            )}
            {settings.whatsapp && (
              <a href={wa} target="_blank" rel="noreferrer" className="btn-primary">
                <MessageCircle size={16} strokeWidth={1.5} /> WhatsApp
              </a>
            )}
          </div>
          <button type="button" onClick={copy} className="btn-ghost mt-3 w-full py-[14px]" aria-live="polite">
            {copied ? <Check size={17} strokeWidth={1.5} /> : <Copy size={17} strokeWidth={1.5} />}
            {copied ? "Скопировано" : "Скопировать детали заказа"}
          </button>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mx-auto mt-auto inline-flex min-h-11 items-end pt-10 text-[14px] underline decoration-line-strong underline-offset-4 transition-colors hover:decoration-choc"
        >
          Собрать ещё один торт
        </button>
      </div>
    </motion.div>
  );
}
