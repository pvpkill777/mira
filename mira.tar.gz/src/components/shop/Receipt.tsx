"use client";

import { AnimatePresence, motion } from "framer-motion";
import type { Quote } from "@/lib/pricing";
import { formatPrice, formatWeight } from "@/lib/format";
import { AnimatedPrice } from "@/components/ui/AnimatedPrice";
import { humanDate } from "@/lib/dates";

export function Receipt({
  quote,
  prepaymentPct,
  date,
  slot,
  delivery,
  compact,
}: {
  quote: Quote;
  prepaymentPct: number;
  date: string | null;
  slot: string | null;
  delivery: boolean;
  compact?: boolean;
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <p className="eyebrow">Ваш торт</p>
        <p className="num text-[12px] text-muted">{quote.weightGrams ? formatWeight(quote.weightGrams) : "—"}</p>
      </div>
      <ul className={`mt-3 space-y-2.5 ${compact ? "" : "min-h-[96px]"}`}>
        <AnimatePresence initial={false}>
          {quote.lines.map((l) => {
            const free = l.amount === 0 && quote.decor.some((d) => d.name === l.label);
            return (
            <motion.li
              key={l.label}
              layout
              initial={{ opacity: 0, x: -6 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 6 }}
              transition={{ type: "spring", stiffness: 400, damping: 32 }}
              className="flex items-start justify-between gap-3 text-[14px]"
            >
              <span className="min-w-0">
                <span className="block leading-snug">{l.label}</span>
                {l.detail && <span className="num block text-[12px] text-muted">{l.detail}</span>}
              </span>
              {/* В шаге декора такая позиция подписана «бесплатно» — в чеке то же слово, а не «0 ₽» */}
              <span className={`num shrink-0 ${free ? "text-muted" : ""}`}>{free ? "бесплатно" : l.amount === 0 ? "0 ₽" : formatPrice(l.amount)}</span>
            </motion.li>
            );
          })}
        </AnimatePresence>
        {!quote.filling && <li className="text-[13px] text-muted">Выберите начинку, чтобы увидеть точную цену</li>}
        {/* Десктопный чек: вместо пустого места под единственной строкой — тихая подсказка, что декор добавится сюда */}
        {!compact && quote.filling && quote.decor.length === 0 && (
          <li className="flex justify-between gap-3 text-[13px] text-muted">
            <span>Декор — по желанию</span>
            <span aria-hidden>—</span>
          </li>
        )}
      </ul>

      <div className="mt-4 space-y-1 border-t border-dashed border-line-strong pt-3 text-[13px] text-muted">
        <p className="flex justify-between gap-3">
          <span>Дата</span>
          <span className="num text-right text-choc">{date ? `${humanDate(date, false)}${slot ? `, ${slot}` : ""}` : "не выбрана"}</span>
        </p>
        <p className="flex justify-between gap-3">
          <span>Получение</span>
          <span className="text-choc">{delivery ? "доставка" : "самовывоз"}</span>
        </p>
      </div>

      <div className="mt-4 flex items-end justify-between border-t border-line-strong pt-4">
        <span className="text-[13px] text-muted">Итого</span>
        <AnimatedPrice value={quote.total} className="display text-[38px] leading-none" />
      </div>
      <p className="mt-1 text-right text-[12px] text-muted">
        предоплата {prepaymentPct}% — <span className="num text-choc">{formatPrice(quote.prepayment)}</span>
      </p>
    </div>
  );
}
