"use client";

import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import { ArrowRight, Loader2 } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MAX_DESIGN_PHOTOS, type Availability, type Catalog, type GalleryDTO, type SizeDTO } from "@/lib/types";
import { calculateQuote, clampWeight } from "@/lib/pricing";
import { formatPrice, formatWeight, phoneDigits } from "@/lib/format";
import { hoursLabel, humanDate, isSlotAvailable, isUrgentSlot } from "@/lib/dates";
import { Hero } from "./Hero";
import { StepNav } from "./StepNav";
import { SizeStep } from "./SizeStep";
import { FillingStep } from "./FillingStep";
import { DecorStep } from "./DecorStep";
import { Gallery } from "./Gallery";
import { Checkout, type FieldErrors, type OrderForm } from "./Checkout";
import { Receipt } from "./Receipt";
import { StickyBar } from "./StickyBar";
import { Confirmation, type ConfirmedOrder } from "./Confirmation";
import { Footer } from "./Footer";
import { Trust } from "./Trust";
import { Faq } from "./Faq";
import { PriceAnnouncer } from "@/components/ui/AnimatedPrice";

const DRAFT_KEY = "mira-draft-v1";
const PHOTOS_BUSY_ERROR = "Фото ещё загружается — подождите пару секунд и отправьте заявку снова.";
const EMPTY_FORM: OrderForm ={ name: "", phone: "", contact: "", address: "", inscription: "", wishes: "" };

export function Shop({ catalog, initialAvailability, demo = false }: { catalog: Catalog; initialAvailability: Availability; demo?: boolean }) {
  const { settings } = catalog;
  const { minLeadHours, urgentHours } = settings;
  const defaultSize = catalog.sizes.find((s) => s.fixedPrice == null) ?? catalog.sizes[0] ?? null;

  const [availability, setAvailability] = useState(initialAvailability);
  const [sizeId, setSizeId] = useState<string | null>(defaultSize?.id ?? null);
  // Вес «по весу»-размера всегда прижат к границам «Вес торта» из кабинета (как считает сервер).
  const sizeWeight = (s: SizeDTO) => (s.fixedPrice == null && s.adjustable ? clampWeight(s.weightGrams, catalog) : s.weightGrams);
  const [weight, setWeight] = useState(defaultSize ? sizeWeight(defaultSize) : 1500);
  const [fillingId, setFillingId] = useState<string | null>(catalog.fillings[0]?.id ?? null);
  const [decorIds, setDecorIds] = useState<string[]>([]);
  const [urgent, setUrgent] = useState(false);
  const [urgentNote, setUrgentNote] = useState<string | null>(null);
  // Если кондитер оставила один способ получения — он выбран сразу и не меняется.
  const bothWays = settings.pickupEnabled && settings.deliveryEnabled;
  const [delivery, setDelivery] = useState(!settings.pickupEnabled && settings.deliveryEnabled);
  const [date, setDate] = useState<string | null>(null);
  const [slot, setSlot] = useState<string | null>(null);
  const [form, setForm] = useState<OrderForm>(EMPTY_FORM);
  const [touched, setTouched] = useState<Partial<Record<keyof OrderForm, boolean>>>({});
  const [showAllErrors, setShowAllErrors] = useState(false);
  const [galleryRefId, setGalleryRefId] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const [confirmed, setConfirmed] = useState<ConfirmedOrder | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [inCheckout, setInCheckout] = useState(false);
  const [photos, setPhotos] = useState<string[]>([]);
  const [formSeq, setFormSeq] = useState(0);
  const [photosBusy, setPhotosBusy] = useState(false);
  const restored = useRef(false);
  const [draftReady, setDraftReady] = useState(false);
  const submitLock = useRef(false);

  const quote = useMemo(
    () => calculateQuote({ sizeId, weightGrams: weight, fillingId, decorIds, urgent, delivery }, catalog),
    [sizeId, weight, fillingId, decorIds, urgent, delivery, catalog],
  );

  // ——— Черновик: восстанавливаем сборку и контакты, если клиент вернулся ———
  useEffect(() => {
    // Повторный запуск (StrictMode, Fast Refresh, новый catalog) не должен перечитывать черновик:
    // к этому моменту эффект сохранения уже мог записать в него начальные значения.
    if (restored.current) return;
    try {
      const raw = localStorage.getItem(DRAFT_KEY);
      if (raw) {
        const d = JSON.parse(raw);
        const size = catalog.sizes.find((s) => s.id === d.sizeId);
        if (size) {
          setSizeId(size.id);
          setWeight(size.fixedPrice != null ? size.weightGrams : clampWeight(d.weight ?? size.weightGrams, catalog));
        }
        if (catalog.fillings.some((f) => f.id === d.fillingId)) setFillingId(d.fillingId);
        if (Array.isArray(d.decorIds)) setDecorIds(d.decorIds.filter((id: string) => catalog.decor.some((x) => x.id === id)));
        if (typeof d.delivery === "boolean" && bothWays) setDelivery(d.delivery);
        // Берём из черновика только строки: повреждённый черновик не должен ронять страницу.
        if (d.form && typeof d.form === "object") {
          const restoredForm = { ...EMPTY_FORM };
          for (const k of Object.keys(EMPTY_FORM) as (keyof OrderForm)[]) {
            if (typeof d.form[k] === "string") restoredForm[k] = d.form[k];
          }
          setForm(restoredForm);
        }
        if (Array.isArray(d.photos)) {
          const saved: string[] = d.photos
            .filter((u: unknown): u is string => typeof u === "string" && /^\/api\/media\/[a-f0-9-]{36}\.(jpg|png|webp|avif)$/.test(u))
            .slice(0, MAX_DESIGN_PHOTOS);
          setPhotos(saved);
          // Старые фото могли удалить с сервера (уборка через сутки) — убираем их из черновика, а не теряем молча при отправке.
          Promise.all(saved.map((u) => fetch(u, { method: "HEAD" }).then((r) => (r.ok ? u : null)).catch(() => u))).then((ok) => {
            const alive = ok.filter((u): u is string => Boolean(u));
            if (alive.length !== saved.length) setPhotos((cur) => cur.filter((u) => alive.includes(u)));
          });
        }
      }
    } catch {
      /* приватный режим или повреждённые данные — начинаем с чистого листа */
    }
    restored.current = true;
    setDraftReady(true);
  }, [catalog, bothWays]);

  useEffect(() => {
    // В том же проходе, где черновик только прочитан, состояние ещё начальное — не затираем им черновик.
    if (!draftReady) return;
    try {
      localStorage.setItem(DRAFT_KEY, JSON.stringify({ sizeId, weight, fillingId, decorIds, delivery, form, photos }));
    } catch {
      /* хранилище недоступно — не критично */
    }
  }, [draftReady, sizeId, weight, fillingId, decorIds, delivery, form, photos]);

  // ——— Срочность синхронизируется с выбранным временем ———
  useEffect(() => {
    if (!date || !slot) return;
    const u = isUrgentSlot(date, slot, urgentHours);
    setUrgent((prev) => {
      if (prev !== u)
        setUrgentNote(
          u ? `Срочность включена автоматически: до выдачи меньше ${hoursLabel(urgentHours)}.` : `Срочность снята — до выдачи больше ${hoursLabel(urgentHours)}.`,
        );
      return u;
    });
  }, [date, slot, urgentHours]);

  const onUrgent = (v: boolean) => {
    // Кондитер выключила срочные заказы (0 часов) — включить срочность нельзя.
    if (v && urgentHours <= 0) {
      setUrgentNote("Срочные заказы сейчас не принимаются — выберите свободную дату в календаре.");
      return;
    }
    setUrgent(v);
    setUrgentNote(null);
    if (date && slot && isUrgentSlot(date, slot, urgentHours) !== v) {
      setSlot(null);
      setUrgentNote(v ? `Выберите время, до которого меньше ${hoursLabel(urgentHours)}.` : `Выберите время, до которого больше ${hoursLabel(urgentHours)}.`);
    } else if (v && !date) {
      setUrgentNote(`Выберите ближайшую дату в календаре ниже — до выдачи должно быть меньше ${hoursLabel(urgentHours)}.`);
    }
  };

  // ——— Наблюдаем, виден ли блок оформления (меняет кнопку в нижней панели) ———
  useEffect(() => {
    const el = document.getElementById("order-form");
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setInCheckout(e.isIntersecting), { rootMargin: "0px 0px -15% 0px" });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3200);
    return () => clearTimeout(t);
  }, [toast]);

  // Фото догрузилось — подсказка «Фото ещё загружается» больше не нужна.
  useEffect(() => {
    if (!photosBusy) setServerError((e) => (e === PHOTOS_BUSY_ERROR ? null : e));
  }, [photosBusy]);

  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });

  const onSize = (s: SizeDTO) => {
    setSizeId(s.id);
    setWeight(sizeWeight(s));
  };

  const onDate = (d: string) => {
    setDate(d);
    if (slot && !isSlotAvailable(d, slot, minLeadHours)) setSlot(null);
    // Ждём, пока блок с интервалами раскроется (анимация высоты), иначе прокрутка «не дотягивает»
    // и интервалы остаются под нижней панелью на телефоне.
    setTimeout(() => document.getElementById("slots")?.scrollIntoView({ behavior: "smooth", block: "nearest" }), 450);
  };

  const onRepeat = (g: GalleryDTO) => {
    const size = catalog.sizes.find((s) => s.id === g.sizeId) ?? catalog.sizes.find((s) => s.fixedPrice == null) ?? null;
    if (size) {
      setSizeId(size.id);
      setWeight(size.fixedPrice != null ? size.weightGrams : clampWeight(g.weightGrams, catalog));
    }
    if (g.fillingId && catalog.fillings.some((f) => f.id === g.fillingId)) setFillingId(g.fillingId);
    setDecorIds(g.decorIds.filter((id) => catalog.decor.some((d) => d.id === id)));
    setGalleryRefId(g.id);
    setToast(`«${g.title}» собран в конструкторе — выберите дату`);
    setTimeout(() => scrollTo("date"), 350);
  };

  // ——— Валидация: показываем ошибку поля после ухода с него или после попытки отправки ———
  const allErrors = useMemo<FieldErrors>(() => {
    const e: FieldErrors = {};
    if (!quote.size) e.size = "Выберите размер";
    if (!quote.filling) e.filling = "Выберите начинку";
    if (!date) e.date = "Выберите дату в календаре";
    else if (!slot) e.timeSlot = "Выберите удобное время";
    if (form.name.trim().length < 2) e.name = "Как к вам обращаться?";
    if (phoneDigits(form.phone).length !== 10) e.phone = "Нужен номер полностью — 10 цифр после +7";
    if (delivery && form.address.trim().length < 5) e.address = "Укажите адрес, куда привезти торт";
    return e;
  }, [quote.size, quote.filling, date, slot, form, delivery]);

  const visibleErrors: FieldErrors = {};
  for (const [k, v] of Object.entries(allErrors) as [keyof FieldErrors, string][]) {
    if (showAllErrors || touched[k as keyof OrderForm]) visibleErrors[k] = v;
  }

  const refreshAvailability = useCallback(async () => {
    try {
      const res = await fetch("/api/availability", { cache: "no-store" });
      if (res.ok) setAvailability(await res.json());
    } catch {
      /* офлайн — оставим как есть */
    }
  }, []);

  const buildDetails = (number: number, total: number, prepayment: number) => {
    const lines = [
      `Заказ №${number} · ${settings.brandName}`,
      `Торт: ${quote.size?.name}, ${formatWeight(quote.weightGrams)} — ${quote.filling?.name}`,
      quote.decor.length ? `Декор: ${quote.decor.map((d) => d.name).join(", ")}` : null,
      urgent ? `Срочный заказ (+${settings.urgentSurchargePct}%)` : null,
      `Дата: ${date ? humanDate(date) : ""}, ${slot}`,
      delivery ? `Доставка: ${form.address}` : `Самовывоз: ${settings.pickupAddress}`,
      form.inscription ? `Надпись: «${form.inscription}»` : null,
      form.wishes ? `Пожелания: ${form.wishes}` : null,
      photos.length ? `Фото дизайна: ${photos.map((u) => window.location.origin + u).join(" ")}` : null,
      `Итого: ${formatPrice(total)} · предоплата ${settings.prepaymentPct}%: ${formatPrice(prepayment)}`,
      `Контакт: ${form.name}, ${form.phone}${form.contact ? `, ${form.contact}` : ""}`,
    ];
    return lines.filter(Boolean).join("\n");
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Двойной тап по кнопке отправлял две заявки: вторая получала 409 и оставляла ошибку под экраном подтверждения.
    if (submitLock.current) return;
    setServerError(null);
    setShowAllErrors(true);
    const keys = Object.keys(allErrors);
    if (keys.length) {
      const first = keys[0];
      const target =
        first === "size" ? "builder" : first === "filling" ? "filling" : first === "date" ? "date" : first === "timeSlot" ? "slots" : `f-${first}`;
      const el = document.getElementById(target);
      el?.scrollIntoView({ behavior: "smooth", block: "center" });
      if (el instanceof HTMLInputElement) setTimeout(() => el.focus({ preventScroll: true }), 400);
      // Ошибка не в поле ввода (дата, время) — убираем клавиатуру, чтобы она не закрывала календарь.
      else if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
      return;
    }
    if (photosBusy) {
      setServerError(PHOTOS_BUSY_ERROR);
      setTimeout(() => document.getElementById("design-photos")?.scrollIntoView({ behavior: "smooth", block: "center" }), 50);
      return;
    }
    // Демо: заявка никуда не уходит — показываем, как это увидит клиент.
    if (demo) {
      setConfirmed({ number: 1001, total: quote.total, prepayment: quote.prepayment, details: buildDetails(1001, quote.total, quote.prepayment) });
      return;
    }
    submitLock.current = true;
    setSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sizeId, weightGrams: weight, fillingId, decorIds, urgent, delivery, date, timeSlot: slot, galleryRefId, designPhotos: photos, ...form }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setServerError(data.error ?? "Не получилось отправить заявку. Попробуйте ещё раз или напишите нам в Telegram.");
        if (data.refresh) {
          setSlot(null);
          if (!data.keepDate) setDate(null);
          refreshAvailability();
          setTimeout(() => document.getElementById(data.keepDate ? "slots" : "date")?.scrollIntoView({ behavior: "smooth", block: "center" }), 200);
        } else {
          // Сообщение внизу формы на телефоне легко не заметить под нижней панелью — показываем его.
          setTimeout(() => document.getElementById("order-error")?.scrollIntoView({ behavior: "smooth", block: "center" }), 50);
        }
        return;
      }
      setConfirmed({ number: data.number, total: data.total, prepayment: data.prepayment, details: buildDetails(data.number, data.total, data.prepayment) });
      // Сразу убираем из черновика то, что относится только к этому торту: если клиент закроет вкладку,
      // не нажав «Собрать ещё один», старые фото и надпись не уйдут со следующим заказом.
      setPhotos([]);
      setFormSeq((n) => n + 1);
      setForm((f) => ({ ...f, inscription: "", wishes: "" }));
      setDate(null);
      setSlot(null);
      refreshAvailability();
    } catch {
      setServerError("Похоже, пропал интернет. Проверьте соединение — сборка сохранена, можно отправить ещё раз.");
      setTimeout(() => document.getElementById("order-error")?.scrollIntoView({ behavior: "smooth", block: "center" }), 50);
    } finally {
      submitLock.current = false;
      setSubmitting(false);
    }
  };

  const resetAfterOrder = () => {
    setConfirmed(null);
    setDate(null);
    setSlot(null);
    setUrgent(false);
    setUrgentNote(null);
    setServerError(null);
    setGalleryRefId(null);
    setShowAllErrors(false);
    setTouched({});
    setForm((f) => ({ ...f, inscription: "", wishes: "" }));
    setPhotos([]);
    setTimeout(() => scrollTo("builder"), 300);
  };

  // День доступен, только если в нём остался хотя бы один интервал: не занятый и не слишком скорый.
  const effectiveAvailability = useMemo(() => {
    const out: Availability = {};
    for (const [k, info] of Object.entries(availability)) {
      if (info.status !== "free" && info.status !== "few") {
        out[k] = info;
        continue;
      }
      const open = settings.timeSlots.filter((s) => !info.takenSlots.includes(s) && isSlotAvailable(k, s, minLeadHours)).length;
      const left = Math.min(info.left, open);
      out[k] = { ...info, left, status: left === 0 ? "full" : left === 1 ? "few" : "free" };
    }
    return out;
  }, [availability, settings.timeSlots, minLeadHours]);

  const takenSlots = date ? (availability[date]?.takenSlots ?? []) : [];

  // Если после обновления календаря выбранные дата или время заняты — сбрасываем их.
  useEffect(() => {
    if (!date) return;
    const st = effectiveAvailability[date]?.status;
    if (st !== "free" && st !== "few") {
      setDate(null);
      setSlot(null);
    } else if (slot && availability[date]?.takenSlots.includes(slot)) {
      setSlot(null);
    }
  }, [effectiveAvailability, availability, date, slot]);

  const nearestDate = useMemo(
    () => Object.keys(effectiveAvailability).sort().find((k) => effectiveAvailability[k].status === "free" || effectiveAvailability[k].status === "few") ?? null,
    [effectiveAvailability],
  );
  const minPrice = useMemo(() => {
    if (!catalog.fillings.length && catalog.sizes.every((s) => s.fixedPrice == null)) return 0;
    const prices = catalog.sizes.map((s) => s.fixedPrice ?? Math.round(((sizeWeight(s) / 1000) * Math.min(...catalog.fillings.map((f) => f.pricePerKg))) / 10) * 10);
    return prices.length ? Math.min(...prices) : 0;
  }, [catalog]);

  const done = {
    builder: Boolean(sizeId),
    filling: Boolean(fillingId),
    decor: decorIds.length > 0,
    gallery: Boolean(galleryRefId),
    checkout: Boolean(date && slot),
    "order-form": form.name.trim().length >= 2 && phoneDigits(form.phone).length === 10,
  };

  return (
    // reducedMotion="user": при «уменьшить движение» Framer Motion отключает сдвиги и пружины, оставляя только прозрачность.
    <MotionConfig reducedMotion="user">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-choc focus:px-5 focus:py-3 focus:text-[14px] focus:text-cream"
      >
        Перейти к конструктору
      </a>
      <PriceAnnouncer value={quote.total} label="Сумма заказа" />
      {demo && (
        <p className="bg-choc px-4 py-2 text-center text-[13px] leading-snug text-cream">
          Демо-версия сайта для «{settings.brandName}» · заявки отсюда не отправляются
        </p>
      )}
      <Hero demo={demo} settings={settings} nearestDate={nearestDate} fillingsCount={catalog.fillings.length} minPrice={minPrice} />
      <StepNav done={done} />

      <main id="main" tabIndex={-1} className="mx-auto max-w-6xl px-4 outline-none pt-10 sm:px-6 lg:grid lg:grid-cols-[minmax(0,1fr)_340px] lg:gap-14 lg:px-10 lg:pt-14">
        <div className="space-y-16 sm:space-y-20">
          <SizeStep catalog={catalog} sizeId={sizeId} weight={weight} onSize={onSize} onWeight={(g) => setWeight((prev) => clampWeight(typeof g === "function" ? g(prev) : g, catalog))} />
          <FillingStep fillings={catalog.fillings} fillingId={fillingId} fixedPrice={quote.size?.fixedPrice != null} onSelect={setFillingId} />
          <DecorStep
            decor={catalog.decor}
            decorIds={decorIds}
            onToggle={(id) => setDecorIds((ids) => (ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id]))}
            urgent={urgent}
            urgentPct={settings.urgentSurchargePct}
            urgentHours={settings.urgentHours}
            urgentFee={quote.urgentFee}
            urgentLocked={urgentNote}
            onUrgent={onUrgent}
          />

          {/* Промежуточный «чек» на мобильных — видно сумму сборки перед галереей */}
          <div className="rounded-[24px] border border-line-strong bg-whip p-5 lg:hidden">
            <Receipt quote={quote} prepaymentPct={settings.prepaymentPct} date={date} slot={slot} delivery={delivery} compact />
            <button type="button" onClick={() => scrollTo("checkout")} className="btn-primary mt-5 w-full">
              Выбрать дату <ArrowRight size={16} strokeWidth={1.5} />
            </button>
          </div>

          <Gallery catalog={catalog} onRepeat={onRepeat} />

          <Trust settings={settings} content={catalog.content} />

          <Checkout
            settings={settings}
            availability={effectiveAvailability}
            takenSlots={takenSlots}
            date={date}
            slot={slot}
            delivery={delivery}
            form={form}
            errors={visibleErrors}
            total={quote.total}
            submitting={submitting}
            serverError={serverError}
            onDate={onDate}
            onSlot={(s) => {
              setSlot(s);
              // Подсказка «выберите время в ближайшие 24 часа» больше не нужна — время выбрано.
              setUrgentNote(null);
              // Ошибка «время уже заняли» больше не актуальна, как только выбран новый интервал.
              setServerError(null);
            }}
            onDelivery={setDelivery}
            onField={(k, v) => setForm((f) => ({ ...f, [k]: v }))}
            onBlurField={(k) => setTouched((t) => ({ ...t, [k]: true }))}
            onSubmit={onSubmit}
            photos={photos}
            photosKey={formSeq}
            onPhotos={setPhotos}
            onPhotosBusy={setPhotosBusy}
            hasFaq={catalog.content.steps.length + catalog.content.faq.length > 0}
          />

          <Faq settings={settings} content={catalog.content} />
        </div>

        {/* Десктоп: липкий чек справа */}
        <aside className="hidden lg:block" aria-label="Состав заказа">
          {/* Радиусы карточек сведены к одной шкале: 14 — поля и кнопки-плитки, 22 — карточки выбора, 24 — панели (чек, календарь) */}
          <div className="sticky top-[76px] rounded-[24px] border border-line-strong bg-whip p-6">
            <Receipt quote={quote} prepaymentPct={settings.prepaymentPct} date={date} slot={slot} delivery={delivery} />
            {inCheckout ? (
              <button type="submit" form="order-form" disabled={submitting} className="btn-primary mt-6 w-full">
                {submitting && <Loader2 size={16} strokeWidth={1.5} className="animate-spin" />}
                Отправить заявку
              </button>
            ) : (
              <button type="button" onClick={() => scrollTo("checkout")} className="btn-primary mt-6 w-full">
                {date ? "Оформить заказ" : "Выбрать дату"} <ArrowRight size={16} strokeWidth={1.5} />
              </button>
            )}
            <p className="mt-3 text-center text-[12px] text-muted">Без оплаты на сайте — сначала подтвердим детали</p>
          </div>
        </aside>
      </main>

      <Footer settings={settings} />

      <StickyBar
        quote={quote}
        prepaymentPct={settings.prepaymentPct}
        date={date}
        slot={slot}
        delivery={delivery}
        inCheckout={inCheckout}
        submitting={submitting}
        onCheckout={() => scrollTo("checkout")}
      />

      <AnimatePresence>
        {toast && (
          <motion.div
            role="status"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 16 }}
            transition={{ type: "spring", stiffness: 400, damping: 32 }}
            className="fixed inset-x-4 bottom-[calc(96px+var(--sab))] z-[65] mx-auto max-w-md rounded-[16px] bg-choc px-4 py-3 text-center text-[14px] text-cream lg:bottom-8"
          >
            {toast}
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>{confirmed && <Confirmation order={confirmed} settings={settings} onClose={resetAfterOrder} />}</AnimatePresence>
    </MotionConfig>
  );
}
