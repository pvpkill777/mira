"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Loader2, MapPin, Truck, Store, Zap } from "lucide-react";
import type { Availability, PublicSettings } from "@/lib/types";
import { formatPhone, formatPrice, phoneDigits } from "@/lib/format";
import { humanDate, isSlotAvailable, isUrgentSlot } from "@/lib/dates";
import { Calendar } from "./Calendar";
import { SectionTitle } from "./SectionTitle";
import { DesignPhotos } from "./DesignPhotos";

export type OrderForm = {
  name: string;
  phone: string;
  contact: string;
  address: string;
  inscription: string;
  wishes: string;
};

export type FieldErrors = Partial<Record<keyof OrderForm | "date" | "timeSlot" | "size" | "filling", string>>;

export function Checkout({
  settings,
  availability,
  takenSlots,
  date,
  slot,
  delivery,
  form,
  errors,
  total,
  submitting,
  serverError,
  onDate,
  onSlot,
  onDelivery,
  onField,
  onBlurField,
  onSubmit,
  photos,
  photosKey,
  onPhotos,
  onPhotosBusy,
  hasFaq = true,
}: {
  /** Есть ли на странице блок «Как это работает» — иначе ссылку на него не показываем. */
  hasFaq?: boolean;
  photos: string[];
  /** Меняется после каждой отправленной заявки — блок фото начинает с чистого листа (без старых ошибок). */
  photosKey?: number;
  onPhotos: (next: string[] | ((prev: string[]) => string[])) => void;
  onPhotosBusy: (busy: boolean) => void;
  settings: PublicSettings;
  availability: Availability;
  takenSlots: string[];
  date: string | null;
  slot: string | null;
  delivery: boolean;
  form: OrderForm;
  errors: FieldErrors;
  total: number;
  submitting: boolean;
  serverError: string | null;
  onDate: (d: string) => void;
  onSlot: (s: string) => void;
  onDelivery: (v: boolean) => void;
  onField: (k: keyof OrderForm, v: string) => void;
  onBlurField: (k: keyof OrderForm) => void;
  onSubmit: (e: React.FormEvent) => void;
}) {
  const dayInfo = date ? availability[date] : null;
  const bothWays = settings.pickupEnabled && settings.deliveryEnabled;

  return (
    <section aria-labelledby="checkout-title" className="scroll-mt-20" id="checkout">
      <SectionTitle index="04 — Дата и получение" title="Когда и как забрать" hint="Закрытые даты уже заняты другими тортами" id="checkout-title" />

      <div id="date" className="scroll-mt-24">
        <Calendar availability={availability} value={date} onChange={onDate} />
        {errors.date && <p className="mt-2 text-[13px] text-caramel-deep">{errors.date}</p>}
      </div>

      <AnimatePresence initial={false}>
        {date && (
          <motion.div
            key="slots"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 34 }}
            className="overflow-hidden"
          >
            <div className="scroll-mb-[calc(112px+var(--sab))] pt-6 lg:scroll-mb-6" id="slots">
              <div className="flex items-baseline justify-between gap-3">
                <p className="text-[15px] font-medium first-letter:uppercase">{humanDate(date)}</p>
                {dayInfo?.status === "few" && <p className="text-[12px] text-caramel-deep">осталось последнее место</p>}
              </div>

              {/* Способ получения: переключатель — только если кондитер оставила оба способа */}
              {bothWays ? (
              <div className="relative mt-4 grid grid-cols-2 rounded-full border border-line-strong p-1" role="radiogroup" aria-label="Способ получения">
                {[
                  { v: false, label: "Самовывоз", icon: <Store size={16} strokeWidth={1.5} /> },
                  { v: true, label: `Доставка${settings.deliveryFee ? ` +${formatPrice(settings.deliveryFee)}` : ""}`, icon: <Truck size={16} strokeWidth={1.5} /> },
                ].map((o) => (
                  <button
                    key={String(o.v)}
                    type="button"
                    role="radio"
                    aria-checked={delivery === o.v}
                    onClick={() => onDelivery(o.v)}
                    className={`relative flex items-center justify-center gap-2 rounded-full py-3 text-[14px] transition-colors ${delivery === o.v ? "text-cream" : ""}`}
                  >
                    {delivery === o.v && (
                      <motion.span layoutId="delivery-pill" className="absolute inset-0 rounded-full bg-choc" transition={{ type: "spring", stiffness: 500, damping: 38 }} />
                    )}
                    <span className="relative flex items-center gap-2">
                      {o.icon}
                      <span className="num">{o.label}</span>
                    </span>
                  </button>
                ))}
              </div>
              ) : (
                <p className="mt-4 flex items-center gap-2 text-[14px]">
                  {delivery ? <Truck size={16} strokeWidth={1.5} /> : <Store size={16} strokeWidth={1.5} />}
                  <span className="num">
                    {delivery ? `Только доставка${settings.deliveryFee ? ` · ${formatPrice(settings.deliveryFee)}` : " · бесплатно"}` : "Только самовывоз"}
                  </span>
                </p>
              )}
              {!delivery && (
                <p className="mt-3 flex items-start gap-2 text-[13px] text-muted">
                  <MapPin size={15} strokeWidth={1.5} className="mt-0.5 shrink-0" /> {settings.pickupAddress}
                </p>
              )}

              {/* Время */}
              <p id="slots-label" className="mt-6 text-[13px] text-muted">{delivery ? "Интервал доставки" : "Время выдачи"}</p>
              <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3" role="radiogroup" aria-labelledby="slots-label" aria-required="true">
                {settings.timeSlots.map((s) => {
                  const taken = takenSlots.includes(s);
                  const available = !taken && isSlotAvailable(date, s, settings.minLeadHours);
                  const urgent = available && isUrgentSlot(date, s, settings.urgentHours);
                  const active = slot === s;
                  // «10:00–12:00» скринридер читает как «десять ноль ноль двенадцать…» — даём понятное имя.
                  const [from, to] = s.split(/\s*[–—-]\s*/);
                  const spoken = `${to ? `с ${from} до ${to}` : s}${taken ? ", занято" : !available ? ", недоступно" : urgent ? `, срочно, плюс ${settings.urgentSurchargePct}%` : ""}`;
                  return (
                    <button
                      key={s}
                      type="button"
                      role="radio"
                      aria-label={spoken}
                      aria-checked={active}
                      disabled={!available}
                      onClick={() => onSlot(s)}
                      className={`relative flex min-h-[64px] flex-col items-center justify-center rounded-[14px] border px-3 py-2 text-[14px] transition-[border-color,background-color,color,transform] duration-200 active:scale-[0.98] ${
                        active ? "border-choc bg-choc text-cream" : "border-line-strong bg-white/40 enabled:hover:border-choc/60"
                      } disabled:cursor-not-allowed disabled:border-dashed disabled:border-line-strong disabled:bg-transparent disabled:text-choc/35 disabled:active:scale-100`}
                    >
                      <span className={`num ${available ? "" : "line-through decoration-choc/30"}`}>{s}</span>
                      {taken && <span className="mt-0.5 block text-[11px] tracking-[0.04em] text-muted">занято</span>}
                      {urgent && (
                        <span className={`mt-0.5 flex items-center justify-center gap-1 text-[11px] ${active ? "text-cream/80" : "text-caramel-deep"}`}>
                          <Zap size={11} strokeWidth={1.5} /> срочно +{settings.urgentSurchargePct}%
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
              {errors.timeSlot && <p className="mt-2 text-[13px] text-caramel-deep">{errors.timeSlot}</p>}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Контакты */}
      <form id="order-form" onSubmit={onSubmit} noValidate className="mt-12">
        <SectionTitle index="05 — Контакты" title="Куда написать" hint="Ответим в течение часа и пришлём реквизиты" />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Имя" error={errors.name} htmlFor="f-name">
            <input
              id="f-name"
              maxLength={80}
              className="field"
              autoComplete="given-name"
              value={form.name}
              onChange={(e) => onField("name", e.target.value)}
              onBlur={() => onBlurField("name")}
              aria-invalid={Boolean(errors.name)}
              placeholder="Анна"
            />
          </Field>
          <Field label="Телефон" error={errors.phone} htmlFor="f-phone">
            <input
              id="f-phone"
              className="field num"
              type="tel"
              inputMode="tel"
              autoComplete="tel"
              value={form.phone}
              onFocus={() => !form.phone && onField("phone", "+7 (")}
              onChange={(e) => onField("phone", formatPhone(e.target.value))}
              onBlur={() => {
                // Пустая маска «+7 (» не должна оставаться в поле и в черновике.
                if (!phoneDigits(form.phone)) onField("phone", "");
                onBlurField("phone");
              }}
              aria-invalid={Boolean(errors.phone)}
              placeholder="+7 (999) 123-45-67"
            />
          </Field>
          <Field label="Telegram или Instagram" hint="необязательно" htmlFor="f-contact">
            <input
              id="f-contact"
              maxLength={80}
              className="field"
              value={form.contact}
              autoCapitalize="none"
              autoCorrect="off"
              onChange={(e) => onField("contact", e.target.value)}
              placeholder="@nickname"
            />
          </Field>
          {delivery && (
            <Field label="Адрес доставки" error={errors.address} htmlFor="f-address">
              <input
                id="f-address"
                maxLength={300}
                className="field"
                autoComplete="street-address"
                value={form.address}
                onChange={(e) => onField("address", e.target.value)}
                onBlur={() => onBlurField("address")}
                aria-invalid={Boolean(errors.address)}
                placeholder="Улица, дом, подъезд, квартира"
              />
            </Field>
          )}
          <Field label="Надпись на торте" hint="необязательно" htmlFor="f-inscription" className="sm:col-span-2">
            <input
              id="f-inscription"
              className="field"
              maxLength={60}
              value={form.inscription}
              onChange={(e) => onField("inscription", e.target.value)}
              placeholder="С днём рождения, мама"
            />
          </Field>
          <Field label="Пожелания" hint="аллергии, цвета, детали" htmlFor="f-wishes" className="sm:col-span-2">
            <textarea
              id="f-wishes"
              maxLength={1000}
              className="field min-h-[96px] resize-y"
              value={form.wishes}
              onChange={(e) => onField("wishes", e.target.value)}
              placeholder="Например: без ярких красителей, в пастельных тонах"
            />
          </Field>
          <div className="sm:col-span-2" id="design-photos">
            <DesignPhotos key={photosKey} photos={photos} onChange={onPhotos} onBusyChange={onPhotosBusy} />
          </div>
        </div>

        {serverError && (
          <p id="order-error" role="alert" className="mt-5 rounded-[14px] border border-caramel/40 bg-caramel-soft/60 px-4 py-3 text-[14px]">
            {serverError}
          </p>
        )}

        {/* Снимаем главный страх перед отправкой: деньги сейчас не списываются, понятно, когда и сколько платить */}
        <div className="mt-6 rounded-[18px] border border-line bg-white/40 px-4 py-3.5 text-[14px] leading-snug">
          <p className="font-medium">Сейчас платить ничего не&nbsp;нужно</p>
          <p className="mt-1 text-muted">
            {settings.prepaymentPct
              ? `Сначала подтвердим детали, затем пришлём реквизиты: предоплата ${settings.prepaymentPct}% закрепит дату за вами.`
              : "Сначала подтвердим детали — после этого дата закрепится за вами."}{" "}
            {hasFaq && (
            <a href="#faq" className="whitespace-nowrap text-choc underline decoration-line-strong underline-offset-4 hover:decoration-choc">
              Как это работает
            </a>
            )}
          </p>
        </div>

        <button type="submit" disabled={submitting} className="btn-primary mt-6 flex w-full py-[17px] text-[16px]">
          {submitting && <Loader2 size={18} className="animate-spin" />}
          Отправить заявку · <span className="num">{formatPrice(total)}</span>
        </button>
        <p className="mt-3 text-[12px] leading-relaxed text-muted">
          Нажимая «Отправить заявку», вы&nbsp;соглашаетесь на&nbsp;обработку контактных данных для&nbsp;связи по&nbsp;заказу.
        </p>
      </form>
    </section>
  );
}

function Field({
  label,
  hint,
  error,
  htmlFor,
  className = "",
  children,
}: {
  label: string;
  hint?: string;
  error?: string;
  htmlFor: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div className={className}>
      <label htmlFor={htmlFor} className="mb-1.5 flex items-baseline justify-between text-[13px] font-medium">
        {label}
        {hint && <span className="text-[12px] font-normal text-muted">{hint}</span>}
      </label>
      {children}
      <AnimatePresence>
        {error && (
          <motion.p initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-1.5 text-[13px] text-caramel-deep">
            {error}
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}
