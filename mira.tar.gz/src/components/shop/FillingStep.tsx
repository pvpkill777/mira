"use client";

import { motion } from "framer-motion";
import { Check } from "lucide-react";
import type { FillingDTO } from "@/lib/types";
import { formatPrice } from "@/lib/format";
import { typograph } from "@/lib/content";
import { responsiveImage } from "@/lib/images";
import { SectionTitle } from "./SectionTitle";

export function FillingStep({
  fillings,
  fillingId,
  fixedPrice,
  onSelect,
}: {
  fillings: FillingDTO[];
  fillingId: string | null;
  fixedPrice: boolean;
  onSelect: (id: string) => void;
}) {
  return (
    <section aria-labelledby="filling-title" className="scroll-mt-20" id="filling">
      <SectionTitle
        index="02 — Начинка"
        title="Что внутри"
        hint={fixedPrice ? "Для бенто — любая начинка без доплаты" : "Цена за 1 кг сразу пересчитается"}
        id="filling-title"
      />
      <div className="grid grid-cols-2 gap-x-3 gap-y-6 lg:grid-cols-3">
        {fillings.map((f, i) => {
          const active = f.id === fillingId;
          return (
            <motion.button
              key={f.id}
              type="button"
              onClick={() => onSelect(f.id)}
              aria-pressed={active}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ type: "spring", stiffness: 200, damping: 26, delay: (i % 3) * 0.05 }}
              className="group flex flex-col text-left"
            >
              <span
                className={`relative block overflow-hidden rounded-[20px] border transition-all duration-300 ${
                  active ? "border-choc p-1" : "border-transparent p-0"
                }`}
              >
                <span className="relative block overflow-hidden rounded-[16px] bg-whip">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    {...responsiveImage(f.imageUrl, [320, 480, 640])}
                    sizes="(min-width: 1024px) 230px, (min-width: 640px) 31vw, 47vw"
                    width={480}
                    height={600}
                    alt={`Разрез торта «${f.name}»`}
                    loading="lazy"
                    decoding="async"
                    className="aspect-[4/5] w-full object-cover transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.04]"
                  />
                  {f.tags.length > 0 && (
                    // Не больше трёх тегов и не шире карточки — иначе на телефоне они закрывали фото.
                    <span className="absolute left-2 right-2 top-2 flex flex-wrap gap-1">
                      {f.tags.slice(0, 3).map((t) => (
                        <span
                          key={t}
                          className={`max-w-full truncate rounded-full px-2 py-[3px] text-[10px] font-semibold uppercase tracking-[0.08em] ${
                            t === "Хит" ? "bg-caramel-deep text-cream" : "bg-cream/90 text-choc"
                          }`}
                        >
                          {t}
                        </span>
                      ))}
                    </span>
                  )}
                  <span
                    className={`absolute bottom-2 right-2 flex h-8 w-8 items-center justify-center rounded-full transition-all duration-300 ${
                      active ? "scale-100 bg-choc text-cream" : "scale-90 bg-cream/85 text-transparent"
                    }`}
                  >
                    <Check size={16} strokeWidth={2} />
                  </span>
                </span>
              </span>
              <span className="display mt-3 text-[length:clamp(18px,calc(5vw_+_2px),24px)] leading-[1.1] hyphens-auto [overflow-wrap:anywhere]">{typograph(f.name)}</span>
              {f.description && <span className="mt-1.5 line-clamp-3 text-[13px] leading-snug text-muted [overflow-wrap:anywhere] sm:line-clamp-4">{typograph(f.description)}</span>}
              {/* mt-auto: цена на одной линии у всех карточек ряда */}
              <span className="mt-auto w-full pt-2.5">
                <span className="block border-t border-line pt-2 text-[13px]">
                {fixedPrice ? (
                  <span className="text-muted">входит в цену бенто</span>
                ) : (
                  <>
                    <span className="num font-semibold">{formatPrice(f.pricePerKg)}</span>
                    <span className="text-muted"> / кг</span>
                  </>
                )}
                </span>
              </span>
            </motion.button>
          );
        })}
      </div>
    </section>
  );
}
