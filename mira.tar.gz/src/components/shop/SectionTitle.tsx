export function SectionTitle({ index, title, hint, id }: { index: string; title: string; hint?: string; id?: string }) {
  return (
    // На телефоне подсказка идёт под заголовком (а не узкой колонкой справа) — так не ломается надзаголовок и не жмётся заголовок.
    <div className="mb-6 border-b border-line pb-4 sm:flex sm:items-end sm:justify-between sm:gap-6">
      <div>
        <p className="eyebrow num">{index}</p>
        <h2 id={id} className="display mt-2 text-[36px] sm:text-[44px]">
          {title}
        </h2>
      </div>
      {hint && <p className="mt-2 max-w-[34ch] text-[13px] leading-snug text-muted sm:mt-0 sm:max-w-xs sm:pb-1.5 sm:text-right">{hint}</p>}
    </div>
  );
}
