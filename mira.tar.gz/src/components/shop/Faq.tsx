"use client";

import { Plus } from "lucide-react";
import type { PublicSettings, SiteContent } from "@/lib/types";
import { fillTemplate, typograph } from "@/lib/content";

/*
 * «Как это работает» и частые вопросы. Заголовок, шаги и вопросы редактируются в кабинете
 * («Тексты сайта»); цифры подставляются из настроек через {предоплата}, {горизонт} и т. п.
 */
export function Faq({ settings, content }: { settings: PublicSettings; content: Pick<SiteContent, "steps" | "faq"> }) {
  const t = (s: string) => typograph(fillTemplate(s.trim(), settings));
  const title = t(settings.faqTitle);
  const steps = content.steps.map((s) => ({ id: s.id, title: t(s.title), text: t(s.text) })).filter((s) => s.title || s.text);
  const questions = content.faq.map((f) => ({ id: f.id, q: t(f.title), a: t(f.text) })).filter((f) => f.q && f.a);

  // Нечего показать — секции нет совсем, без пустого заголовка.
  if (!steps.length && !questions.length) return null;
  const eyebrow = steps.length ? "Как это работает" : "Частые вопросы";

  return (
    <section aria-labelledby="faq-title" className="scroll-mt-20" id="faq">
      <div className="mb-6 border-b border-line pb-4">
        {title && <p className="eyebrow">{eyebrow}</p>}
        <h2 id="faq-title" className={`display text-[36px] sm:text-[44px] ${title ? "mt-2" : ""}`}>
          {title || eyebrow}
        </h2>
      </div>

      {steps.length > 0 && (
        // На десктопе колонка рядом с чеком узкая (~680px): 4 колонки давали по 5–6 строк на шаг, поэтому там 2×2
        <ol className="grid gap-x-8 gap-y-6 sm:grid-cols-2 md:grid-cols-4 md:gap-x-6 lg:grid-cols-2 lg:gap-x-10">
          {steps.map((s, i) => (
            <li key={s.id} className="border-t border-line-strong pt-3">
              <p className="flex items-baseline gap-2.5">
                <span className="display num text-[22px] leading-none text-caramel-deep">{String(i + 1).padStart(2, "0")}</span>
                <span className="text-[15px] font-medium">{s.title}</span>
              </p>
              {s.text && <p className="mt-1.5 text-[14px] leading-snug text-muted">{s.text}</p>}
            </li>
          ))}
        </ol>
      )}

      {questions.length > 0 && (
        <>
          {steps.length > 0 && <p className="eyebrow mt-12">Частые вопросы</p>}
          <div className={`divide-y divide-line border-y border-line ${steps.length > 0 ? "mt-3" : ""}`}>
            {questions.map((item) => (
              <details key={item.id} className="group">
                <summary className="flex min-h-[56px] cursor-pointer list-none items-center justify-between gap-4 py-4 text-[15px] font-medium transition-colors hover:text-caramel-deep [&::-webkit-details-marker]:hidden">
                  {item.q}
                  <Plus
                    size={18}
                    strokeWidth={1.5}
                    aria-hidden
                    className="shrink-0 text-muted transition-[transform,color] duration-300 ease-[cubic-bezier(.22,1,.36,1)] group-open:rotate-45 group-open:text-choc"
                  />
                </summary>
                <p className="max-w-[62ch] whitespace-pre-line pb-5 pr-8 text-[14px] leading-relaxed text-muted">{item.a}</p>
              </details>
            ))}
          </div>
        </>
      )}
    </section>
  );
}