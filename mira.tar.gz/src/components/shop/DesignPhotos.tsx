"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ImagePlus, Loader2, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { MAX_DESIGN_PHOTOS } from "@/lib/types";

type Pending = { id: string; preview: string };

const MAX_SIDE = 1600;

/** Уменьшает фото на устройстве и перекодирует в JPEG (заодно превращает HEIC с iPhone в обычный JPEG). */
async function compress(file: File): Promise<Blob> {
  let source: ImageBitmap | HTMLImageElement;
  try {
    source = await createImageBitmap(file, { imageOrientation: "from-image" });
  } catch {
    const src = URL.createObjectURL(file);
    try {
      source = await new Promise<HTMLImageElement>((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = src;
      });
    } finally {
      URL.revokeObjectURL(src);
    }
  }
  const w = "naturalWidth" in source ? source.naturalWidth : source.width;
  const h = "naturalHeight" in source ? source.naturalHeight : source.height;
  const scale = Math.min(1, MAX_SIDE / Math.max(w, h));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(w * scale);
  canvas.height = Math.round(h * scale);
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("canvas");
  // Прозрачный PNG (скриншот, стикер) в JPEG иначе получает чёрный фон.
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
  if ("close" in source) source.close();
  return new Promise((resolve, reject) => canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("blob"))), "image/jpeg", 0.85));
}

export function DesignPhotos({
  photos,
  onChange,
  onBusyChange,
}: {
  photos: string[];
  onChange: (next: string[] | ((prev: string[]) => string[])) => void;
  onBusyChange: (busy: boolean) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [pending, setPending] = useState<Pending[]>([]);
  const [error, setError] = useState<string | null>(null);
  const free = MAX_DESIGN_PHOTOS - photos.length - pending.length;

  useEffect(() => onBusyChange(pending.length > 0), [pending.length, onBusyChange]);

  const upload = async (file: File) => {
    const id = Math.random().toString(36).slice(2);
    const preview = URL.createObjectURL(file);
    setPending((p) => [...p, { id, preview }]);
    try {
      let body: Blob = file;
      try {
        body = await compress(file);
      } catch {
        /* браузер не смог прочитать формат — отправим оригинал, сервер попробует сам */
      }
      const fd = new FormData();
      fd.append("file", body, "design.jpg");
      const res = await fetch("/api/uploads/design", { method: "POST", body: fd });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.url) throw new Error(data.error ?? "Фото не загрузилось. Попробуйте ещё раз.");
      onChange((prev) => (prev.length < MAX_DESIGN_PHOTOS ? [...prev, data.url] : prev));
    } catch (e) {
      // Сетевой сбой fetch — это TypeError с текстом браузера по-английски («Failed to fetch», в Safari «Load failed»): его не показываем.
      setError(e instanceof Error && !(e instanceof TypeError) ? e.message : "Нет соединения — фото не загрузилось. Попробуйте ещё раз.");
    } finally {
      setPending((p) => p.filter((x) => x.id !== id));
      URL.revokeObjectURL(preview);
    }
  };

  const onPick = (files: FileList | null) => {
    setError(null);
    if (!files?.length) return;
    const list = [...files].filter((f) => f.type.startsWith("image/") || /\.(heic|heif)$/i.test(f.name));
    if (list.length < files.length) setError("Можно прикрепить только изображения.");
    if (list.length > free) setError(`Можно прикрепить не больше ${MAX_DESIGN_PHOTOS} фото.`);
    list.slice(0, Math.max(0, free)).forEach(upload);
  };

  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between text-[13px] font-medium">
        <span id="design-photos-label">Фото дизайна</span>
        <span className="text-[12px] font-normal text-muted">необязательно · до {MAX_DESIGN_PHOTOS}</span>
      </div>
      <ul className="flex flex-wrap gap-2.5" aria-labelledby="design-photos-label">
        <AnimatePresence initial={false}>
          {photos.map((url, i) => (
            <motion.li
              key={url}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative h-[84px] w-[84px]"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={url} alt={`Референс дизайна ${i + 1}`} className="h-full w-full rounded-[14px] border border-line object-cover" />
              <button
                type="button"
                onClick={() => onChange((prev) => prev.filter((u) => u !== url))}
                aria-label={`Удалить фото ${i + 1}`}
                // Видимый кружок 32px, тап-зона 44px за счёт псевдоэлемента.
                className="absolute -right-2 -top-2 flex h-8 w-8 items-center justify-center rounded-full border border-line-strong bg-cream text-choc before:absolute before:-inset-1.5 before:content-['']"
              >
                <X size={15} strokeWidth={1.5} />
              </button>
            </motion.li>
          ))}
          {pending.map((p) => (
            <motion.li key={p.id} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="relative h-[84px] w-[84px]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={p.preview} alt="" className="h-full w-full rounded-[14px] border border-line object-cover opacity-50" />
              <span className="absolute inset-0 flex items-center justify-center" role="status" aria-label="Фото загружается">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-cream/90">
                  <Loader2 size={16} strokeWidth={1.5} className="animate-spin text-choc" />
                </span>
              </span>
            </motion.li>
          ))}
        </AnimatePresence>
        {free > 0 && (
          <li>
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="flex h-[84px] w-[84px] flex-col items-center justify-center gap-1.5 rounded-[14px] border border-dashed border-line-strong bg-white/40 text-[12px] text-muted transition-[border-color,color,transform] duration-200 hover:border-choc hover:text-choc active:scale-[0.97]"
            >
              <ImagePlus size={20} strokeWidth={1.5} aria-hidden />
              {photos.length + pending.length ? "Ещё фото" : "Добавить"}
            </button>
          </li>
        )}
      </ul>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        aria-label="Выбрать фото дизайна"
        onChange={(e) => {
          onPick(e.target.files);
          e.target.value = "";
        }}
      />
      {error ? (
        <p role="alert" className="mt-2 text-[13px] text-caramel-deep">
          {error}
        </p>
      ) : (
        <p className="mt-2 text-[12px] leading-snug text-muted">Скриншот из Pinterest, эскиз или фото торта, который понравился, — так точнее поймём идею.</p>
      )}
    </div>
  );
}
