import { AtSign, MessageCircle, Send } from "lucide-react";
import type { PublicSettings } from "@/lib/types";
import { Monogram } from "@/components/ui/Monogram";

export function Footer({ settings }: { settings: PublicSettings }) {
  // Пустые контакты в кабинете — значит, их не показываем (иначе ссылки вели бы в никуда).
  const contacts = [
    settings.telegram && { href: `https://t.me/${settings.telegram}`, icon: <Send size={15} strokeWidth={1.5} />, label: `@${settings.telegram}` },
    settings.whatsapp && { href: `https://wa.me/${settings.whatsapp}`, icon: <MessageCircle size={15} strokeWidth={1.5} />, label: "WhatsApp" },
    settings.instagram && { href: `https://instagram.com/${settings.instagram}`, icon: <AtSign size={15} strokeWidth={1.5} />, label: settings.instagram },
  ].filter(Boolean) as { href: string; icon: React.ReactNode; label: string }[];

  return (
    <footer className="mt-20 border-t border-line pb-[calc(120px+var(--sab))] lg:pb-12">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 pt-12 sm:px-6 md:grid-cols-2 lg:px-10">
        <div>
          <div className="flex items-center gap-3">
            <Monogram size={44} />
            <div className="min-w-0">
              <p className="display text-[26px] leading-none [overflow-wrap:anywhere]">{settings.brandName}</p>
              {settings.tagline && <p className="mt-1 text-[12px] text-muted [overflow-wrap:anywhere]">{settings.tagline}</p>}
            </div>
          </div>
        </div>
        {(contacts.length > 0 || (settings.pickupEnabled && settings.pickupAddress)) && (
          <div className="min-w-0 text-[14px]">
            {contacts.length > 0 && (
              <>
                <p className="eyebrow mb-3">Связаться</p>
                <ul className="space-y-1">
                  {contacts.map((c) => (
                    <li key={c.href}>
                      <a className="inline-flex min-h-11 items-center gap-2 [overflow-wrap:anywhere] hover:text-caramel-deep" href={c.href} target="_blank" rel="noreferrer">
                        {c.icon} {c.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </>
            )}
            {settings.pickupEnabled && settings.pickupAddress && (
              <p className="mt-4 text-muted [overflow-wrap:anywhere]">Самовывоз: {settings.pickupAddress}</p>
            )}
          </div>
        )}
      </div>
    </footer>
  );
}
