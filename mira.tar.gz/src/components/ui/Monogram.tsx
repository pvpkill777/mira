/** Монограмма. Без letter — фирменная «М»; с letter — первая буква названия (демо для других кондитеров). */
export function Monogram({ size = 40, className = "", letter }: { size?: number; className?: string; letter?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 512 512" className={className} aria-hidden>
      <circle cx="256" cy="256" r="236" fill="#F2ECE4" stroke="#231F1E" strokeOpacity="0.2" strokeWidth="6" />
      {letter ? (
        <text x="256" y="338" textAnchor="middle" fontSize="230" fill="#231F1E" style={{ fontFamily: "var(--font-cormorant), serif" }}>
          {letter}
        </text>
      ) : (
        <path d="M 166 338 L 166 196 L 256 300 L 346 196 L 346 338" fill="none" stroke="#231F1E" strokeWidth="26" strokeLinecap="square" />
      )}
      <line x1="140" y1="370" x2="372" y2="370" stroke="#231F1E" strokeWidth="5" />
      <circle cx="256" cy="150" r="17" fill="#B86B4B" />
    </svg>
  );
}
