"use client";

import { animate, motion, useMotionValue, useReducedMotion, useTransform } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { formatPrice } from "@/lib/format";

/**
 * Анимированная цена. Бегущие цифры скрыты от скринридера (aria-hidden), ему отдаётся
 * только итоговое значение — иначе он зачитывал промежуточные кадры анимации.
 * Объявление об изменении суммы делает один общий <PriceAnnouncer>, а не каждая копия цены.
 */
export function AnimatedPrice({ value, className }: { value: number; className?: string }) {
  const mv = useMotionValue(value);
  const reduce = useReducedMotion();
  const text = useTransform(mv, (v) => formatPrice(Math.round(v / 10) * 10));
  useEffect(() => {
    if (reduce) {
      mv.set(value);
      return;
    }
    const controls = animate(mv, value, { type: "spring", stiffness: 160, damping: 24, mass: 0.8 });
    return () => controls.stop();
  }, [mv, value, reduce]);
  return (
    <span className={`num ${className ?? ""}`}>
      <motion.span aria-hidden>{text}</motion.span>
      <span className="sr-only">{formatPrice(value)}</span>
    </span>
  );
}

/** Невидимая «живая» область: сообщает новую сумму, когда клиент перестал её менять (без дребезга ползунка). */
export function PriceAnnouncer({ value, label = "Итого" }: { value: number; label?: string }) {
  const [message, setMessage] = useState("");
  const first = useRef(true);
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    const t = setTimeout(() => setMessage(`${label}: ${formatPrice(value)}`), 800);
    return () => clearTimeout(t);
  }, [value, label]);
  return (
    <p role="status" aria-live="polite" aria-atomic="true" className="sr-only">
      {message}
    </p>
  );
}
