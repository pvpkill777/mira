"use client";

import { motion } from "framer-motion";

export function SwitchVisual({ on }: { on: boolean }) {
  return (
    <span
      aria-hidden
      className={`relative inline-flex h-[26px] w-[44px] shrink-0 items-center rounded-full border transition-colors duration-300 ${
        on ? "border-choc bg-choc" : "border-line-strong bg-white/60"
      }`}
    >
      <motion.span
        layout
        transition={{ type: "spring", stiffness: 600, damping: 34 }}
        className={`absolute h-[20px] w-[20px] rounded-full ${on ? "bg-cream" : "bg-choc/80"}`}
        style={{ left: on ? 20 : 2 }}
      />
    </span>
  );
}
