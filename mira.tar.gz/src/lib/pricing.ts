import type { Catalog, DecorDTO, FillingDTO, SizeDTO } from "./types";

export type Selection = {
  sizeId: string | null;
  weightGrams: number;
  fillingId: string | null;
  decorIds: string[];
  urgent: boolean;
  delivery: boolean;
};

export type QuoteLine = { label: string; detail?: string; amount: number };

export type Quote = {
  size: SizeDTO | null;
  filling: FillingDTO | null;
  decor: DecorDTO[];
  weightGrams: number;
  basePrice: number;
  decorTotal: number;
  urgentFee: number;
  deliveryFee: number;
  total: number;
  prepayment: number;
  lines: QuoteLine[];
  complete: boolean;
};

const round10 = (n: number) => Math.round(n / 10) * 10;

type PricingCatalog = Pick<Catalog, "sizes" | "fillings" | "decor"> & {
  settings: Pick<Catalog["settings"], "urgentSurchargePct" | "prepaymentPct" | "deliveryFee" | "customMinGrams" | "customMaxGrams">;
};

export function clampWeight(grams: number, catalog: PricingCatalog): number {
  const { customMinGrams, customMaxGrams } = catalog.settings;
  const stepped = Math.round(grams / 100) * 100;
  return Math.min(customMaxGrams, Math.max(customMinGrams, stepped));
}

/**
 * Единая формула расчёта — используется и в браузере (живой пересчёт),
 * и на сервере (сервер всегда пересчитывает цену сам и не доверяет клиенту).
 */
export function calculateQuote(sel: Selection, catalog: PricingCatalog): Quote {
  const size = catalog.sizes.find((s) => s.id === sel.sizeId) ?? null;
  const filling = catalog.fillings.find((f) => f.id === sel.fillingId) ?? null;
  const decor = catalog.decor.filter((d) => sel.decorIds.includes(d.id));

  let weightGrams = size ? size.weightGrams : 0;
  if (size && size.adjustable && size.fixedPrice == null) {
    weightGrams = clampWeight(sel.weightGrams || size.weightGrams, catalog);
  }

  let basePrice = 0;
  if (size?.fixedPrice != null) basePrice = size.fixedPrice;
  else if (size && filling) basePrice = round10((weightGrams / 1000) * filling.pricePerKg);

  const decorTotal = decor.reduce((s, d) => s + d.price, 0);
  const urgentFee = sel.urgent ? round10(((basePrice + decorTotal) * catalog.settings.urgentSurchargePct) / 100) : 0;
  const deliveryFee = sel.delivery ? catalog.settings.deliveryFee : 0;
  const total = basePrice + decorTotal + urgentFee + deliveryFee;
  const prepayment = round10((total * catalog.settings.prepaymentPct) / 100);

  const lines: QuoteLine[] = [];
  if (size) {
    lines.push({
      label: size.fixedPrice != null ? size.name : `Торт · ${filling ? filling.name : "начинка не выбрана"}`,
      detail:
        size.fixedPrice != null
          ? `${filling ? filling.name : "начинка на выбор"} · фиксированная цена`
          : filling
            ? `${(weightGrams / 1000).toString().replace(".", ",")} кг × ${filling.pricePerKg.toLocaleString("ru-RU")} ₽`
            : undefined,
      amount: basePrice,
    });
  }
  for (const d of decor) lines.push({ label: d.name, amount: d.price });
  if (urgentFee) lines.push({ label: "Срочный заказ", detail: `+${catalog.settings.urgentSurchargePct}%`, amount: urgentFee });
  if (deliveryFee) lines.push({ label: "Доставка", amount: deliveryFee });

  return {
    size,
    filling,
    decor,
    weightGrams,
    basePrice,
    decorTotal,
    urgentFee,
    deliveryFee,
    total,
    prepayment,
    lines,
    complete: Boolean(size && filling),
  };
}
