export type SizeDTO = {
  id: string;
  name: string;
  weightGrams: number;
  guestsLabel: string;
  fixedPrice: number | null;
  adjustable: boolean;
};

export type FillingDTO = {
  id: string;
  name: string;
  description: string;
  pricePerKg: number;
  imageUrl: string;
  tags: string[];
};

export type DecorDTO = {
  id: string;
  name: string;
  description: string;
  price: number;
};

/** Слаг категории галереи — категории хранятся в базе (GalleryCategory) и редактируются в кабинете. */
export type GalleryCategory = string;

export type GalleryCategoryDTO = { slug: string; label: string };

/** Пункт редактируемого списка текстов: вопрос FAQ, шаг, принцип или отзыв. */
export type ContentDTO = { id: string; title: string; text: string; detail: string };

export type SiteContent = {
  faq: ContentDTO[];
  steps: ContentDTO[];
  principles: ContentDTO[];
  reviews: ContentDTO[];
};

export type GalleryDTO = {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  category: GalleryCategory;
  weightGrams: number;
  sizeId: string | null;
  fillingId: string | null;
  decorIds: string[];
};

export type PublicSettings = {
  brandName: string;
  ownerName: string;
  tagline: string;
  city: string;
  avatarUrl: string;
  heroImageUrl: string;
  telegram: string;
  whatsapp: string;
  instagram: string;
  pickupAddress: string;
  urgentSurchargePct: number;
  prepaymentPct: number;
  deliveryFee: number;
  timeSlots: string[];
  customMinGrams: number;
  customMaxGrams: number;
  bookingHorizonDays: number;
  minLeadHours: number;
  urgentHours: number;
  pickupEnabled: boolean;
  deliveryEnabled: boolean;
  heroTitle: string;
  heroSubtitle: string;
  aboutTitle: string;
  aboutQuote: string;
  aboutText: string;
  faqTitle: string;
  seoTitle: string;
  seoDescription: string;
};

export type Catalog = {
  settings: PublicSettings;
  sizes: SizeDTO[];
  fillings: FillingDTO[];
  decor: DecorDTO[];
  gallery: GalleryDTO[];
  galleryCategories: GalleryCategoryDTO[];
  content: SiteContent;
};

export type DayStatus = "free" | "few" | "full" | "closed" | "off" | "past";

export type DayInfo = { status: DayStatus; left: number; takenSlots: string[] };

export type Availability = Record<string, DayInfo>;

/** Сколько фото-референсов дизайна клиент может приложить к заявке */
export const MAX_DESIGN_PHOTOS = 3;

export type OrderStatus ="NEW" | "CONFIRMED" | "DONE" | "CANCELLED";
