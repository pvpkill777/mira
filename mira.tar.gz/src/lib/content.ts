import { formatPrice, plural } from "./format";
import type { PublicSettings } from "./types";

/**
 * Подстановки в текстах сайта, которые кондитер пишет в кабинете.
 * Числа берутся из настроек, поэтому тексты не устаревают, когда меняются условия.
 */
export const TEMPLATE_VARIABLES: { key: string; hint: string }[] = [
  { key: "{имя}", hint: "имя кондитера (первое слово)" },
  { key: "{бренд}", hint: "название кондитерской" },
  { key: "{город}", hint: "город" },
  { key: "{адрес}", hint: "адрес самовывоза" },
  { key: "{предоплата}", hint: "процент предоплаты, например «50%»" },
  { key: "{срочность}", hint: "наценка за срочность, например «20%»" },
  { key: "{доставка}", hint: "стоимость доставки, например «450 ₽»" },
  { key: "{горизонт}", hint: "на сколько дней вперёд открыта запись, например «60 дней»" },
];

export function fillTemplate(text: string, s: PublicSettings): string {
  const values: Record<string, string> = {
    "{имя}": s.ownerName.split(" ")[0] ?? "",
    "{бренд}": s.brandName,
    "{город}": s.city,
    "{адрес}": s.pickupAddress,
    "{предоплата}": `${s.prepaymentPct}%`,
    "{срочность}": `${s.urgentSurchargePct}%`,
    "{доставка}": s.deliveryFee ? formatPrice(s.deliveryFee) : "бесплатно",
    "{горизонт}": `${s.bookingHorizonDays} ${plural(s.bookingHorizonDays, "день", "дня", "дней")}`,
  };
  return text.replace(/\{[а-яё]+\}/gi, (m) => values[m.toLowerCase()] ?? m);
}

/**
 * Неразрывные пробелы после коротких слов («в календаре», «и декор») и перед тире —
 * чтобы предлоги не висели в конце строки. Тексты из кабинета пишутся обычными пробелами.
 */
export function typograph(text: string): string {
  return text
    .replace(/(?<=^|[\s(«"*])([а-яёa-z]{1,2}) /gi, "$1 ")
    .replace(/ (—|–)/g, " $1");
}

/** «Авторские торты *из 100% натуральных* ингредиентов» → куски текста с пометкой, какие выделить курсивом. */
export function splitAccent(text: string): { text: string; accent: boolean }[] {
  return text
    .split(/(\*[^*]+\*)/)
    .filter(Boolean)
    .map((part) => (part.startsWith("*") && part.endsWith("*") ? { text: part.slice(1, -1), accent: true } : { text: part, accent: false }));
}
