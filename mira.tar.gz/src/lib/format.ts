const NBSP = " ";

export function formatPrice(value: number): string {
  const rounded = Math.round(value);
  const s = Math.abs(rounded)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, NBSP);
  return `${rounded < 0 ? "−" : ""}${s}${NBSP}₽`;
}

export function formatWeight(grams: number): string {
  if (grams < 1000) return `${grams}${NBSP}г`;
  const kg = grams / 1000;
  const str = Number.isInteger(kg) ? kg.toString() : kg.toFixed(kg * 10 === Math.round(kg * 10) ? 1 : 2);
  return `${str.replace(".", ",")}${NBSP}кг`;
}

export function plural(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}

export function guestsForWeight(grams: number): string {
  if (grams <= 600) return "1–2 гостя";
  const max = Math.max(2, Math.round(grams / 180));
  const min = Math.max(1, Math.round(grams / 230));
  if (min === max) return `${max} ${plural(max, "гость", "гостя", "гостей")}`;
  return `${min}–${max} ${plural(max, "гость", "гостя", "гостей")}`;
}

/** Оставляет только цифры номера после +7 (до 10 цифр). */
export function phoneDigits(input: string): string {
  let d = input.replace(/\D/g, "");
  // Код страны: «+7…» или «8…».
  if (d.startsWith("7") || d.startsWith("8")) d = d.slice(1);
  // Поле уже начинается с «+7 (», а клиент по привычке набирает или вставляет номер с 8 / +7:
  // «+7 (8999…» → 999…, «+7 (+7 999…» → 999…. Срезаем вторую 8/7 только когда цифр больше 10 —
  // иначе ломаются настоящие коды на 8 (812 Петербург, 843, 8-800) и 7xx (Казахстан).
  if (d.length > 10 && (d.startsWith("8") || d.startsWith("7"))) d = d.slice(1);
  return d.slice(0, 10);
}

/** Маска «+7 (999) 123-45-67». */
export function formatPhone(input: string): string {
  const d = phoneDigits(input);
  if (!d) return "";
  let out = "+7 (" + d.slice(0, 3);
  // Скобку закрываем только когда пошли следующие цифры — иначе Backspace «застревает» на «)».
  if (d.length > 3) out += ") " + d.slice(3, 6);
  if (d.length > 6) out += "-" + d.slice(6, 8);
  if (d.length > 8) out += "-" + d.slice(8, 10);
  return out;
}

export function normalizeHandle(contact: string): string {
  return contact.trim().replace(/^@/, "").replace(/^https?:\/\/(t\.me|instagram\.com)\//, "").replace(/\/$/, "");
}
