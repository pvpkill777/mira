/**
 * Адаптивные картинки без next/image: для Unsplash подставляем ширину в параметр `w`,
 * чтобы телефон не качал кадр шириной 900–1600 px ради карточки в 170 px.
 * Для своих загрузок (/api/media/…) возвращаем исходный адрес — ресайза на сервере нет.
 */
export function responsiveImage(url: string, widths: number[]): { src: string; srcSet?: string } {
  if (!url || !url.startsWith("https://images.unsplash.com/")) return { src: url };
  try {
    const at = (w: number) => {
      const u = new URL(url);
      u.searchParams.set("w", String(w));
      if (!u.searchParams.has("auto")) u.searchParams.set("auto", "format");
      if (!u.searchParams.has("fit")) u.searchParams.set("fit", "crop");
      if (!u.searchParams.has("q")) u.searchParams.set("q", "75");
      return u.toString();
    };
    const sorted = [...widths].sort((a, b) => a - b);
    return { src: at(sorted[Math.min(1, sorted.length - 1)]), srcSet: sorted.map((w) => `${at(w)} ${w}w`).join(", ") };
  } catch {
    return { src: url };
  }
}
