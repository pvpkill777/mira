export const MONTHS = [
  "январь", "февраль", "март", "апрель", "май", "июнь",
  "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь",
];
export const MONTHS_GEN = [
  "января", "февраля", "марта", "апреля", "мая", "июня",
  "июля", "августа", "сентября", "октября", "ноября", "декабря",
];
export const WEEKDAYS_SHORT = ["пн", "вт", "ср", "чт", "пт", "сб", "вс"];
export const WEEKDAYS_FULL = ["воскресенье", "понедельник", "вторник", "среда", "четверг", "пятница", "суббота"];

const pad = (n: number) => n.toString().padStart(2, "0");

export function toKey(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function fromKey(key: string): Date {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(y, m - 1, d);
}

export function addDays(d: Date, n: number): Date {
  const r = new Date(d);
  r.setDate(r.getDate() + n);
  return r;
}

/** Часовой пояс кондитерской. Все «сегодня», интервалы и срочность считаются по нему. */
export const BAKERY_TZ = "Europe/Moscow";

let tzFormatter: Intl.DateTimeFormat | null = null;

/**
 * Текущее время кондитерской — московское, независимо от часового пояса сервера и телефона клиента.
 * Возвращает Date, у которого «местные» поля (год, месяц, день, часы) равны московским — так же,
 * как даты из fromKey(): их можно сравнивать между собой. Без этого сервер в UTC и клиент в Москве
 * по-разному считали доступные интервалы, и React ругался на расхождение разметки (#418).
 */
export function bakeryNow(): Date {
  tzFormatter ??= new Intl.DateTimeFormat("en-GB", {
    timeZone: BAKERY_TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  });
  const parts = tzFormatter.formatToParts(new Date());
  const get = (type: Intl.DateTimeFormatPartTypes) => Number(parts.find((p) => p.type === type)?.value ?? 0);
  return new Date(get("year"), get("month") - 1, get("day"), get("hour"), get("minute"), get("second"));
}

export function todayKey(): string {
  return toKey(bakeryNow());
}

/** Строгая проверка «YYYY-MM-DD»: отсекает и несуществующие даты вроде 2026-02-30 или 2026-13-40. */
export function isValidKey(key: unknown): key is string {
  return typeof key === "string" && /^\d{4}-\d{2}-\d{2}$/.test(key) && toKey(fromKey(key)) === key;
}

/** «19 ноября, среда» */
export function humanDate(key: string, withWeekday = true): string {
  const d = fromKey(key);
  const base = `${d.getDate()} ${MONTHS_GEN[d.getMonth()]}`;
  return withWeekday ? `${base}, ${WEEKDAYS_FULL[d.getDay()]}` : base;
}

/** Начало временного интервала «10:00–12:00» как Date в указанный день. */
export function slotStart(dateKey: string, slot: string): Date {
  const m = slot.match(/(\d{1,2}):(\d{2})/);
  const d = fromKey(dateKey);
  if (m) d.setHours(Number(m[1]), Number(m[2]), 0, 0);
  return d;
}

/** Значения по умолчанию; действующие правила записи берутся из настроек кабинета (minLeadHours, urgentHours). */
export const DEFAULT_MIN_LEAD_HOURS = 4;
export const DEFAULT_URGENT_HOURS = 24;

export function hoursUntil(dateKey: string, slot: string, now = bakeryNow()): number {
  return (slotStart(dateKey, slot).getTime() - now.getTime()) / 36e5;
}

/** Интервал ещё можно заказать: до его начала не меньше minLeadHours часов (из настроек). */
export function isSlotAvailable(dateKey: string, slot: string, minLeadHours: number, now = bakeryNow()): boolean {
  return hoursUntil(dateKey, slot, now) >= minLeadHours;
}

/** Срочный — если до начала интервала меньше urgentHours часов (из настроек; 0 — срочных заказов не бывает). */
export function isUrgentSlot(dateKey: string, slot: string, urgentHours: number, now = bakeryNow()): boolean {
  return hoursUntil(dateKey, slot, now) < urgentHours;
}

/** «24 часов» → «суток», «48» → «2 суток», иначе «N часов» — для подсказок клиенту. */
export function hoursLabel(h: number): string {
  if (h > 0 && h % 24 === 0) return h === 24 ? "суток" : `${h / 24} суток`;
  const n = h % 100;
  const word = n >= 11 && n <= 14 ? "часов" : h % 10 === 1 ? "часа" : "часов";
  return `${h} ${word}`;
}

export function relativeDayLabel(key: string): string | null {
  const now = bakeryNow();
  if (key === toKey(now)) return "Сегодня";
  if (key === toKey(addDays(now, 1))) return "Завтра";
  if (key === toKey(addDays(now, 2))) return "Послезавтра";
  return null;
}
