import "server-only";
import { randomUUID } from "node:crypto";
import { access, mkdir, readdir, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import sharp from "sharp";

export const UPLOAD_DIR = path.join(process.cwd(), "uploads");
export const MEDIA_URL_RE = /^\/api\/media\/([a-f0-9-]{36}\.(?:jpg|png|webp|avif))$/;

export class UploadError extends Error {
  constructor(
    message: string,
    public status = 400,
  ) {
    super(message);
  }
}

/**
 * Проверяет, что файл — настоящее изображение, поворачивает по EXIF, уменьшает
 * и перекодирует в JPEG. Перекодирование удаляет все метаданные (в том числе геолокацию).
 */
export async function saveImage(file: File, opts: { maxBytes: number; maxSide: number }): Promise<string> {
  if (file.size === 0) throw new UploadError("Файл пустой — выберите фото ещё раз.");
  if (file.size > opts.maxBytes) {
    throw new UploadError(`Фото больше ${Math.round(opts.maxBytes / 1024 / 1024)} МБ — уменьшите его и загрузите снова.`, 413);
  }
  const input = Buffer.from(await file.arrayBuffer());
  let output: Buffer;
  try {
    // Только растровые форматы фото: SVG/PDF и прочее sharp тоже умеет читать, но они нам не нужны.
    const meta = await sharp(input, { limitInputPixels: 60_000_000 }).metadata();
    if (!meta.format || !["jpeg", "png", "webp", "heif", "avif", "gif", "tiff"].includes(meta.format)) throw new Error("format");
    output = await sharp(input, { limitInputPixels: 60_000_000 })
      .rotate()
      .resize({ width: opts.maxSide, height: opts.maxSide, fit: "inside", withoutEnlargement: true })
      .jpeg({ quality: 84, mozjpeg: true })
      .toBuffer();
  } catch {
    throw new UploadError("Не получилось прочитать фото. Подойдут JPG, PNG или WebP.", 415);
  }
  await mkdir(UPLOAD_DIR, { recursive: true });
  const name = `${randomUUID()}.jpg`;
  await writeFile(path.join(UPLOAD_DIR, name), output, { flag: "wx" });
  bumpUsage(output.length);
  return `/api/media/${name}`;
}

/**
 * Общий объём папки uploads (кешируется на минуту, чтобы не обходить диск на каждый запрос).
 * Лимит — UPLOADS_MAX_MB (по умолчанию 2048 МБ).
 */
let usageCache: { bytes: number; at: number } | null = null;
export async function uploadsUsageBytes(): Promise<number> {
  if (usageCache && Date.now() - usageCache.at < 60_000) return usageCache.bytes;
  let bytes = 0;
  try {
    const names = await readdir(UPLOAD_DIR);
    for (const n of names) {
      try {
        bytes += (await stat(path.join(UPLOAD_DIR, n))).size;
      } catch {
        /* файл удалили между readdir и stat */
      }
    }
  } catch {
    /* папки ещё нет */
  }
  usageCache = { bytes, at: Date.now() };
  return bytes;
}
export function uploadsLimitBytes(): number {
  const mb = Number(process.env.UPLOADS_MAX_MB);
  return (Number.isFinite(mb) && mb > 0 ? mb : 2048) * 1024 * 1024;
}
function bumpUsage(n: number) {
  if (usageCache) usageCache.bytes += n;
}

/** Оставляет только корректные ссылки на реально существующие загруженные файлы. */
export async function existingMediaUrls(urls: unknown, max: number): Promise<string[]> {
  if (!Array.isArray(urls)) return [];
  const out: string[] = [];
  for (const u of urls) {
    if (typeof u !== "string" || out.includes(u)) continue;
    const m = u.match(MEDIA_URL_RE);
    if (!m) continue;
    try {
      await access(path.join(UPLOAD_DIR, m[1]));
      out.push(u);
    } catch {
      /* файла нет — пропускаем */
    }
    if (out.length >= max) break;
  }
  return out;
}
