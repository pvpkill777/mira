import "server-only";
import { prisma } from "@/lib/prisma";
import { addDays, bakeryNow, toKey } from "@/lib/dates";
import { getCapacity, type DayCapacity } from "./availability";
import { getSettings } from "./catalog";

export type AdminOrder = {
  id: string;
  number: number;
  createdAt: string;
  status: string;
  date: string;
  timeSlot: string;
  delivery: boolean;
  address: string;
  customerName: string;
  phone: string;
  contact: string;
  inscription: string;
  wishes: string;
  designPhotos: string[];
  sizeName: string;
  weightGrams: number;
  fillingName: string;
  decor: { name: string; price: number }[];
  urgent: boolean;
  total: number;
  prepayment: number;
  deliveryFee: number;
  urgentFee: number;
};

export type BakePlanDay = {
  date: string;
  orders: {
    number: number;
    fillingName: string;
    weightGrams: number;
    sizeName: string;
    timeSlot: string;
    decor: string[];
    inscription: string;
    delivery: boolean;
    confirmed: boolean;
  }[];
};

export type AdminStats = {
  weekRevenue: number;
  weekExpected: number;
  monthRevenue: number;
  monthExpected: number;
  weekOrders: number;
  monthOrders: number;
  avgCheck: number;
  bakePlan: BakePlanDay[];
  fillingTotals: { name: string; grams: number; count: number }[];
  decorTotals: { name: string; count: number }[];
};

export async function getAdminData() {
  const now = bakeryNow();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  // Календарь кабинета покрывает весь горизонт записи (до конца последнего месяца), а не фиксированные 125 дней.
  const settingsForRange = await getSettings();
  const horizonEnd = addDays(now, settingsForRange.bookingHorizonDays);
  const lastMonthEnd = new Date(horizonEnd.getFullYear(), horizonEnd.getMonth() + 1, 0);
  const calendarDays = Math.max(125, Math.ceil((lastMonthEnd.getTime() - monthStart.getTime()) / 864e5) + 1);

  const [settings, ordersDesc, sizes, fillings, decor, gallery, capacity, galleryCategories, content, demos] = await Promise.all([
    getSettings(),
    // Самые поздние по дате 1000 заказов: новые и будущие видны всегда, даже когда заказов станет много.
    prisma.order.findMany({ orderBy: [{ date: "desc" }, { timeSlot: "desc" }], take: 1000 }),
    prisma.size.findMany({ orderBy: { sortOrder: "asc" } }),
    prisma.filling.findMany({ orderBy: { sortOrder: "asc" } }),
    prisma.decor.findMany({ orderBy: { sortOrder: "asc" } }),
    prisma.galleryItem.findMany({ orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }] }),
    getCapacity(toKey(monthStart), calendarDays),
    prisma.galleryCategory.findMany({ orderBy: { sortOrder: "asc" } }),
    prisma.contentItem.findMany({ orderBy: [{ kind: "asc" }, { sortOrder: "asc" }] }),
    prisma.demo.findMany({ orderBy: { createdAt: "desc" } }),
  ]);
  const ordersRaw = ordersDesc.reverse();

  const orders: AdminOrder[] = ordersRaw.map((o) => ({
    id: o.id,
    number: o.number,
    createdAt: o.createdAt.toISOString(),
    status: o.status,
    date: o.date,
    timeSlot: o.timeSlot,
    delivery: o.delivery,
    address: o.address,
    customerName: o.customerName,
    phone: o.phone,
    contact: o.contact,
    inscription: o.inscription,
    wishes: o.wishes,
    designPhotos: o.designPhotos.split(",").filter(Boolean),
    sizeName: o.sizeName,
    weightGrams: o.weightGrams,
    fillingName: o.fillingName,
    decor: safeJson(o.decorJson),
    urgent: o.urgent,
    total: o.total,
    prepayment: o.prepayment,
    deliveryFee: o.deliveryFee,
    urgentFee: o.urgentFee,
  }));

  // Хеш PIN в браузер не отдаём — кабинету достаточно знать, задан ли PIN из кабинета.
  const { adminPinHash, ...safeSettings } = settings;

  return {
    settings: { ...safeSettings, pinFromCabinet: Boolean(adminPinHash) },
    orders,
    sizes,
    fillings,
    decor,
    gallery: gallery.map((g) => ({ ...g, createdAt: g.createdAt.toISOString() })),
    galleryCategories,
    content,
    demos: demos.map((d) => ({ ...d, createdAt: d.createdAt.toISOString(), lastViewedAt: d.lastViewedAt?.toISOString() ?? null })),
    capacity,
    stats: computeStats(orders, now),
  };
}

function safeJson(s: string): { name: string; price: number }[] {
  try {
    const v = JSON.parse(s);
    return Array.isArray(v) ? v : [];
  } catch {
    return [];
  }
}

function computeStats(orders: AdminOrder[], now: Date): AdminStats {
  const weekday = (now.getDay() + 6) % 7;
  const weekStart = toKey(addDays(now, -weekday));
  const weekEnd = toKey(addDays(now, 6 - weekday));
  const monthStart = toKey(new Date(now.getFullYear(), now.getMonth(), 1));
  const monthEnd = toKey(new Date(now.getFullYear(), now.getMonth() + 1, 0));

  const paid = (o: AdminOrder) => o.status === "CONFIRMED" || o.status === "DONE";
  const inRange = (o: AdminOrder, a: string, b: string) => o.date >= a && o.date <= b;
  const sum = (list: AdminOrder[]) => list.reduce((s, o) => s + o.total, 0);

  const week = orders.filter((o) => inRange(o, weekStart, weekEnd));
  const month = orders.filter((o) => inRange(o, monthStart, monthEnd));
  const monthPaid = month.filter(paid);

  const today = toKey(now);
  const planKeys = [0, 1, 2].map((i) => toKey(addDays(now, i)));
  const active = orders.filter((o) => (o.status === "NEW" || o.status === "CONFIRMED") && planKeys.includes(o.date));

  const bakePlan: BakePlanDay[] = planKeys.map((date) => ({
    date,
    orders: active
      .filter((o) => o.date === date)
      .map((o) => ({
        number: o.number,
        fillingName: o.fillingName,
        weightGrams: o.weightGrams,
        sizeName: o.sizeName,
        timeSlot: o.timeSlot,
        decor: o.decor.map((d) => d.name),
        inscription: o.inscription,
        delivery: o.delivery,
        confirmed: o.status === "CONFIRMED",
      })),
  }));

  const fMap = new Map<string, { grams: number; count: number }>();
  const dMap = new Map<string, number>();
  for (const o of active) {
    const cur = fMap.get(o.fillingName) ?? { grams: 0, count: 0 };
    fMap.set(o.fillingName, { grams: cur.grams + o.weightGrams, count: cur.count + 1 });
    for (const d of o.decor) dMap.set(d.name, (dMap.get(d.name) ?? 0) + 1);
  }

  void today;
  return {
    weekRevenue: sum(week.filter(paid)),
    weekExpected: sum(week.filter((o) => o.status === "NEW")),
    monthRevenue: sum(monthPaid),
    monthExpected: sum(month.filter((o) => o.status === "NEW")),
    weekOrders: week.filter((o) => o.status !== "CANCELLED").length,
    monthOrders: month.filter((o) => o.status !== "CANCELLED").length,
    avgCheck: monthPaid.length ? Math.round(sum(monthPaid) / monthPaid.length) : 0,
    bakePlan,
    fillingTotals: [...fMap.entries()].map(([name, v]) => ({ name, ...v })).sort((a, b) => b.grams - a.grams),
    decorTotals: [...dMap.entries()].map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count),
  };
}

export type AdminData = Awaited<ReturnType<typeof getAdminData>>;
export type { DayCapacity };
