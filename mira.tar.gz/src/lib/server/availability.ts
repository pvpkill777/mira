import "server-only";
import { prisma } from "@/lib/prisma";
import { addDays, bakeryNow, fromKey, toKey } from "@/lib/dates";
import type { Availability, DayInfo } from "@/lib/types";
import { getSettings, splitList } from "./catalog";

export const ACTIVE_STATUSES = ["NEW", "CONFIRMED"];

export const slotKeyOf = (date: string, timeSlot: string) => `${date}|${timeSlot}`;

export type DayCapacity = {
  date: string;
  limit: number;
  count: number;
  closed: boolean;
  weekdayOff: boolean;
  hasOverride: boolean;
  note: string;
  /** Интервалы, уже занятые активными заказами */
  takenSlots: string[];
  /** Сколько всего интервалов выдачи в дне */
  slotsTotal: number;
};

/** Сырые данные о загрузке по дням диапазона (для кабинета и публичного календаря). */
export async function getCapacity(fromKeyStr: string, days: number): Promise<DayCapacity[]> {
  const settings = await getSettings();
  const start = fromKey(fromKeyStr);
  const endKey = toKey(addDays(start, days - 1));
  const closedWeekdays = splitList(settings.closedWeekdays).map(Number);
  const slots = splitList(settings.timeSlots);

  const [overrides, active] = await Promise.all([
    prisma.dayOverride.findMany({ where: { date: { gte: fromKeyStr, lte: endKey } } }),
    prisma.order.findMany({
      where: { date: { gte: fromKeyStr, lte: endKey }, status: { in: ACTIVE_STATUSES } },
      select: { date: true, timeSlot: true },
    }),
  ]);
  const ov = new Map(overrides.map((o) => [o.date, o]));
  const cnt = new Map<string, number>();
  const taken = new Map<string, Set<string>>();
  for (const o of active) {
    cnt.set(o.date, (cnt.get(o.date) ?? 0) + 1);
    if (!taken.has(o.date)) taken.set(o.date, new Set());
    taken.get(o.date)!.add(o.timeSlot);
  }

  const result: DayCapacity[] = [];
  for (let i = 0; i < days; i++) {
    const d = addDays(start, i);
    const key = toKey(d);
    const o = ov.get(key);
    // Выходной по дню недели можно «открыть», задав для даты свой лимит.
    const weekdayOff = closedWeekdays.includes(d.getDay()) && !(o && !o.closed && o.limit != null);
    result.push({
      date: key,
      limit: o?.limit ?? settings.defaultDailyLimit,
      count: cnt.get(key) ?? 0,
      closed: o?.closed ?? false,
      weekdayOff,
      hasOverride: Boolean(o),
      note: o?.note ?? "",
      takenSlots: [...(taken.get(key) ?? [])].filter((s) => slots.includes(s)),
      slotsTotal: slots.length,
    });
  }
  return result;
}

export function dayInfoFromCapacity(c: DayCapacity, today: string, horizonEnd: string): DayInfo {
  const takenSlots = c.takenSlots;
  if (c.date < today || c.date > horizonEnd) return { status: "past", left: 0, takenSlots };
  if (c.closed) return { status: "closed", left: 0, takenSlots };
  if (c.weekdayOff) return { status: "off", left: 0, takenSlots };
  // Свободно столько, сколько позволяет и дневной лимит, и число незанятых интервалов.
  const left = Math.max(0, Math.min(c.limit - c.count, c.slotsTotal - takenSlots.length));
  if (left === 0) return { status: "full", left: 0, takenSlots };
  if (left === 1) return { status: "few", left, takenSlots };
  return { status: "free", left, takenSlots };
}

/** Публичная доступность: от начала текущего месяца до горизонта записи. */
export async function getAvailability(): Promise<Availability> {
  const settings = await getSettings();
  const now = bakeryNow();
  const today = toKey(now);
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const horizonEnd = toKey(addDays(now, settings.bookingHorizonDays));
  const days = Math.ceil((fromKey(horizonEnd).getTime() - monthStart.getTime()) / 864e5) + 1;
  const cap = await getCapacity(toKey(monthStart), days);
  const out: Availability = {};
  for (const c of cap) out[c.date] = dayInfoFromCapacity(c, today, horizonEnd);
  return out;
}
