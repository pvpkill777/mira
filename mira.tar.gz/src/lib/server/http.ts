import "server-only";
import { NextResponse } from "next/server";

/**
 * IP клиента. За обратным прокси (nginx, Caddy) первый элемент X-Forwarded-For
 * присылает сам клиент — ему верить нельзя. Берём X-Real-IP (его ставит прокси)
 * или последний элемент X-Forwarded-For (его дописывает ближайший к нам прокси).
 */
export function clientIp(req: Request): string {
  const real = req.headers.get("x-real-ip")?.trim();
  if (real) return real.slice(0, 64);
  const xff = req.headers.get("x-forwarded-for");
  if (xff) {
    const parts = xff.split(",").map((s) => s.trim()).filter(Boolean);
    if (parts.length) return parts[parts.length - 1].slice(0, 64);
  }
  return "local";
}

type Bucket = { n: number; until: number };

/**
 * Простой счётчик «не больше `max` событий за `windowMs`» в памяти процесса.
 * Подходит для одного экземпляра приложения (наш случай); при нескольких
 * экземплярах лимиты нужно переносить в общее хранилище.
 */
export function createLimiter(max: number, windowMs: number, maxKeys = 10_000) {
  const map = new Map<string, Bucket>();
  function sweep(now: number) {
    if (map.size < maxKeys) return;
    for (const [k, v] of map) if (v.until < now) map.delete(k);
    // Если всё ещё переполнено (атака с множества адресов) — сбрасываем самые старые.
    if (map.size >= maxKeys) {
      let i = 0;
      const drop = map.size - Math.floor(maxKeys / 2);
      for (const k of map.keys()) {
        if (i++ >= drop) break;
        map.delete(k);
      }
    }
  }
  return {
    /** Засчитывает событие и возвращает true, если лимит превышен. */
    hit(key: string): boolean {
      const now = Date.now();
      sweep(now);
      const rec = map.get(key);
      if (!rec || rec.until < now) {
        map.set(key, { n: 1, until: now + windowMs });
        return 1 > max;
      }
      rec.n += 1;
      return rec.n > max;
    },
    /** Проверяет лимит, не засчитывая событие. */
    blocked(key: string): boolean {
      const rec = map.get(key);
      return Boolean(rec && rec.until >= Date.now() && rec.n >= max);
    },
    reset(key: string) {
      map.delete(key);
    },
  };
}

export class HttpError extends Error {
  constructor(
    message: string,
    public status = 400,
  ) {
    super(message);
  }
}

/** Читает JSON-тело не больше `maxBytes`; объект верхнего уровня обязателен. */
export async function readJson(req: Request, maxBytes = 32 * 1024): Promise<Record<string, unknown>> {
  const len = Number(req.headers.get("content-length") ?? 0);
  if (len > maxBytes) throw new HttpError("Слишком большой запрос.", 413);
  let text: string;
  try {
    text = await req.text();
  } catch {
    throw new HttpError("Не удалось прочитать запрос. Обновите страницу и попробуйте ещё раз.", 400);
  }
  if (Buffer.byteLength(text) > maxBytes) throw new HttpError("Слишком большой запрос.", 413);
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    throw new HttpError("Не удалось прочитать запрос. Обновите страницу и попробуйте ещё раз.", 400);
  }
  if (!data || typeof data !== "object" || Array.isArray(data)) {
    throw new HttpError("Не удалось прочитать запрос. Обновите страницу и попробуйте ещё раз.", 400);
  }
  return data as Record<string, unknown>;
}

/** Ответ на непредвиденную ошибку: подробности — только в лог сервера. */
export function serverError(e: unknown, where: string): NextResponse {
  if (e instanceof HttpError) return NextResponse.json({ error: e.message }, { status: e.status });
  console.error(`[${where}]`, e);
  return NextResponse.json(
    { error: "Что-то пошло не так на нашей стороне. Попробуйте ещё раз через минуту." },
    { status: 500 },
  );
}

/** Убирает управляющие символы (кроме перевода строки при `multiline`), обрезает по длине. */
export function cleanText(v: unknown, max: number, multiline = false): string {
  if (typeof v !== "string") return "";
  const re = multiline ? /[\u0000-\u0009\u000B-\u001F\u007F​-‏‪-‮⁦-⁩]/g : /[\u0000-\u001F\u007F​-‏‪-‮⁦-⁩]/g;
  // Режем по символам, а не по UTF-16: иначе эмодзи на границе разрезается пополам
  // и одинокая половинка суррогатной пары роняла запись в базу (500).
  const clean = v
    .replace(/\r\n?/g, "\n")
    .replace(re, multiline ? "" : " ")
    .replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, "")
    .trim();
  return Array.from(clean).slice(0, max).join("");
}

/** Строгая проверка ключа даты YYYY-MM-DD без «перекатывания» (2026-02-31 — невалидно). */
export function isStrictDateKey(v: unknown): v is string {
  if (typeof v !== "string") return false;
  const m = v.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return false;
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const dt = new Date(y, mo - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === mo - 1 && dt.getDate() === d;
}
