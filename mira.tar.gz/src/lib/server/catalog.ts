import "server-only";
import { prisma } from "@/lib/prisma";
import type { Catalog, GalleryCategory, PublicSettings } from "@/lib/types";
import type { Settings } from "@prisma/client";

export const splitList = (s: string) =>
  s
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean);

export async function getSettings(): Promise<Settings> {
  const s = await prisma.settings.findUnique({ where: { id: 1 } });
  if (!s) throw new Error("Настройки не найдены. Выполните `npm run setup`, чтобы наполнить базу.");
  return s;
}

export function toPublicSettings(s: Settings): PublicSettings {
  return {
    brandName: s.brandName,
    ownerName: s.ownerName,
    tagline: s.tagline,
    city: s.city,
    avatarUrl: s.avatarUrl,
    heroImageUrl: s.heroImageUrl,
    telegram: s.telegram,
    whatsapp: s.whatsapp,
    instagram: s.instagram,
    pickupAddress: s.pickupAddress,
    urgentSurchargePct: s.urgentSurchargePct,
    prepaymentPct: s.prepaymentPct,
    deliveryFee: s.deliveryFee,
    timeSlots: splitList(s.timeSlots),
    customMinGrams: s.customMinGrams,
    customMaxGrams: s.customMaxGrams,
    bookingHorizonDays: s.bookingHorizonDays,
    minLeadHours: s.minLeadHours,
    urgentHours: s.urgentHours,
    pickupEnabled: s.pickupEnabled,
    deliveryEnabled: s.deliveryEnabled,
    heroTitle: s.heroTitle,
    heroSubtitle: s.heroSubtitle,
    aboutTitle: s.aboutTitle,
    aboutQuote: s.aboutQuote,
    aboutText: s.aboutText,
    faqTitle: s.faqTitle,
    seoTitle: s.seoTitle,
    seoDescription: s.seoDescription,
  };
}

/** Публичный каталог — только активные позиции. */
export async function getCatalog(opts: { includeInactive?: boolean } = {}): Promise<Catalog> {
  const where = opts.includeInactive ? {} : { active: true };
  const [settings, sizes, fillings, decor, gallery, categories, content] = await Promise.all([
    getSettings(),
    prisma.size.findMany({ where, orderBy: { sortOrder: "asc" } }),
    prisma.filling.findMany({ where, orderBy: { sortOrder: "asc" } }),
    prisma.decor.findMany({ where, orderBy: { sortOrder: "asc" } }),
    prisma.galleryItem.findMany({ where, orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }] }),
    prisma.galleryCategory.findMany({ where, orderBy: { sortOrder: "asc" } }),
    prisma.contentItem.findMany({ where, orderBy: { sortOrder: "asc" } }),
  ]);
  const byKind = (kind: string) =>
    content.filter((c) => c.kind === kind).map((c) => ({ id: c.id, title: c.title, text: c.text, detail: c.detail }));
  return {
    settings: toPublicSettings(settings),
    galleryCategories: categories.map((c) => ({ slug: c.slug, label: c.label })),
    content: { faq: byKind("faq"), steps: byKind("step"), principles: byKind("principle"), reviews: byKind("review") },
    sizes: sizes.map((s) => ({
      id: s.id,
      name: s.name,
      weightGrams: s.weightGrams,
      guestsLabel: s.guestsLabel,
      fixedPrice: s.fixedPrice,
      adjustable: s.adjustable,
    })),
    fillings: fillings.map((f) => ({
      id: f.id,
      name: f.name,
      description: f.description,
      pricePerKg: f.pricePerKg,
      imageUrl: f.imageUrl,
      tags: splitList(f.tags),
    })),
    decor: decor.map((d) => ({ id: d.id, name: d.name, description: d.description, price: d.price })),
    gallery: gallery.map((g) => ({
      id: g.id,
      title: g.title,
      description: g.description,
      imageUrl: g.imageUrl,
      category: g.category as GalleryCategory,
      weightGrams: g.weightGrams,
      sizeId: g.sizeId,
      fillingId: g.fillingId,
      decorIds: splitList(g.decorIds),
    })),
  };
}
