import "server-only";
import type { Demo } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import type { Catalog } from "@/lib/types";
import { isAdmin } from "./auth";
import { getCatalog, splitList } from "./catalog";

const round = (v: number, step: number) => Math.max(step, Math.round(v / step) * step);

/** Каталог основного сайта, «переодетый» под конкретного кондитера. В базе ничего не меняется. */
export function applyDemo(base: Catalog, demo: Demo): Catalog {
  const k = demo.pricePct / 100;
  const photos = splitList(demo.photos);
  const defaultSize = base.sizes.find((s) => s.fixedPrice == null) ?? base.sizes[0];

  return {
    ...base,
    settings: {
      ...base.settings,
      brandName: demo.brandName,
      ownerName: demo.ownerName || base.settings.ownerName,
      city: demo.city || base.settings.city,
      // Адрес основного сайта чужому кондитеру не показываем.
      pickupAddress: "адрес пришлём после подтверждения заказа",
      telegram: demo.telegram,
      whatsapp: demo.whatsapp,
      instagram: demo.instagram,
      avatarUrl: "",
      heroImageUrl: photos[0] ?? base.settings.heroImageUrl,
      deliveryFee: base.settings.deliveryFee ? round(base.settings.deliveryFee * k, 50) : 0,
      seoTitle: "",
      seoDescription: "",
    },
    sizes: k === 1 ? base.sizes : base.sizes.map((s) => ({ ...s, fixedPrice: s.fixedPrice == null ? null : round(s.fixedPrice * k, 50) })),
    fillings: k === 1 ? base.fillings : base.fillings.map((f) => ({ ...f, pricePerKg: round(f.pricePerKg * k, 50) })),
    decor: k === 1 ? base.decor : base.decor.map((d) => ({ ...d, price: d.price ? round(d.price * k, 10) : 0 })),
    // Свои фото — вместо работ шаблона, без категорий: названия шаблона к чужим тортам не подходят.
    ...(photos.length > 0 && {
      galleryCategories: [],
      gallery: photos.map((url, i) => ({
        id: `demo-${i}`,
        title: `Работа №${i + 1}`,
        description: "",
        imageUrl: url,
        category: "",
        weightGrams: defaultSize?.weightGrams ?? 1500,
        sizeId: defaultSize?.id ?? null,
        fillingId: base.fillings.length ? base.fillings[i % base.fillings.length].id : null,
        decorIds: [],
      })),
    }),
  };
}

export async function getDemo(slug: string): Promise<Demo | null> {
  if (!/^[a-z0-9-]{1,60}$/.test(slug)) return null;
  return prisma.demo.findUnique({ where: { slug } });
}

/** Демо-каталог + отметка о просмотре (свои просмотры из кабинета не считаем). */
export async function getDemoCatalog(demo: Demo, countView: boolean): Promise<Catalog> {
  if (countView && !(await isAdmin())) {
    await prisma.demo
      .update({ where: { id: demo.id }, data: { viewCount: { increment: 1 }, lastViewedAt: new Date() } })
      .catch(() => {});
  }
  return applyDemo(await getCatalog(), demo);
}
