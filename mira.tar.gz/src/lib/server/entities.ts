import "server-only";
import { prisma } from "@/lib/prisma";

type FieldType = "string" | "int" | "intNullable" | "bool" | "stringNullable" | "category" | "kind" | "slug";

const CONTENT_KINDS = ["faq", "step", "principle", "review"];
type Schema = Record<
  string,
  { type: FieldType; required?: boolean; max?: number; min?: number; minError?: string; maxValue?: number; maxError?: string; label?: string }
>;


/** Ссылка на картинку: загруженный файл /api/media/…, локальный путь или https://. Никаких javascript:/data:. */
export function isSafeImageUrl(v: string): boolean {
  if (/^\/api\/media\/[a-f0-9-]{36}\.(jpg|png|webp|avif)$/.test(v)) return true;
  if (/^\/(?!\/)[A-Za-z0-9._~\-/]+$/.test(v)) return true;
  try {
    const u = new URL(v);
    return u.protocol === "https:" && !u.username && !u.password;
  } catch {
    return false;
  }
}

export const ENTITY_SCHEMAS: Record<string, Schema> = {
  fillings: {
    name: { type: "string", required: true, max: 80 },
    description: { type: "string", max: 600 },
    pricePerKg: { type: "int", required: true, min: 100, minError: "Цена за 1 кг — от 100 ₽", label: "Цена за 1 кг" },
    imageUrl: { type: "string", required: true, max: 500, label: "Фото" },
    tags: { type: "string", max: 120 },
    active: { type: "bool" },
    sortOrder: { type: "int" },
  },
  decor: {
    name: { type: "string", required: true, max: 80 },
    description: { type: "string", max: 200 },
    price: { type: "int", required: true, label: "Цена" },
    active: { type: "bool" },
    sortOrder: { type: "int" },
  },
  sizes: {
    name: { type: "string", required: true, max: 60 },
    weightGrams: { type: "int", required: true, min: 100, minError: "Вес торта — от 100 г", maxValue: 20_000, maxError: "Вес торта — не больше 20 кг", label: "Вес" },
    guestsLabel: { type: "string", max: 40 },
    fixedPrice: { type: "intNullable", min: 100, minError: "Фиксированная цена — от 100 ₽ (или оставьте поле пустым)" },
    adjustable: { type: "bool" },
    active: { type: "bool" },
    sortOrder: { type: "int" },
  },
  gallery: {
    title: { type: "string", required: true, max: 100 },
    description: { type: "string", max: 400 },
    imageUrl: { type: "string", required: true, max: 500 },
    category: { type: "category", required: true },
    weightGrams: { type: "int", required: true, min: 100, minError: "Вес на фото — от 100 г", maxValue: 20_000, maxError: "Вес на фото — не больше 20 кг", label: "Вес на фото" },
    sizeId: { type: "stringNullable" },
    fillingId: { type: "stringNullable" },
    decorIds: { type: "string", max: 400 },
    active: { type: "bool" },
    sortOrder: { type: "int" },
  },
  /** Категории галереи. slug можно не передавать — сервер придумает сам. */
  categories: {
    label: { type: "string", required: true, max: 40, label: "Название категории" },
    slug: { type: "slug" },
    active: { type: "bool" },
    sortOrder: { type: "int" },
  },
  /** Демо-версии сайта для продажи шаблона. slug сервер придумывает сам из названия. */
  demos: {
    brandName: { type: "string", required: true, max: 60, label: "Название" },
    ownerName: { type: "string", max: 40 },
    city: { type: "string", max: 40 },
    instagram: { type: "string", max: 120 },
    telegram: { type: "string", max: 120 },
    whatsapp: { type: "string", max: 40 },
    pricePct: { type: "int", min: 50, minError: "Уровень цен — от 50%", maxValue: 200, maxError: "Уровень цен — не больше 200%" },
    photos: { type: "string", max: 2000 },
  },
  /** Тексты сайта: FAQ, шаги, принципы, отзывы (поле kind). */
  content: {
    kind: { type: "kind", required: true },
    title: { type: "string", max: 200, label: "Заголовок" },
    text: { type: "string", max: 2000, label: "Текст" },
    detail: { type: "string", max: 200 },
    active: { type: "bool" },
    sortOrder: { type: "int" },
  },
};

/**
 * Проверки, которым нужна база (вызывать после parseEntity, до записи).
 * Возвращает текст ошибки или null.
 */
export async function validateEntityRefs(entity: string, data: Record<string, unknown>, isCreate: boolean): Promise<string | null> {
  if (entity === "gallery" && typeof data.category === "string") {
    const exists = await prisma.galleryCategory.findUnique({ where: { slug: data.category } });
    if (!exists) return "Такой категории нет — выберите категорию из списка";
  }
  if (entity === "gallery") {
    if (typeof data.sizeId === "string" && !(await prisma.size.findUnique({ where: { id: data.sizeId } }))) return "Такого размера нет";
    if (typeof data.fillingId === "string" && !(await prisma.filling.findUnique({ where: { id: data.fillingId } }))) return "Такой начинки нет";
    // Декор, который успели удалить, просто отбрасываем — без «битых» ссылок.
    if (typeof data.decorIds === "string" && data.decorIds) {
      const ids = data.decorIds.split(",").map((x) => x.trim()).filter(Boolean);
      const found = await prisma.decor.findMany({ where: { id: { in: ids } }, select: { id: true } });
      const ok = new Set(found.map((d) => d.id));
      data.decorIds = ids.filter((id) => ok.has(id)).join(",");
    }
  }
  if (entity === "categories" && isCreate && data.slug === undefined) {
    data.slug = `c${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
  }
  if (entity === "demos") {
    if (typeof data.instagram === "string") data.instagram = normalizeHandle(data.instagram, /instagram\.com\/([A-Za-z0-9._]+)/i, /^[A-Za-z0-9._]{1,30}$/);
    if (typeof data.telegram === "string") data.telegram = normalizeHandle(data.telegram, /t(?:elegram)?\.me\/([A-Za-z0-9_]+)/i, /^[A-Za-z0-9_]{3,32}$/);
    if (typeof data.whatsapp === "string") data.whatsapp = normalizeWhatsapp(data.whatsapp);
    if (data.instagram === null) return "Instagram: вставьте ник (например, oksana.cakes) или ссылку на профиль";
    if (data.telegram === null) return "Telegram: вставьте ник (например, oksana_cakes) или ссылку t.me/…";
    if (data.whatsapp === null) return "WhatsApp: нужен номер из 10 цифр после +7";
    if (typeof data.photos === "string") {
      data.photos = data.photos
        .split(",")
        .map((x) => x.trim())
        .filter((u) => /^\/api\/media\/[a-f0-9-]{36}\.(jpg|png|webp|avif)$/.test(u))
        .slice(0, MAX_DEMO_PHOTOS)
        .join(",");
    }
    if (isCreate) data.slug = await uniqueDemoSlug(String(data.brandName ?? ""));
  }
  return null;
}

export const MAX_DEMO_PHOTOS = 12;

/** «@oksana.cakes», «instagram.com/oksana.cakes/?igsh=…» → «oksana.cakes». Пусто — пусто, мусор — null. */
function normalizeHandle(raw: string, fromUrl: RegExp, valid: RegExp): string | null {
  const s = raw.trim();
  if (!s) return "";
  const handle = (s.match(fromUrl)?.[1] ?? s).replace(/^@/, "").replace(/\/+$/, "");
  return valid.test(handle) ? handle : null;
}

/** «+7 (999) 123-45-67», «89991234567» → «79991234567». */
function normalizeWhatsapp(raw: string): string | null {
  let d = raw.replace(/\D/g, "");
  if (!d) return "";
  if (d.length === 11 && (d[0] === "8" || d[0] === "7")) d = d.slice(1);
  return d.length === 10 ? `7${d}` : null;
}

const TRANSLIT: Record<string, string> = {
  а: "a", б: "b", в: "v", г: "g", д: "d", е: "e", ё: "e", ж: "zh", з: "z", и: "i", й: "y", к: "k", л: "l", м: "m", н: "n", о: "o",
  п: "p", р: "r", с: "s", т: "t", у: "u", ф: "f", х: "h", ц: "c", ч: "ch", ш: "sh", щ: "sch", ъ: "", ы: "y", ь: "", э: "e", ю: "yu", я: "ya",
};

/** «Торты от Оксаны» → «torty-ot-oksany» (при совпадении — «-2», «-3»…). */
async function uniqueDemoSlug(name: string): Promise<string> {
  const base =
    [...name.toLowerCase()]
      .map((ch) => TRANSLIT[ch] ?? ch)
      .join("")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 40)
      .replace(/-+$/, "") || "demo";
  for (let i = 1; i < 100; i++) {
    const slug = i === 1 ? base : `${base}-${i}`;
    if (!(await prisma.demo.findUnique({ where: { slug } }))) return slug;
  }
  return `${base}-${Date.now().toString(36)}`;
}

export function parseEntity(entity: string, input: Record<string, unknown>, partial: boolean) {
  const schema = ENTITY_SCHEMAS[entity];
  const data: Record<string, unknown> = {};
  for (const [key, f] of Object.entries(schema)) {
    if (!(key in input)) {
      if (!partial && f.required) return { error: `Заполните поле «${f.label ?? key}»` };
      // Необязательные текстовые поля при создании — пустые, а не отсутствующие (иначе Prisma падала с 500).
      if (!partial && f.type === "string") data[key] = "";
      continue;
    }
    const v = input[key];
    switch (f.type) {
      case "string": {
        const s = String(v ?? "").trim().slice(0, f.max ?? 500);
        if (f.required && !s) return { error: "Заполните обязательные поля" };
        if (key === "imageUrl" && s && !isSafeImageUrl(s)) return { error: "Ссылка на фото должна начинаться с https:// или быть загруженным файлом" };
        data[key] = s;
        break;
      }
      case "stringNullable":
        data[key] = v ? String(v).slice(0, 40) : null;
        break;
      case "int": {
        const n = Math.round(Number(v));
        if (!Number.isFinite(n) || n < 0) return { error: "Числа должны быть положительными" };
        // Prisma Int — 32 бита; огромные значения роняли запрос с 500.
        if (n > 10_000_000) return { error: "Слишком большое число" };
        // Цена 0 ₽/кг или вес 0 г ломали расчёт на сайте («торт от 0 ₽»).
        if (f.min != null && n < f.min) return { error: f.minError ?? `Минимальное значение — ${f.min}` };
        if (f.maxValue != null && n > f.maxValue) return { error: f.maxError ?? `Максимальное значение — ${f.maxValue}` };
        data[key] = n;
        break;
      }
      case "intNullable": {
        if (v === null || v === "" || v === undefined) data[key] = null;
        else {
          const n = Math.round(Number(v));
          if (!Number.isFinite(n) || n < 0) return { error: "Числа должны быть положительными" };
          if (n > 10_000_000) return { error: "Слишком большое число" };
          if (f.min != null && n < f.min) return { error: f.minError ?? `Минимальное значение — ${f.min}` };
          data[key] = n;
        }
        break;
      }
      case "bool":
        data[key] = Boolean(v);
        break;
      case "category":
      case "slug": {
        const s = String(v ?? "").trim();
        if (!/^[a-z0-9-]{1,40}$/.test(s)) return { error: "Неизвестная категория" };
        data[key] = s;
        break;
      }
      case "kind":
        if (!CONTENT_KINDS.includes(String(v))) return { error: "Неизвестный тип текста" };
        data[key] = String(v);
        break;
    }
  }
  return { data };
}

// Prisma-делегаты по имени сущности.
export function delegate(entity: string) {
  switch (entity) {
    case "fillings":
      return prisma.filling;
    case "decor":
      return prisma.decor;
    case "sizes":
      return prisma.size;
    case "gallery":
      return prisma.galleryItem;
    case "categories":
      return prisma.galleryCategory;
    case "content":
      return prisma.contentItem;
    case "demos":
      return prisma.demo;
    default:
      return null;
  }
}
