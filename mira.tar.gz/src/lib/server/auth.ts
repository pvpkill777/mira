import "server-only";
import { createHash, createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { createLimiter } from "./http";
import { prisma } from "@/lib/prisma";

export const ADMIN_COOKIE = "mira_admin";
/** Срок жизни сессии кабинета. */
export const SESSION_MAX_AGE_SEC = 60 * 60 * 24 * 30;

const PLACEHOLDER_SECRET = "replace-with-a-long-random-string";

/**
 * Ключ подписи сессии. В продакшене без настоящего ADMIN_SECRET (≥ 16 символов,
 * не значение из .env.example) вход в кабинет отключён — иначе куку можно подделать.
 */
function secret(): string | null {
  const s = process.env.ADMIN_SECRET;
  if (s && s.length >= 16 && s !== PLACEHOLDER_SECRET) return s;
  if (process.env.NODE_ENV === "production") return null;
  return s || "dev-secret";
}

type PinState = { hash: string; length: number; sessionsRevokedAt: number };

/** PIN, заданный в кабинете (хеш в базе), и отметка «выйти везде». База недоступна — действует только .env. */
async function pinState(): Promise<PinState> {
  try {
    const s = await prisma.settings.findUnique({
      where: { id: 1 },
      select: { adminPinHash: true, adminPinLength: true, sessionsRevokedAt: true },
    });
    return { hash: s?.adminPinHash ?? "", length: s?.adminPinLength ?? 0, sessionsRevokedAt: s?.sessionsRevokedAt ?? 0 };
  } catch {
    return { hash: "", length: 0, sessionsRevokedAt: 0 };
  }
}

/** Длина действующего PIN для экрана входа (число точек и автоотправка). Сам PIN в браузер не попадает. */
export async function activePinLength(): Promise<number> {
  const st = await pinState();
  if (st.hash && st.length >= 4 && st.length <= 12) return st.length;
  const pin = process.env.ADMIN_PIN ?? "";
  return /^\d{4,12}$/.test(pin) ? pin.length : 4;
}

export async function authConfigured(): Promise<boolean> {
  if (!secret()) return false;
  if (process.env.ADMIN_PIN) return true;
  return Boolean((await pinState()).hash);
}

/**
 * Отпечаток действующего PIN для подписи сессии. Для PIN из .env — как раньше (старые сессии
 * не слетают при обновлении сайта); для PIN из кабинета — хеш с солью, который меняется при каждой смене.
 */
function pinFingerprint(st: PinState): string | null {
  if (st.hash) return createHash("sha256").update(`db:${st.hash}`).digest("hex");
  const pin = process.env.ADMIN_PIN;
  return pin ? createHash("sha256").update(pin).digest("hex") : null;
}

function sign(issuedAt: number, st: PinState): string | null {
  const key = secret();
  const fp = pinFingerprint(st);
  if (!key || !fp) return null;
  // PIN входит в подпись: смена PIN (в .env или в кабинете) сразу завершает все старые сессии.
  return createHmac("sha256", key).update(`admin:v2:${issuedAt}:${fp}`).digest("hex");
}

/** Новая кука сессии: «время выдачи.подпись». */
export async function sessionToken(): Promise<string> {
  const issuedAt = Math.floor(Date.now() / 1000);
  return `${issuedAt}.${sign(issuedAt, await pinState()) ?? ""}`;
}

async function verifyToken(value: string): Promise<boolean> {
  const m = value.match(/^(\d{10})\.([a-f0-9]{64})$/);
  if (!m) return false;
  const issuedAt = Number(m[1]);
  const now = Math.floor(Date.now() / 1000);
  if (issuedAt > now + 60 || now - issuedAt > SESSION_MAX_AGE_SEC) return false;
  const st = await pinState();
  const expected = sign(issuedAt, st);
  if (!expected) return false;
  if (!timingSafeEqual(Buffer.from(m[2]), Buffer.from(expected))) return false;
  // «Выйти на всех устройствах»: сессии, выданные до этого момента, больше не действуют.
  // Точность — секунда: сессия, выданная в ту же секунду, что и «выйти везде», считается новой
  // (иначе вход сразу после «выйти везде» давал неработающую сессию).
  return issuedAt >= st.sessionsRevokedAt;
}

/** Завершает все сессии кабинета, включая текущую. */
export async function revokeAllSessions(): Promise<void> {
  await prisma.settings.update({ where: { id: 1 }, data: { sessionsRevokedAt: Math.floor(Date.now() / 1000) } });
}

const SCRYPT_KEYLEN = 32;

/** Хеш PIN для хранения в базе: «соль:хеш» (scrypt, соль 16 байт). */
export function hashPin(pin: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(pin, salt, SCRYPT_KEYLEN).toString("hex");
  return `${salt}:${hash}`;
}

function verifyPinHash(pin: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash || !/^[a-f0-9]+$/.test(hash) || hash.length !== SCRYPT_KEYLEN * 2) return false;
  const actual = scryptSync(pin.slice(0, 128), salt, SCRYPT_KEYLEN);
  return timingSafeEqual(actual, Buffer.from(hash, "hex"));
}

/**
 * Проверка PIN: сначала PIN, заданный в кабинете (если есть), иначе ADMIN_PIN из .env.
 * Сравнение за постоянное время, независимо от длины ввода.
 */
export async function checkPin(pin: string): Promise<boolean> {
  if (!secret()) return false;
  const st = await pinState();
  if (st.hash) return verifyPinHash(pin, st.hash);
  const expected = process.env.ADMIN_PIN;
  if (!expected) return false;
  const a = createHash("sha256").update(pin.slice(0, 128)).digest();
  const b = createHash("sha256").update(expected).digest();
  return timingSafeEqual(a, b);
}

/** Простые PIN, которые подбирают первыми: 1111, 1234, 4321… */
export function weakPin(pin: string): boolean {
  if (/^(\d)\1+$/.test(pin)) return true;
  const digits = pin.split("").map(Number);
  const step = digits[1] - digits[0];
  return Math.abs(step) === 1 && digits.every((d, i) => i === 0 || d - digits[i - 1] === step);
}
export async function isAdmin(): Promise<boolean> {
  const store = await cookies();
  const value = store.get(ADMIN_COOKIE)?.value;
  if (!value) return false;
  return await verifyToken(value);
}

/** Возвращает ответ 401, если не авторизован; иначе null. */
export async function guard(): Promise<NextResponse | null> {
  if (await isAdmin()) return null;
  return NextResponse.json({ error: "Нужно войти в кабинет" }, { status: 401 });
}

// Защита от перебора PIN: считаем только неудачные попытки.
// 6 ошибок за 15 минут с одного IP и 40 ошибок в час со всех адресов вместе
// (против перебора с множества IP). Владелица в это время остаётся в кабинете — её кука действует.
const perIp = createLimiter(6, 15 * 60_000);
const global = createLimiter(40, 60 * 60_000);
export function loginBlocked(ip: string): boolean {
  return perIp.blocked(ip) || global.blocked("all");
}
export function registerFailure(ip: string) {
  perIp.hit(ip);
  global.hit("all");
}
export function resetAttempts(ip: string) {
  perIp.reset(ip);
}
