/** Публичный адрес сайта для canonical, Open Graph, sitemap и JSON-LD. Задаётся в NEXT_PUBLIC_SITE_URL. */
export const SITE_URL = (() => {
  const raw = process.env.NEXT_PUBLIC_SITE_URL?.trim() || "http://localhost:3000";
  try {
    return new URL(raw).origin;
  } catch {
    return "http://localhost:3000";
  }
})();

// Запасные значения: настоящие название, заголовок и описание задаются в кабинете (Настройки → Бренд, Тексты сайта → SEO).
// Используются, если поле в кабинете пустое или база недоступна.
export const SITE_NAME = "Мира";
export const SITE_TITLE = "Мира — авторские торты на заказ";
export const SITE_DESCRIPTION =
  "Соберите торт за минуту: размер, начинка, декор и точная цена сразу. Свободные даты онлайн, заявка без переписки в директе.";
export const OG_IMAGE = { url: "/og.png", width: 1200, height: 630, alt: "Мира — авторские торты на заказ" } as const;
