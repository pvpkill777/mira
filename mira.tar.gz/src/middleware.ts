import { NextResponse, type NextRequest } from "next/server";

/**
 * 1) Страницы: строгий Content-Security-Policy с одноразовым nonce на каждый запрос.
 *    Next.js сам проставляет nonce своим скриптам (читает CSP из заголовков запроса),
 *    а 'strict-dynamic' разрешает только то, что эти скрипты подгружают. Внедрённый
 *    инлайн-скрипт без nonce не выполнится.
 * 2) API: защита от CSRF и слишком больших запросов.
 *    Мутирующие запросы (POST/PUT/PATCH/DELETE) принимаем только со своего сайта:
 *    Origin должен совпадать с хостом, а при отсутствии Origin браузер не должен
 *    помечать запрос как cross-site (Sec-Fetch-Site). Запросы без обоих заголовков
 *    (curl, серверные клиенты) пропускаем — у них нет «чужих» кук браузера.
 */
const isDev = process.env.NODE_ENV !== "production";

function contentSecurityPolicy(nonce: string): string {
  return [
    "default-src 'self'",
    `script-src 'self' 'nonce-${nonce}' 'strict-dynamic'${isDev ? " 'unsafe-eval'" : ""}`,
    // Framer Motion и next/font выставляют стили инлайн — без этого анимации не работают.
    "style-src 'self' 'unsafe-inline'",
    // Кондитер может указать фото с любого https-адреса (кабинет это разрешает) — картинки не исполняются.
    "img-src 'self' data: blob: https:",
    "font-src 'self' data:",
    // Service Worker догружает фото и шрифты через fetch().
    `connect-src 'self' https://images.unsplash.com https://fonts.gstatic.com${isDev ? " ws: wss:" : ""}`,
    "manifest-src 'self'",
    "worker-src 'self'",
    "frame-src 'none'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
    ...(isDev ? [] : ["upgrade-insecure-requests"]),
  ].join("; ");
}

const MAX_BODY: { prefix: string; bytes: number }[] = [
  { prefix: "/api/uploads/", bytes: 13 * 1024 * 1024 },
  { prefix: "/api/admin/upload", bytes: 16 * 1024 * 1024 },
  { prefix: "/api/", bytes: 64 * 1024 },
];

const json = (error: string, status: number) =>
  NextResponse.json({ error }, { status, headers: { "Cache-Control": "no-store" } });

function hostOf(url: string | undefined): string | null {
  if (!url) return null;
  try {
    return new URL(url).host;
  } catch {
    return null;
  }
}

function sameOrigin(req: NextRequest): boolean {
  const origin = req.headers.get("origin");
  if (origin) {
    if (origin === "null") return false;
    const originHost = hostOf(origin);
    if (!originHost) return false;
    // Прокси может передавать внутренний Host (127.0.0.1:3000), поэтому сверяем
    // и с X-Forwarded-Host, и с адресом сайта из окружения.
    const allowed = [
      req.headers.get("host"),
      req.headers.get("x-forwarded-host")?.split(",")[0]?.trim(),
      hostOf(process.env.SITE_URL),
      hostOf(process.env.NEXT_PUBLIC_SITE_URL),
    ].filter(Boolean);
    return allowed.includes(originHost);
  }
  const site = req.headers.get("sec-fetch-site");
  return !site || site === "same-origin" || site === "none";
}

function guardApi(req: NextRequest) {
  const method = req.method.toUpperCase();
  if (method === "GET" || method === "HEAD" || method === "OPTIONS") return NextResponse.next();

  if (!sameOrigin(req)) return json("Запрос отклонён. Обновите страницу и попробуйте ещё раз.", 403);

  const len = Number(req.headers.get("content-length") ?? 0);
  const limit = MAX_BODY.find((r) => req.nextUrl.pathname.startsWith(r.prefix))?.bytes ?? 64 * 1024;
  if (Number.isFinite(len) && len > limit) return json("Слишком большой запрос.", 413);

  return NextResponse.next();
}

export function middleware(req: NextRequest) {
  if (req.nextUrl.pathname.startsWith("/api/")) return guardApi(req);

  const nonce = btoa(crypto.randomUUID());
  const csp = contentSecurityPolicy(nonce);
  const requestHeaders = new Headers(req.headers);
  requestHeaders.set("x-nonce", nonce);
  requestHeaders.set("Content-Security-Policy", csp);

  const res = NextResponse.next({ request: { headers: requestHeaders } });
  res.headers.set("Content-Security-Policy", csp);
  return res;
}

export const config = {
  matcher: [
    "/api/:path*",
    {
      // Страницы — без статики, иконок и файлов из public (у них нет инлайн-скриптов Next).
      source: "/((?!api/|_next/static|_next/image|icons/|.*\\.(?:png|jpg|jpeg|webp|svg|ico|js|json|txt|xml|html|webmanifest)$).*)",
      missing: [
        { type: "header", key: "next-router-prefetch" },
        { type: "header", key: "purpose", value: "prefetch" },
      ],
    },
  ],
};
