import type { MetadataRoute } from "next";
import { SITE_URL } from "@/lib/site";

// Публичная страница одна — главная с конструктором. Кабинет и API в карту не попадают.
export default function sitemap(): MetadataRoute.Sitemap {
  return [{ url: `${SITE_URL}/`, changeFrequency: "weekly", priority: 1 }];
}
