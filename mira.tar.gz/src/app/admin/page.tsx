import type { Metadata } from "next";
import { activePinLength, isAdmin } from "@/lib/server/auth";
import { getAdminData } from "@/lib/server/admin-data";
import { AdminLogin } from "@/components/admin/AdminLogin";
import { AdminApp } from "@/components/admin/AdminApp";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  // « — Мира» добавляет шаблон title из корневого layout.
  title: "Кабинет кондитера",
  robots: { index: false, follow: false },
};

export default async function AdminPage() {
  if (!(await isAdmin())) {
    // Длина PIN нужна только для автоотправки и числа точек: PIN из кабинета, иначе из .env; если не цифровой — 4.
    return <AdminLogin pinLength={await activePinLength()} />;
  }
  const data = await getAdminData();
  return <AdminApp data={data} />;
}
