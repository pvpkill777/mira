import { NextResponse } from "next/server";
import { saveImage, UploadError, uploadsLimitBytes, uploadsUsageBytes } from "@/lib/server/uploads";
import { clientIp, createLimiter, serverError } from "@/lib/server/http";

export const dynamic = "force-dynamic";

const MAX_BYTES = 12 * 1024 * 1024;

// Публичная загрузка фото-референса: не больше 15 файлов за 10 минут с одного IP
// и не больше 300 файлов в час со всех адресов (против распределённого спама).
const perIp = createLimiter(15, 10 * 60_000);
const global = createLimiter(300, 60 * 60_000);

export async function POST(req: Request) {
  try {
    const ip = clientIp(req);
    if (perIp.hit(ip) || global.hit("all")) {
      return NextResponse.json({ error: "Слишком много фото за короткое время. Подождите несколько минут." }, { status: 429 });
    }
    const len = Number(req.headers.get("content-length") ?? 0);
    if (len > MAX_BYTES + 64 * 1024) {
      return NextResponse.json({ error: "Фото больше 12 МБ — уменьшите его и загрузите снова." }, { status: 413 });
    }
    if ((await uploadsUsageBytes()) > uploadsLimitBytes()) {
      console.error("[uploads] хранилище переполнено — запустите scripts/cleanup-uploads.mjs");
      return NextResponse.json(
        { error: "Сейчас не получается принять фото. Опишите идею словами или пришлите фото в мессенджер после заявки." },
        { status: 507 },
      );
    }
    const form = await req.formData().catch(() => null);
    const file = form?.get("file");
    if (!(file instanceof File)) return NextResponse.json({ error: "Фото не получено — попробуйте ещё раз." }, { status: 400 });
    const url = await saveImage(file, { maxBytes: MAX_BYTES, maxSide: 1600 });
    return NextResponse.json({ url }, { headers: { "Cache-Control": "no-store" } });
  } catch (e) {
    if (e instanceof UploadError) return NextResponse.json({ error: e.message }, { status: e.status });
    return serverError(e, "POST /api/uploads/design");
  }
}
