import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { guard } from "@/lib/server/auth";
import { cleanText, readJson, serverError } from "@/lib/server/http";
import { isSafeImageUrl } from "@/lib/server/entities";

const TEXT_FIELDS = ["brandName", "ownerName", "tagline", "city", "pickupAddress"] as const;

/** Тексты сайта из вкладки «Тексты сайта»: заголовки — одной строкой, длинные тексты — с переводами строк. */
const SITE_TEXTS: Record<string, { max: number; multiline: boolean }> = {
  heroTitle: { max: 200, multiline: false },
  heroSubtitle: { max: 600, multiline: true },
  aboutTitle: { max: 200, multiline: false },
  aboutQuote: { max: 600, multiline: true },
  aboutText: { max: 1500, multiline: true },
  faqTitle: { max: 200, multiline: false },
  seoTitle: { max: 120, multiline: false },
  seoDescription: { max: 300, multiline: false },
};

/** Допустимые границы чисел: защищают расчёт цены и календарь от опечаток и мусора. */
const INT_FIELDS: Record<string, { min: number; max: number; label: string }> = {
  defaultDailyLimit: { min: 0, max: 50, label: "Заказов в день" },
  urgentSurchargePct: { min: 0, max: 200, label: "Наценка за срочность, %" },
  prepaymentPct: { min: 0, max: 100, label: "Предоплата, %" },
  deliveryFee: { min: 0, max: 100_000, label: "Стоимость доставки" },
  customMinGrams: { min: 100, max: 50_000, label: "Минимальный вес" },
  customMaxGrams: { min: 100, max: 50_000, label: "Максимальный вес" },
  bookingHorizonDays: { min: 1, max: 365, label: "Горизонт записи, дней" },
  minLeadHours: { min: 0, max: 72, label: "Приём заказа закрывается за N часов до интервала" },
  urgentHours: { min: 0, max: 168, label: "Срочным считается заказ меньше чем за N часов" },
};

const bad = (error: string) => NextResponse.json({ error }, { status: 422 });

export async function PUT(req: Request) {
  const denied = await guard();
  if (denied) return denied;
  try {
    const input = await readJson(req);
    const data: Record<string, string | number | boolean> = {};

    for (const k of TEXT_FIELDS) if (k in input) data[k] = cleanText(String(input[k] ?? ""), 200);
    // Название и имя подставляются в шапку сайта и текст клиенту — пустыми быть не могут.
    if ("brandName" in data && !data.brandName) return bad("Укажите название кондитерской");
    if ("ownerName" in data && !data.ownerName) return bad("Укажите имя кондитера");
    if ("paymentDetails" in input) data.paymentDetails = cleanText(String(input.paymentDetails ?? ""), 600, true);

    for (const [k, r] of Object.entries(SITE_TEXTS)) {
      if (!(k in input)) continue;
      const raw = String(input[k] ?? "");
      if (Array.from(raw.trim()).length > r.max) return bad(`Текст слишком длинный: не больше ${r.max} символов`);
      data[k] = cleanText(raw, r.max, r.multiline);
    }
    // Заголовок первого экрана — главное, что видит клиент; пустым он оставлял «дыру» на сайте.
    if ("heroTitle" in data && !String(data.heroTitle).replace(/\*/g, "").trim()) return bad("Заполните заголовок первого экрана");

    for (const k of ["pickupEnabled", "deliveryEnabled"] as const) {
      if (!(k in input)) continue;
      if (typeof input[k] !== "boolean") return bad("Не получилось сохранить способ получения. Обновите страницу и попробуйте ещё раз.");
      data[k] = input[k] as boolean;
    }
    if ("pickupEnabled" in data || "deliveryEnabled" in data) {
      const cur = await prisma.settings.findUnique({ where: { id: 1 }, select: { pickupEnabled: true, deliveryEnabled: true } });
      const pickup = "pickupEnabled" in data ? data.pickupEnabled : cur?.pickupEnabled;
      const delivery = "deliveryEnabled" in data ? data.deliveryEnabled : cur?.deliveryEnabled;
      if (!pickup && !delivery) return bad("Оставьте включённым хотя бы один способ получения — самовывоз или доставку. Иначе клиенты не смогут оформить заказ.");
    }

    for (const k of ["avatarUrl", "heroImageUrl"] as const) {
      if (!(k in input)) continue;
      const v = cleanText(String(input[k] ?? ""), 500);
      if (v && !isSafeImageUrl(v)) return bad("Ссылка на фото должна начинаться с https:// или быть загруженным файлом");
      data[k] = v;
    }

    // Ники и номер подставляются в ссылки t.me / wa.me / instagram.com — только безопасные символы.
    if ("telegram" in input) {
      const v = String(input.telegram ?? "").trim().replace(/^https?:\/\/t\.me\//i, "").replace(/^@/, "");
      if (v && !/^[A-Za-z0-9_]{3,32}$/.test(v)) return bad("Ник в Telegram: латиница, цифры и «_», без пробелов");
      data.telegram = v;
    }
    if ("instagram" in input) {
      const v = String(input.instagram ?? "").trim().replace(/^https?:\/\/(www\.)?instagram\.com\//i, "").replace(/^@/, "").replace(/\/$/, "");
      if (v && !/^[A-Za-z0-9_.]{1,30}$/.test(v)) return bad("Ник в Instagram: латиница, цифры, «_» и точка");
      data.instagram = v;
    }
    if ("whatsapp" in input) {
      let v = String(input.whatsapp ?? "").replace(/\D/g, "");
      // «8 999 …» → «7999…»: wa.me понимает только международный формат.
      if (v.length === 11 && v.startsWith("8")) v = "7" + v.slice(1);
      if (v.length === 10 && v.startsWith("9")) v = "7" + v;
      if (v && (v.length < 10 || v.length > 15)) return bad("Номер WhatsApp — от 10 до 15 цифр");
      data.whatsapp = v;
    }

    if ("closedWeekdays" in input) {
      const days = String(input.closedWeekdays ?? "").split(",").map((s) => s.trim()).filter(Boolean);
      if (days.some((d) => !/^[0-6]$/.test(d))) return bad("Выходные дни: числа от 0 (вс) до 6 (сб) через запятую");
      data.closedWeekdays = [...new Set(days)].join(",");
    }
    if ("timeSlots" in input) {
      const slots = String(input.timeSlots ?? "").split(",").map((s) => cleanText(s, 40)).filter(Boolean);
      if (!slots.length) return bad("Нужен хотя бы один интервал выдачи");
      if (slots.length > 12) return bad("Не больше 12 интервалов выдачи");
      // Строго «ЧЧ:ММ–ЧЧ:ММ», время реальное, начало раньше конца; храним отсортированными по началу.
      const parsed: { text: string; start: number }[] = [];
      for (const s of slots) {
        const m = s.match(/^(\d{1,2}):(\d{2})\s*[–—-]\s*(\d{1,2}):(\d{2})$/);
        const wrong = () => bad(`Интервал «${s}» записан неверно. Пример: «10:00–12:00», начало раньше конца`);
        if (!m) return wrong();
        const [h1, m1, h2, m2] = [Number(m[1]), Number(m[2]), Number(m[3]), Number(m[4])];
        if (h1 > 23 || h2 > 24 || m1 > 59 || m2 > 59 || h1 * 60 + m1 >= h2 * 60 + m2) return wrong();
        const pad = (n: number) => String(n).padStart(2, "0");
        parsed.push({ text: `${pad(h1)}:${pad(m1)}–${pad(h2)}:${pad(m2)}`, start: h1 * 60 + m1 });
      }
      parsed.sort((a, b) => a.start - b.start);
      data.timeSlots = [...new Set(parsed.map((p) => p.text))].join(",");
    }

    for (const [k, r] of Object.entries(INT_FIELDS)) {
      if (!(k in input)) continue;
      const n = Math.round(Number(input[k]));
      if (!Number.isFinite(n) || n < r.min || n > r.max) return bad(`«${r.label}»: от ${r.min} до ${r.max}`);
      data[k] = n;
    }
    if ("customMinGrams" in data || "customMaxGrams" in data) {
      const cur = await prisma.settings.findUnique({ where: { id: 1 }, select: { customMinGrams: true, customMaxGrams: true } });
      const min = Number(data.customMinGrams ?? cur?.customMinGrams);
      const max = Number(data.customMaxGrams ?? cur?.customMaxGrams);
      if (min >= max) return bad("Минимальный вес должен быть меньше максимального");
    }

    const updated = await prisma.settings.update({ where: { id: 1 }, data });
    // Хеш PIN наружу не отдаём.
    const { adminPinHash: _hidden, ...rest } = updated;
    void _hidden;
    return NextResponse.json(rest);
  } catch (e) {
    return serverError(e, "PUT /api/admin/settings");
  }
}
