import { NextResponse } from "next/server";
import { guard } from "@/lib/server/auth";
import { saveImage, UploadError } from "@/lib/server/uploads";

export async function POST(req: Request) {
  const denied = await guard();
  if (denied) return denied;
  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!(file instanceof File)) return NextResponse.json({ error: "Файл не получен" }, { status: 400 });
  try {
    const url = await saveImage(file, { maxBytes: 15 * 1024 * 1024, maxSide: 2000 });
    return NextResponse.json({ url });
  } catch (e) {
    if (e instanceof UploadError) return NextResponse.json({ error: e.message }, { status: e.status });
    throw e;
  }
}
