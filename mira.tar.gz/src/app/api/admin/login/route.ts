import { NextResponse } from "next/server";
import {
  ADMIN_COOKIE,
  SESSION_MAX_AGE_SEC,
  authConfigured,
  checkPin,
  loginBlocked,
  registerFailure,
  resetAttempts,
  sessionToken,
} from "@/lib/server/auth";
import { clientIp, readJson } from "@/lib/server/http";

export const dynamic = "force-dynamic";

/**
 * Secure-флаг. За HTTPS-прокси req.url всё равно http://…, поэтому в продакшене кука
 * всегда Secure, кроме явного запуска на localhost (проверка `next start` без TLS).
 */
function secureCookie(req: Request): boolean {
  if (process.env.NODE_ENV !== "production") return false;
  const host = (req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? "").split(":")[0];
  return !["localhost", "127.0.0.1", "[::1]"].includes(host);
}

const cookieOptions = (req: Request) => ({
  httpOnly: true,
  sameSite: "lax" as const,
  secure: secureCookie(req),
  path: "/",
});

export async function POST(req: Request) {
  const ip = clientIp(req);
  if (loginBlocked(ip)) {
    return NextResponse.json({ error: "Слишком много попыток. Подождите 15 минут и попробуйте снова." }, { status: 429 });
  }
  if (!(await authConfigured())) {
    return NextResponse.json(
      { error: "Вход в кабинет не настроен: задайте ADMIN_PIN и длинный ADMIN_SECRET в .env и перезапустите сайт." },
      { status: 503 },
    );
  }
  const body = await readJson(req, 1024).catch(() => ({}) as Record<string, unknown>);
  const pin = body.pin;
  if (typeof pin !== "string" || !(await checkPin(pin))) {
    registerFailure(ip);
    // Небольшая задержка замедляет перебор и выравнивает время ответа.
    await new Promise((r) => setTimeout(r, 400 + Math.random() * 200));
    return NextResponse.json({ error: "PIN не подошёл. Проверьте и введите ещё раз." }, { status: 401 });
  }
  resetAttempts(ip);
  const res = NextResponse.json({ ok: true });
  res.cookies.set(ADMIN_COOKIE, await sessionToken(), { ...cookieOptions(req), maxAge: SESSION_MAX_AGE_SEC });
  res.headers.set("Cache-Control", "no-store");
  return res;
}

export async function DELETE(req: Request) {
  const res = NextResponse.json({ ok: true });
  // Удаляем с теми же атрибутами, с которыми ставили, иначе браузер может не стереть куку.
  res.cookies.set(ADMIN_COOKIE, "", { ...cookieOptions(req), maxAge: 0 });
  res.headers.set("Cache-Control", "no-store");
  return res;
}
