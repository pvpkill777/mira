import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { guard } from "@/lib/server/auth";
import { isValidKey } from "@/lib/dates";

/** Обновить день: закрыть/открыть, задать лимит (null — по умолчанию). */
export async function PUT(req: Request) {
  const denied = await guard();
  if (denied) return denied;
  const body = (await req.json().catch(() => ({}))) as { date?: string; closed?: boolean; limit?: number | null; note?: string };
  if (!isValidKey(body.date)) return NextResponse.json({ error: "Некорректная дата" }, { status: 400 });

  const closed = Boolean(body.closed);
  if (body.limit != null && !Number.isFinite(Number(body.limit))) {
    return NextResponse.json({ error: "Лимит — число от 0 до 50" }, { status: 400 });
  }
  const limit = body.limit == null ? null : Math.max(0, Math.min(50, Math.round(Number(body.limit))));
  const note = typeof body.note === "string" ? body.note.slice(0, 120) : "";

  // Если всё по умолчанию — просто удаляем запись.
  if (!closed && limit == null && !note) {
    await prisma.dayOverride.deleteMany({ where: { date: body.date } });
    return NextResponse.json({ ok: true });
  }
  const data = { closed, limit, note };
  await prisma.dayOverride.upsert({ where: { date: body.date }, create: { date: body.date, ...data }, update: data });
  return NextResponse.json({ ok: true });
}
