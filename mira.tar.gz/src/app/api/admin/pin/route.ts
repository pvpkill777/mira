import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { ADMIN_COOKIE, checkPin, guard, hashPin, loginBlocked, registerFailure, resetAttempts, weakPin } from "@/lib/server/auth";
import { clientIp, HttpError, readJson, serverError } from "@/lib/server/http";

export const dynamic = "force-dynamic";

const bad = (error: string, status = 422) => NextResponse.json({ error }, { status });

/**
 * Смена PIN из кабинета: { currentPin, newPin }. Новый PIN хранится хешем (scrypt с солью)
 * в Settings.adminPinHash и с этого момента заменяет ADMIN_PIN из .env.
 * Подпись сессии зависит от PIN, поэтому после смены все сессии (включая текущую) завершаются.
 */
export async function POST(req: Request) {
  const denied = await guard();
  if (denied) return denied;
  const ip = clientIp(req);
  // Тот же лимит, что и на входе: украденная сессия не должна давать перебирать текущий PIN.
  if (loginBlocked(ip)) return bad("Слишком много попыток. Подождите 15 минут и попробуйте снова.", 429);
  try {
    const body = await readJson(req, 1024);
    const currentPin = typeof body.currentPin === "string" ? body.currentPin : "";
    const newPin = typeof body.newPin === "string" ? body.newPin.trim() : "";

    if (!/^\d{4,8}$/.test(newPin)) return bad("Новый PIN — от 4 до 8 цифр");
    if (weakPin(newPin)) return bad("Такой PIN легко угадать (одинаковые цифры или подряд). Придумайте другой.");

    if (!(await checkPin(currentPin))) {
      registerFailure(ip);
      await new Promise((r) => setTimeout(r, 400 + Math.random() * 200));
      return bad("Текущий PIN не подошёл. Проверьте и введите ещё раз.");
    }
    resetAttempts(ip);
    if (currentPin === newPin) return bad("Новый PIN совпадает с текущим");

    await prisma.settings.update({ where: { id: 1 }, data: { adminPinHash: hashPin(newPin), adminPinLength: newPin.length } });

    const res = NextResponse.json({ ok: true });
    res.cookies.set(ADMIN_COOKIE, "", { httpOnly: true, sameSite: "lax", path: "/", maxAge: 0 });
    res.headers.set("Cache-Control", "no-store");
    return res;
  } catch (e) {
    if (e instanceof HttpError) return bad(e.message, e.status);
    return serverError(e, "POST /api/admin/pin");
  }
}
