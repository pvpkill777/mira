import { NextResponse } from "next/server";
import { ADMIN_COOKIE, guard, revokeAllSessions } from "@/lib/server/auth";
import { serverError } from "@/lib/server/http";

export const dynamic = "force-dynamic";

/** «Выйти на всех устройствах»: отзывает все сессии кабинета, включая текущую. */
export async function POST() {
  const denied = await guard();
  if (denied) return denied;
  try {
    await revokeAllSessions();
    const res = NextResponse.json({ ok: true });
    res.cookies.set(ADMIN_COOKIE, "", { httpOnly: true, sameSite: "lax", path: "/", maxAge: 0 });
    res.headers.set("Cache-Control", "no-store");
    return res;
  } catch (e) {
    return serverError(e, "POST /api/admin/logout-all");
  }
}
