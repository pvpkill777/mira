import { NextResponse } from "next/server";
import { guard } from "@/lib/server/auth";
import { Prisma } from "@prisma/client";
import { delegate, parseEntity, validateEntityRefs, ENTITY_SCHEMAS } from "@/lib/server/entities";
import { serverError } from "@/lib/server/http";
import { prisma } from "@/lib/prisma";

type Ctx = { params: Promise<{ entity: string; id: string }> };

export async function PATCH(req: Request, ctx: Ctx) {
  const denied = await guard();
  if (denied) return denied;
  const { entity, id } = await ctx.params;
  if (!ENTITY_SCHEMAS[entity]) return NextResponse.json({ error: "Неизвестный раздел" }, { status: 404 });
  const input = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const parsed = parseEntity(entity, input, true);
  if ("error" in parsed) return NextResponse.json({ error: parsed.error }, { status: 422 });
  // Слаг категории неизменен: на него ссылаются работы галереи.
  if (entity === "categories") delete parsed.data.slug;
  try {
    const refError = await validateEntityRefs(entity, parsed.data, false);
    if (refError) return NextResponse.json({ error: refError }, { status: 422 });
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const updated = await (delegate(entity) as any).update({ where: { id }, data: parsed.data });
    return NextResponse.json(updated);
  } catch (e) {
    return dbError(e, "PATCH entity");
  }
}

function dbError(e: unknown, where: string) {
  if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2025") {
    return NextResponse.json({ error: "Запись не найдена — возможно, её уже удалили. Обновите страницу." }, { status: 404 });
  }
  return serverError(e, where);
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const denied = await guard();
  if (denied) return denied;
  const { entity, id } = await ctx.params;
  if (!ENTITY_SCHEMAS[entity]) return NextResponse.json({ error: "Неизвестный раздел" }, { status: 404 });
  try {
    // Работы галереи ссылаются на размеры, начинки, декор и категории — не оставляем «битых» ссылок.
    // Заказы хранят снимок названий, их не трогаем.
    if (entity === "categories") {
      const cat = await prisma.galleryCategory.findUnique({ where: { id } });
      if (!cat) return NextResponse.json({ error: "Запись не найдена — возможно, её уже удалили. Обновите страницу." }, { status: 404 });
      const used = await prisma.galleryItem.count({ where: { category: cat.slug } });
      if (used > 0) {
        return NextResponse.json(
          { error: `В категории «${cat.label}» ${used} ${plural(used, "работа", "работы", "работ")}. Сначала перенесите ${plural(used, "её", "их", "их")} в другую категорию — или просто выключите категорию.` },
          { status: 409 },
        );
      }
      await prisma.galleryCategory.delete({ where: { id } });
      return NextResponse.json({ ok: true });
    }
    if (entity === "sizes" || entity === "fillings") {
      const field = entity === "sizes" ? "sizeId" : "fillingId";
      await prisma.$transaction([
        prisma.galleryItem.updateMany({ where: { [field]: id }, data: { [field]: null } }),
        entity === "sizes" ? prisma.size.delete({ where: { id } }) : prisma.filling.delete({ where: { id } }),
      ]);
      return NextResponse.json({ ok: true });
    }
    if (entity === "decor") {
      await prisma.$transaction(async (tx) => {
        const items = await tx.galleryItem.findMany({ where: { decorIds: { contains: id } }, select: { id: true, decorIds: true } });
        for (const it of items) {
          const next = it.decorIds
            .split(",")
            .map((x) => x.trim())
            .filter((x) => x && x !== id)
            .join(",");
          if (next !== it.decorIds) await tx.galleryItem.update({ where: { id: it.id }, data: { decorIds: next } });
        }
        await tx.decor.delete({ where: { id } });
      });
      return NextResponse.json({ ok: true });
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (delegate(entity) as any).delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return dbError(e, "DELETE entity");
  }
}

function plural(n: number, one: string, few: string, many: string) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return one;
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return few;
  return many;
}
