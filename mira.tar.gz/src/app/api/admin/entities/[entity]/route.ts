import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { guard } from "@/lib/server/auth";
import { delegate, parseEntity, validateEntityRefs, ENTITY_SCHEMAS } from "@/lib/server/entities";
import { serverError } from "@/lib/server/http";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request, ctx: { params: Promise<{ entity: string }> }) {
  const denied = await guard();
  if (denied) return denied;
  const { entity } = await ctx.params;
  if (!ENTITY_SCHEMAS[entity]) return NextResponse.json({ error: "Неизвестный раздел" }, { status: 404 });
  const input = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const parsed = parseEntity(entity, input, false);
  if ("error" in parsed) return NextResponse.json({ error: parsed.error }, { status: 422 });
  try {
    const refError = await validateEntityRefs(entity, parsed.data, true);
    if (refError) return NextResponse.json({ error: refError }, { status: 422 });
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const created = await (delegate(entity) as any).create({ data: parsed.data });
    return NextResponse.json(created);
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
      return NextResponse.json({ error: "Такая запись уже есть" }, { status: 409 });
    }
    return serverError(e, `POST entity ${entity}`);
  }
}

/** Новый порядок: { ids: [...] } — sortOrder = позиция в списке. */
export async function PUT(req: Request, ctx: { params: Promise<{ entity: string }> }) {
  const denied = await guard();
  if (denied) return denied;
  const { entity } = await ctx.params;
  if (!ENTITY_SCHEMAS[entity] || !("sortOrder" in ENTITY_SCHEMAS[entity])) return NextResponse.json({ error: "Неизвестный раздел" }, { status: 404 });
  const input = (await req.json().catch(() => ({}))) as { ids?: unknown };
  const ids = Array.isArray(input.ids) ? input.ids.filter((x): x is string => typeof x === "string" && x.length > 0 && x.length <= 40) : [];
  if (ids.length === 0 || ids.length > 500 || new Set(ids).size !== ids.length) {
    return NextResponse.json({ error: "Не получилось изменить порядок. Обновите страницу и попробуйте ещё раз." }, { status: 422 });
  }
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const d = delegate(entity) as any;
    // updateMany не падает, если запись успели удалить в другой вкладке.
    await prisma.$transaction(ids.map((id, i) => d.updateMany({ where: { id }, data: { sortOrder: i } })));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return serverError(e, `PUT order ${entity}`);
  }
}
