import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { guard } from "@/lib/server/auth";
import { ACTIVE_STATUSES, getCapacity, slotKeyOf } from "@/lib/server/availability";

const STATUSES = ["NEW", "CONFIRMED", "DONE", "CANCELLED"];

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const denied = await guard();
  if (denied) return denied;
  const { id } = await ctx.params;
  const { status } = (await req.json().catch(() => ({}))) as { status?: string };
  if (!status || !STATUSES.includes(status)) {
    return NextResponse.json({ error: "Неизвестный статус" }, { status: 400 });
  }
  const current = await prisma.order.findUnique({ where: { id } });
  if (!current) return NextResponse.json({ error: "Заказ не найден" }, { status: 404 });

  // Время держат только активные заказы (новые и подтверждённые) — ровно те, что сайт
  // показывает клиентам как «занято». Выполненный и отменённый заказ время освобождают:
  // иначе интервал выглядел бы свободным, а заявка на него всё равно получала бы отказ.
  const slotKey = ACTIVE_STATUSES.includes(status) ? slotKeyOf(current.date, current.timeSlot) : null;

  // Возврат в работу (из выполненных или отменённых) не должен молча переполнять день.
  if (ACTIVE_STATUSES.includes(status) && !ACTIVE_STATUSES.includes(current.status)) {
    const [cap] = await getCapacity(current.date, 1);
    if (cap.closed || cap.weekdayOff) {
      return NextResponse.json({ error: "Этот день закрыт для записи. Сначала откройте его в календаре." }, { status: 409 });
    }
    if (cap.count >= cap.limit) {
      return NextResponse.json(
        { error: `На этот день уже ${cap.count} из ${cap.limit} заказов. Увеличьте лимит дня в календаре, если готовы взять ещё один.` },
        { status: 409 },
      );
    }
  }
  try {
    const order = await prisma.order.update({ where: { id }, data: { status, slotKey } });
    return NextResponse.json(order);
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
      const other = await prisma.order.findUnique({ where: { slotKey: slotKeyOf(current.date, current.timeSlot) }, select: { number: true } });
      return NextResponse.json(
        { error: `На это время уже есть заказ №${other?.number ?? "?"}. Сначала отмените его или договоритесь с клиентом о другом времени.` },
        { status: 409 },
      );
    }
    throw e;
  }
}
