import { NextResponse } from "next/server";
import { getAvailability } from "@/lib/server/availability";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json(await getAvailability(), { headers: { "Cache-Control": "no-store" } });
}
