import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCatalog } from "@/lib/server/catalog";
import { Prisma } from "@prisma/client";
import { ACTIVE_STATUSES, getCapacity, dayInfoFromCapacity, slotKeyOf } from "@/lib/server/availability";
import { calculateQuote } from "@/lib/pricing";
import { addDays, bakeryNow, isSlotAvailable, isUrgentSlot, toKey } from "@/lib/dates";
import { phoneDigits, formatPhone } from "@/lib/format";
import { existingMediaUrls } from "@/lib/server/uploads";
import { cleanText, clientIp, createLimiter, HttpError, isStrictDateKey, readJson, serverError } from "@/lib/server/http";
import { MAX_DESIGN_PHOTOS } from "@/lib/types";

export const dynamic = "force-dynamic";

const str = (v: unknown, max: number) => cleanText(v, max);

class DayFullError extends Error {}

function isRetryableDbError(e: unknown): boolean {
  if (e instanceof Prisma.PrismaClientKnownRequestError) return e.code === "P2034" || e.code === "P1008";
  const msg = e instanceof Error ? e.message : "";
  return /database is locked|SQLITE_BUSY|write conflict/i.test(msg);
}

// Защита от спама заявками: 5 заявок за 30 минут и 12 за сутки с одного IP,
// плюс общий предохранитель — не больше 60 заявок в час со всех адресов.
const perIpShort = createLimiter(5, 30 * 60_000);
const perIpDay = createLimiter(12, 24 * 60 * 60_000);
const globalHour = createLimiter(60, 60 * 60_000);

export async function POST(req: Request) {
  try {
    return await createOrderHandler(req);
  } catch (e) {
    return serverError(e, "POST /api/orders");
  }
}

async function createOrderHandler(req: Request) {
  const ip = clientIp(req);
  if (perIpShort.blocked(ip) || perIpDay.blocked(ip) || globalHour.blocked("all")) {
    return NextResponse.json(
      { error: "Слишком много заявок за короткое время. Если что-то не получается — напишите нам в Telegram или WhatsApp." },
      { status: 429 },
    );
  }

  let body: Record<string, unknown>;
  try {
    body = await readJson(req, 16 * 1024);
  } catch (e) {
    if (e instanceof HttpError) return NextResponse.json({ error: e.status === 413 ? "Заявка слишком большая — сократите пожелания." : e.message }, { status: e.status });
    throw e;
  }

  const catalog = await getCatalog();
  const errors: Record<string, string> = {};

  const name = str(body.name, 80);
  const phone = phoneDigits(str(body.phone, 30));
  const contact = str(body.contact, 80);
  const address = str(body.address, 300);
  const delivery = body.delivery === true;
  const date = typeof body.date === "string" ? body.date : "";
  const timeSlot = str(body.timeSlot, 40);

  if (name.length < 2) errors.name = "Как к вам обращаться?";
  if (phone.length !== 10) errors.phone = "Нужен номер из 10 цифр после +7";
  const { pickupEnabled, deliveryEnabled, minLeadHours, urgentHours } = catalog.settings;
  if (delivery && !deliveryEnabled) errors.delivery = "Доставка сейчас не работает — доступен только самовывоз. Обновите страницу и отправьте заявку снова.";
  else if (!delivery && !pickupEnabled) errors.delivery = "Самовывоза сейчас нет — торт можно только доставить. Обновите страницу и укажите адрес доставки.";
  if (delivery && address.length < 5) errors.address = "Укажите адрес доставки";
  if (!isStrictDateKey(date)) errors.date = "Выберите дату";
  if (!catalog.settings.timeSlots.includes(timeSlot)) errors.timeSlot = "Выберите время";

  const size = catalog.sizes.find((s) => s.id === body.sizeId);
  const filling = catalog.fillings.find((f) => f.id === body.fillingId);
  if (!size) errors.size = "Выберите размер торта";
  if (!filling) errors.filling = "Выберите начинку — возможно, она закончилась";

  if (Object.keys(errors).length) {
    return NextResponse.json({ error: Object.values(errors)[0], fields: errors }, { status: 422 });
  }

  // Проверяем, что дата всё ещё свободна и время достижимо.
  const now = bakeryNow();
  const today = toKey(now);
  const horizonEnd = toKey(addDays(now, catalog.settings.bookingHorizonDays));
  const [cap] = await getCapacity(date!, 1);
  const info = dayInfoFromCapacity(cap, today, horizonEnd);
  if (info.status !== "free" && info.status !== "few") {
    return NextResponse.json(
      { error: "Эта дата только что закрылась. Выберите, пожалуйста, другой день — календарь обновлён.", fields: { date: "Дата занята" }, refresh: true },
      { status: 409 },
    );
  }
  if (cap.takenSlots.includes(timeSlot)) {
    return NextResponse.json(
      { error: "Это время уже занято другим заказом. Выберите, пожалуйста, другой интервал — список обновлён.", fields: { timeSlot: "Время занято" }, refresh: true, keepDate: true },
      { status: 409 },
    );
  }
  if (!isSlotAvailable(date!, timeSlot, minLeadHours)) {
    return NextResponse.json({ error: "До этого времени слишком мало часов на приготовление. Выберите интервал позже.", fields: { timeSlot: "Слишком скоро" } }, { status: 409 });
  }

  // urgentHours = 0 — кондитер не берёт срочные заказы, наценку не начисляем.
  // Срочность определяется только временем до выдачи — флаг из запроса не может навязать наценку.
  const urgent = urgentHours > 0 && isUrgentSlot(date!, timeSlot, urgentHours);
  // Только активные позиции декора (каталог уже отфильтрован), без повторов и не больше 30.
  const decorIds = Array.isArray(body.decorIds)
    ? [...new Set(body.decorIds.filter((x): x is string => typeof x === "string").slice(0, 30))]
    : [];
  const rawWeight = Number(body.weightGrams);
  const quote = calculateQuote(
    { sizeId: size!.id, weightGrams: Number.isFinite(rawWeight) && rawWeight > 0 ? rawWeight : size!.weightGrams, fillingId: filling!.id, decorIds, urgent, delivery },
    catalog,
  );
  const galleryRefId =
    typeof body.galleryRefId === "string" && catalog.gallery.some((g) => g.id === body.galleryRefId) ? body.galleryRefId : null;

  const designPhotos = await existingMediaUrls(body.designPhotos, MAX_DESIGN_PHOTOS);

  const createOrder = () =>
    prisma.$transaction(async (tx) => {
    // Повторная проверка дневного лимита внутри транзакции: два заказа на разные
    // интервалы одного дня могли пройти проверку выше одновременно.
    const dayCount = await tx.order.count({ where: { date: date!, status: { in: ACTIVE_STATUSES } } });
    if (dayCount >= cap.limit) throw new DayFullError();
    const last = await tx.order.aggregate({ _max: { number: true } });
    const number = Math.max(1000, last._max.number ?? 1000) + 1;
    return tx.order.create({
      data: {
        number,
        date: date!,
        timeSlot,
        slotKey: slotKeyOf(date!, timeSlot),
        delivery,
        address: delivery ? address : "",
        customerName: name,
        phone: formatPhone(phone),
        contact,
        inscription: str(body.inscription, 120),
        wishes: cleanText(body.wishes, 1000, true),
        designPhotos: designPhotos.join(","),
        sizeId: size!.id,
        sizeName: size!.name,
        weightGrams: quote.weightGrams,
        fillingId: filling!.id,
        fillingName: filling!.name,
        decorJson: JSON.stringify(quote.decor.map((d) => ({ name: d.name, price: d.price }))),
        urgent,
        basePrice: quote.basePrice,
        decorTotal: quote.decorTotal,
        urgentFee: quote.urgentFee,
        deliveryFee: quote.deliveryFee,
        total: quote.total,
        prepayment: quote.prepayment,
        galleryRefId,
      },
    });
    });

  let order: Awaited<ReturnType<typeof createOrder>> | null = null;
  // Номер заказа = max + 1: при одновременных заявках второй получит P2002 по number
  // (или конфликт записи SQLite) — повторяем с новым номером.
  for (let attempt = 0; attempt < 4 && !order; attempt++) {
    try {
      order = await createOrder();
    } catch (e) {
      if (e instanceof DayFullError) {
        return NextResponse.json(
          { error: "Эта дата только что закрылась. Выберите, пожалуйста, другой день — календарь обновлён.", fields: { date: "Дата занята" }, refresh: true },
          { status: 409 },
        );
      }
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
        const target = JSON.stringify(e.meta?.target ?? "");
        if (target.includes("number")) continue;
        // Уникальный slotKey: два клиента одновременно отправили заявку на одно время.
        return NextResponse.json(
          { error: "Это время только что заняли. Выберите, пожалуйста, другой интервал — список обновлён.", fields: { timeSlot: "Время занято" }, refresh: true, keepDate: true },
          { status: 409 },
        );
      }
      if (isRetryableDbError(e) && attempt < 3) {
        await new Promise((r) => setTimeout(r, 50 + Math.random() * 150));
        continue;
      }
      throw e;
    }
  }
  if (!order) throw new Error("Не удалось подобрать номер заказа");

  perIpShort.hit(ip);
  perIpDay.hit(ip);
  globalHour.hit("all");

  return NextResponse.json({
    number: order.number,
    total: order.total,
    prepayment: order.prepayment,
    date: order.date,
    timeSlot: order.timeSlot,
    urgent: order.urgent,
  });
}
