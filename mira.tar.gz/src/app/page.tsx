import { headers } from "next/headers";
import { Shop } from "@/components/shop/Shop";
import { getCatalog } from "@/lib/server/catalog";
import { getAvailability } from "@/lib/server/availability";
import { SITE_URL } from "@/lib/site";
import type { PublicSettings } from "@/lib/types";

export const dynamic = "force-dynamic";

/** Структурированные данные для поисковиков — только то, что есть в настройках, без рейтингов и отзывов. */
function bakeryJsonLd(s: PublicSettings) {
  const abs = (u: string) => (u ? new URL(u, SITE_URL).toString() : undefined);
  const sameAs = [
    s.instagram && `https://instagram.com/${s.instagram}`,
    s.telegram && `https://t.me/${s.telegram}`,
  ].filter(Boolean);
  return {
    "@context": "https://schema.org",
    "@type": "Bakery",
    "@id": `${SITE_URL}/#bakery`,
    name: s.brandName,
    description: s.tagline || undefined,
    url: `${SITE_URL}/`,
    image: abs(s.heroImageUrl),
    logo: `${SITE_URL}/icons/icon-512.png`,
    founder: s.ownerName ? { "@type": "Person", name: s.ownerName } : undefined,
    address: s.pickupAddress || s.city
      ? { "@type": "PostalAddress", streetAddress: s.pickupAddress || undefined, addressLocality: s.city || undefined, addressCountry: "RU" }
      : undefined,
    areaServed: s.city || undefined,
    currenciesAccepted: "RUB",
    sameAs: sameAs.length ? sameAs : undefined,
  };
}

export default async function Home() {
  const [catalog, availability] = await Promise.all([getCatalog(), getAvailability()]);
  const jsonLd = JSON.stringify(bakeryJsonLd(catalog.settings)).replace(/</g, "\\u003c");
  const nonce = (await headers()).get("x-nonce") ?? undefined;
  return (
    <>
      {/* Браузер скрывает атрибут nonce после загрузки — без suppressHydrationWarning React видит «расхождение». */}
      <script type="application/ld+json" nonce={nonce} suppressHydrationWarning dangerouslySetInnerHTML={{ __html: jsonLd }} />
      <Shop catalog={catalog} initialAvailability={availability} />
    </>
  );
}
