import type { MetadataRoute } from "next";
import { getSettings } from "@/lib/server/catalog";
import { SITE_NAME } from "@/lib/site";

// Название берётся из настроек кабинета — манифест собирается на каждый запрос, а не при сборке.
export const dynamic = "force-dynamic";

async function brandName(): Promise<string> {
  try {
    return (await getSettings()).brandName.trim() || SITE_NAME;
  } catch {
    return SITE_NAME;
  }
}

export default async function manifest(): Promise<MetadataRoute.Manifest> {
  const name = await brandName();
  return {
    id: "/",
    name: `${name} — авторские торты`,
    // На домашнем экране под иконкой помещается ~12 символов — длинное название обрезаем по первому слову.
    short_name: name.length <= 12 ? name : name.split(/\s+/)[0].slice(0, 12),
    description: "Соберите торт, узнайте точную цену и выберите свободную дату.",
    start_url: "/?source=pwa",
    scope: "/",
    display: "standalone",
    orientation: "portrait",
    background_color: "#FAF7F2",
    theme_color: "#FAF7F2",
    lang: "ru",
    categories: ["food", "shopping"],
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/icons/maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
    prefer_related_applications: false,
    // Ярлыки видят все, кто установил приложение, поэтому кабинета кондитера здесь нет:
    // клиентам он не нужен, а кондитер откроет /admin по закладке.
    shortcuts: [
      { name: "Собрать торт", short_name: "Собрать", url: "/?source=pwa-shortcut#builder", icons: [{ src: "/icons/icon-192.png", sizes: "192x192", type: "image/png" }] },
      { name: "Выбрать дату", short_name: "Дата", url: "/?source=pwa-shortcut#checkout", icons: [{ src: "/icons/icon-192.png", sizes: "192x192", type: "image/png" }] },
    ],
  };
}
