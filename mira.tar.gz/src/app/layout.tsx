import type { Metadata, Viewport } from "next";
import { headers } from "next/headers";
import { Cormorant_Garamond, Manrope } from "next/font/google";
import "./globals.css";
import { ServiceWorker } from "@/components/ServiceWorker";
import { OG_IMAGE, SITE_DESCRIPTION, SITE_NAME, SITE_TITLE, SITE_URL } from "@/lib/site";
import { getSettings, toPublicSettings } from "@/lib/server/catalog";
import { fillTemplate } from "@/lib/content";

const cormorant = Cormorant_Garamond({
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600"],
  style: ["normal", "italic"],
  variable: "--font-cormorant",
  display: "swap",
});

// Manrope — вариативный шрифт: один файл на все начертания вместо четырёх статических.
const manrope = Manrope({
  subsets: ["latin", "cyrillic"],
  variable: "--font-manrope",
  display: "swap",
});

/** Название, заголовок вкладки и описание — из настроек кабинета; база недоступна или поле пустое — значения из site.ts. */
async function seoFromSettings(): Promise<{ name: string; title: string; description: string }> {
  try {
    const s = await getSettings();
    const pub = toPublicSettings(s);
    const name = s.brandName.trim() || SITE_NAME;
    const title = fillTemplate(s.seoTitle.trim(), pub) || (s.brandName.trim() ? `${name} — авторские торты на заказ` : SITE_TITLE);
    const description = fillTemplate(s.seoDescription.trim(), pub) || SITE_DESCRIPTION;
    return { name, title, description };
  } catch {
    return { name: SITE_NAME, title: SITE_TITLE, description: SITE_DESCRIPTION };
  }
}

export async function generateMetadata(): Promise<Metadata> {
  const { name, title, description } = await seoFromSettings();
  const ogImage = { ...OG_IMAGE, alt: title };
  return {
    metadataBase: new URL(SITE_URL),
    title: { default: title, template: `%s — ${name}` },
    description,
    applicationName: name,
    alternates: { canonical: "/" },
    appleWebApp: {
      capable: true,
      title: name,
      statusBarStyle: "default",
    },
    formatDetection: { telephone: false },
    icons: {
      icon: [
        { url: "/icons/favicon-32.png", sizes: "32x32", type: "image/png" },
        { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      ],
      apple: [{ url: "/icons/apple-touch-icon.png", sizes: "180x180" }],
    },
    openGraph: {
      title,
      description,
      url: "/",
      siteName: name,
      type: "website",
      locale: "ru_RU",
      images: [ogImage],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [OG_IMAGE.url],
    },
  };
}
export const viewport: Viewport = {
  themeColor: "#FAF7F2",
  colorScheme: "light",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  // Чтение заголовков делает все страницы динамическими: nonce из middleware работает
  // только при рендере на запрос (в заранее собранном HTML его не было бы).
  await headers();
  return (
    <html lang="ru" className={`${cormorant.variable} ${manrope.variable}`}>
      <body>
        <div className="relative z-[1]">{children}</div>
        <ServiceWorker />
      </body>
    </html>
  );
}
