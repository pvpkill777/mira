import type { Metadata } from "next";
import { headers } from "next/headers";
import { notFound } from "next/navigation";
import { Shop } from "@/components/shop/Shop";
import { getAvailability } from "@/lib/server/availability";
import { getDemo, getDemoCatalog } from "@/lib/server/demo";
import { splitList } from "@/lib/server/catalog";
import { OG_IMAGE, SITE_DESCRIPTION } from "@/lib/site";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

// Превью ссылок в мессенджерах и поисковые роботы — не «просмотры» кондитера.
const BOT_UA = /bot|crawl|spider|preview|facebookexternalhit|whatsapp|vkshare|telegram|skype|slack|discord|yandex|google/i;

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const demo = await getDemo((await params).slug);
  if (!demo) return { title: "Страница не найдена", robots: { index: false, follow: false } };
  const title = `${demo.brandName} — авторские торты на заказ`;
  const photo = splitList(demo.photos)[0];
  const image = photo ? { url: photo, alt: title } : { ...OG_IMAGE, alt: title };
  return {
    title: { absolute: title },
    description: SITE_DESCRIPTION,
    applicationName: demo.brandName,
    robots: { index: false, follow: false },
    alternates: { canonical: null },
    appleWebApp: { capable: true, title: demo.brandName },
    // Превью ссылки в Instagram/Telegram/WhatsApp — уже с её названием.
    openGraph: { title, description: SITE_DESCRIPTION, url: `/demo/${demo.slug}`, siteName: demo.brandName, type: "website", locale: "ru_RU", images: [image] },
    twitter: { card: "summary_large_image", title, description: SITE_DESCRIPTION, images: [image.url] },
  };
}

export default async function DemoPage({ params }: Props) {
  const demo = await getDemo((await params).slug);
  if (!demo) notFound();
  const ua = (await headers()).get("user-agent") ?? "";
  const [catalog, availability] = await Promise.all([getDemoCatalog(demo, !BOT_UA.test(ua)), getAvailability()]);
  return <Shop catalog={catalog} initialAvailability={availability} demo />;
}
