import type { Metadata } from "next";
import Link from "next/link";
import { Monogram } from "@/components/ui/Monogram";

export const metadata: Metadata = {
  title: "Страница не найдена",
  robots: { index: false, follow: false },
};

/** Страница 404 — в стиле сайта и на русском, вместо стандартной английской. */
export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col items-center justify-center px-6 py-16 text-center">
      <Monogram size={56} />
      <p className="eyebrow mt-8">Ошибка 404</p>
      <h1 className="display mt-3 text-[44px]">Такой страницы нет</h1>
      <p className="mt-4 text-[15px] leading-relaxed text-muted">
        Возможно, ссылка устарела или в&nbsp;ней опечатка. Торт можно собрать на&nbsp;главной&nbsp;— это займёт пару минут.
      </p>
      <Link href="/" className="btn-primary mt-8">
        Собрать торт
      </Link>
    </main>
  );
}
